<?php

use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Auth\OneDriveAuthController;
use App\Http\Controllers\DealModulesController;
use App\Http\Controllers\HierarchyFolderController;
use App\Http\Controllers\LeadModulesController;
use App\Http\Controllers\LeadToDealConversionController;
use App\Http\Controllers\MainFolderController;
use App\Http\Controllers\OneDriveApiController;
use App\Http\Controllers\TemplateController;
use App\Http\Controllers\UsersController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::post('onInstallation', [AuthController::class, 'OnExtensionInstallation']);
//Route::resource('users', UsersController::class);
Route::get('users/{zapikey}/forPlugin', [UsersController::class,'getUserForPlugin']);
Route::get("users/{zapikey}/revokeToken", [OneDriveAuthController::class, 'revokeToken']);

Route::get("hooks/moveConvertedLeadFilesToDeal", [LeadToDealConversionController::class, 'moveConvertedLeadFilesToDeal']);


Route::post("users/{zapikey}/setLeadRootFolder", [UsersController::class, 'setLeadRootFolder']);
Route::post("users/{zapikey}/setConvertedLeadsLocation", [App\Http\Controllers\UsersController::class, 'setConvertedLeadsLocation']);
Route::post('users/{zapikey}/createTemplate', [TemplateController::class, 'createTemplate']);
Route::post('users/{zapikey}/createHierarchyFolder', [HierarchyFolderController::class, 'createFolder']);
Route::get('getHierarchyParentFolderOptions/{templateId}/{parentId}', [HierarchyFolderController::class, 'getParentFolderOptions']);
Route::get('users/{zapikey}/getTemplates', [TemplateController::class, 'getTemplates']);
Route::delete('users/{template}/deleteTemplate', [TemplateController::class, 'deleteTemplate']);
Route::delete('users/{folder}/deleteFolder', [HierarchyFolderController::class, 'deleteFolder']);
Route::post('users/{folder}/updateParentId', [HierarchyFolderController::class, 'updateParentId']);
Route::get('users/{zapikey}/fetchDealTemplateOptions', [TemplateController::class, 'fetchDealTemplateOptions']);
Route::get("users/{zapikey}/getFolderInfo", [OneDriveApiController::class, 'getFolderInfo']);
Route::get("users/{zapikey}/getFolderList", [OneDriveApiController::class, 'getFolderList']);
Route::post("users/{zapikey}/createFolder", [OneDriveApiController::class, 'createFolder']);
Route::post("users/{zapikey}/setDealRootFolder", [UsersController::class, 'setDealRootFolder']);

Route::post("users/{zapikey}/mainFolders/{zoho_id}/uploadFiles", [MainFolderController::class, 'uploadFiles']);
Route::get("users/{zapikey}/mainFolders/{zoho_id}", [MainFolderController::class, 'getMainFolderForPlugin']);
Route::post("users/{zapikey}/mainFolders/{zoho_id}/moveContent", [MainFolderController::class, 'moveContent']);
Route::post("users/{zapikey}/mainFolders/{zoho_id}/deleteContentsBatch", [MainFolderController::class, 'deleteContentsBatch']);
Route::post("users/{zapikey}/mainFolders/{zoho_id}/moveContentsBatch", [MainFolderController::class, 'moveContentsBatch']);
Route::post("users/{zapikey}/mainFolders/{zoho_id}/createFolder", [MainFolderController::class, 'createFolder']);
Route::post("users/{zapikey}/mainFolders/{zoho_id}/deleteContent", [MainFolderController::class, 'deleteContent']);
Route::post("users/{zapikey}/mainFolders/{zoho_id}/renameContent", [MainFolderController::class, 'renameContent']);
Route::get("users/{zapikey}/mainFolders/{zoho_id}/shareContent", [MainFolderController::class, 'shareContent']);
Route::get("users/{zapikey}/mainFolders/{zoho_id}/getFolderContents", [MainFolderController::class, 'getFolderContents']);
Route::get("users/{zapikey}/mainFolders/{zoho_id}/getPaginatedFolderContents", [MainFolderController::class, 'getPaginatedFolderContents']);

Route::post("users/{zapikey}/createDealFoldersFromSettings", [DealModulesController::class, 'createFoldersFromSettings']);
Route::post("users/{zapikey}/createLeadFoldersFromSettings", [LeadModulesController::class, 'createFoldersFromSettings']);
Route::get('getHierarchyFolders/{templateId}',[HierarchyFolderController::class,'getFoldersHierarchy']);


//test for get hierarchy folder
//-------------
//Route::get('/test', [AuthController::class, 'test']);
//Route::get("users/{zapikey}/getRootFolder", [OneDriveApiController::class, 'getRootFolder']);
//Route::get('test/{zapikey}',[TemplateController::class, 'test']);

//1003.c6eca4a2911cfb29c2fcf6c9f80b80f6.0b4136899c128e3040810c7175878907
//users/ ${this.zapikey}/createTemplate`, data
