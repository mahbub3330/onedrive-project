<?php

namespace App\Repositories;

use App\Models\AccountOrContact;
use Illuminate\Database\Eloquent\Model;

class AccountOrContactRepository extends BaseRepository
{
    /*
    * Constructor
    *
    * @param AccountOrContact $model
    *
    * @return void
    */
    public function __construct(AccountOrContact $model)
    {
        $this->model = $model;
    }

    /*
    * Update a model instance from an array
    *
    * @param Model $model
    * @param array $data
    *
    * @return Model $model
    */
    public function updateFromArray(Model $model, array $data)
    {
        $model->fill($data);
        $model->save();
        return $model;
    }

    /*
    * Update or create a model instance
    *
    * @param array $whereClause
    * @param array $data
    *
    * @return Model $model
    */
    public function updateOrCreateFromArray(array $whereClause, array $data)
    {
        $model = $this->model->updateOrCreate($whereClause, $data);
        return $model;
    }

    /*
    * Find a model instance from given conditions
    *
    * @param array $whereClause
    *
    * @return Model $model
    */
    public function findOneByCondition($whereClause = [])
    {
        return $this->model->where($whereClause)->first();
    }

    /*
    * Find a model instances from given conditions
    *
    * @param array $whereClause
    *
    * @return Illuminate\Database\Eloquent\Collection
    */
    public function findByCondition($whereClause = [])
    {
        return $this->model->where($whereClause)->get();
    }
}
