<?php

namespace App\Repositories;

use App\Models\MainFolder;

class MainFolderRepository extends BaseRepository
{
    /*
    * Constructor
    *
    * @param MainFolder $model
    *
    * @return void
    */
    public function __construct(MainFolder $model)
    {
        $this->model = $model;
    }

    /*
    * Update or create a model instance
    *
    * @param array $whereClause
    * @param array $data
    *
    * @return Model $model
    */
    public function updateOrCreateFromArray(array $whereClause, array $data)
    {
        $model = $this->model->updateOrCreate($whereClause, $data);
        return $model;
    }
}
