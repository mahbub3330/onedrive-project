<?php

namespace App\Repositories;

use App\Interfaces\UserRepositoryInterface;
use Illuminate\Database\Eloquent\Model;

class UserRepository extends BaseRepository implements UserRepositoryInterface
{
    public function __construct(Model $model)
    {
        $this->model = $model;
    }

    /**
     * Get Model's first match instance filtered by zapikey
     * @param string $zapikey
     * @return Model
     */

    public function getByZapiKey(string $zapikey): Model
    {
        return $this->model->whereZapikey($zapikey)->first();
    }

    /**
     * Update Model from array of data.
     * @param Model $model
     * @param array $data
     * @return Model
     */
    public function updateFromArray(Model $model, array $data): Model
    {
        $model->fill($data)->update();
        return $model;
    }

}
