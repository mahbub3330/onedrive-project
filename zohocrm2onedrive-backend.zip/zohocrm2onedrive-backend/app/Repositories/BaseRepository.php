<?php

namespace App\Repositories;
use App\Interfaces\BaseRepositoryInterface;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;

abstract class BaseRepository implements BaseRepositoryInterface
{

    /**
     *  Eloquent Model instance
     */
    protected $model;

    /**
     *  Load default model class dependencies.
     * @param Model $model
     */

    public function __construct(Model $model)
    {
        $this->model = $model;
    }

    /**
     *  Get the count of all models
     * @return int
     */

    public function count(): int
    {
        return $this->model->count();
    }

    /**
     * Get Models according to queries.
     * @param Request $request
     * @return Collection
     */
    public function get(Request $request): Collection
    {
        return $this->model
            ->orderBy(
                $request->input('sort_by','created_at'),
                $request->input('sort_order', 'desc')
            )->get();
    }

    /**
     * @param Request $request
     * @return LengthAwarePaginator
     */
    public function paginate(Request $request): LengthAwarePaginator
    {
       return $this->model
           ->orderBy(
               $request->input('sort_by','created_at'),
               $request->input('sort_order', 'desc')
           )->paginate(
               $request->input('per_page', 10),
               '*',
               'page',
               $request->input('page', 1)
           );
    }

    /**
     * @param Request $request
     * @return Model
     */
    public function store(Request $request): Model
    {
        $data = $this->setDataPayload($request);
        $model = $this->model;
        $model->fill($data)->save();

        return $model;
    }

    /**
     * @param Model $model
     * @param Request $request
     * @return Model
     */
    public function update(Model $model, Request $request): Model
    {
        $data = $this->setDataPayload($request);
        $model->fill($data)->update();

        return $model;

    }

    /**
     * Get requested model and send back.
     * @param Model $model
     * @return Model
     */
    public function show(Model $model): Model
    {
        return $model;
    }

    /**
     * @param Model $model
     * @return bool
     */
    public function delete(Model $model): bool
    {
        return $this->model->destroy($model->id);
    }

    /**
     * Set data for saving or updating a model
     * @param Request $request
     * @return array
     */
    protected function setDataPayload(Request $request): array
    {
        if (get_class($request) == Request::class) {
            return $request->all();
        } else {
            return $request->validated();
        }
    }
}
