<?php

namespace App\Http\Resources;

use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  Request  $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'data' => [
                'id' => $this->id,
                'name' => $this->name,
                'email' => $this->email,
                'is_authorized' => $this->is_authorized,
                'picture' => $this->picture,

                'deal_root_folder_id' => $this->deal_root_folder_id,
                'deal_root_folder_name' => $this->deal_root_folder_name,

                'lead_root_folder_id' => $this->lead_root_folder_id,
                'lead_root_folder_name' => $this->lead_root_folder_name,

                'converted_lead_target_template_id' => $this->converted_lead_target_template_id,
                'converted_lead_target_folder_id' => $this->converted_lead_target_folder_id,
                'converted_lead_target_folder_name' => $this->converted_lead_target_folder_name,
            ]
        ];
    }
}
