<?php

namespace App\Http\Resources;

use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MainFolderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  Request  $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request): array|\JsonSerializable|Arrayable
    {
        return [
            'data' => [
                'id' => $this->id,
                'user_id' => $this->user_id,
                'module_name' => $this->module_name,
                'zoho_id' => $this->zoho_id,
                'folder_id' => $this->folder_id,
                'folder_is_deleted' => $this->folder_is_deleted,
                'hierarchy_folder_ids' => $this->hierarchy_folder_ids,
            ]
        ];
    }
}
