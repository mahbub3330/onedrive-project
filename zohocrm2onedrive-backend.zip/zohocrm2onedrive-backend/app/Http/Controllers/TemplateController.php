<?php

namespace App\Http\Controllers;

use App\Models\HierarchyFolder;
use App\Models\Template;
use App\Services\UserService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class TemplateController extends Controller
{
    protected $userService;
    public function __construct(UserService $userService)
    {
        $this->userService = $userService;
    }
    public function test($zapikey)
    {
        $user = $this->userService->getByZapikey($zapikey);
        return response()->json($user);
    }

    public function createTemplate($zapikey ,Request $request,  Template $template)
    {
        $request['user_id'] = $this->userService->getByZapikey($zapikey)->id;
        $template->updateOrCreate(['id'=>$request->id],$request->all());
        return response()->json($template);
    }

    public function getTemplates($zapikey, Request $request)
    {
        $user = $this->userService->getByZapikey($zapikey);
        $templates = $user->templates($request->module_name)->get();

        foreach ($templates as $template)
        {
            $template['hierarchy_folders'] = HierarchyFolder::getFoldersHierarchy($template->id);
        }

        return response()->json($templates);
    }

    public function fetchDealTemplateOptions($zapikey, Request $request)
    {
        $user = $this->userService->getByZapikey($zapikey);
        $templates = $user->templates($request->module_name)->get();

        return response()->json($templates);
    }

    public function deleteTemplate(Template $template)
    {
        try {
            DB::beginTransaction();
            $template->hierarchyFolders()->delete();
            $template->delete();
            DB::commit();

            return response()->json('$template');
        }catch (\Exception $exception){
            DB::rollBack();
            return response()->json($exception->getMessage(),$exception->getCode());
        }

    }
}
