<?php

namespace App\Http\Controllers;

use App\Services\LeadToDealConversionService;
use App\Util\HandleResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class LeadToDealConversionController extends Controller
{

    use HandleResponse;

    /** @var LeadToDealConversionService */
    protected LeadToDealConversionService $leadToDealConversionService;

    /*
    * Constructor
    *
    * @param LeadToDealConversionService $leadToDealConversionService
    *
    * @return void
    */
    public function __construct(LeadToDealConversionService $leadToDealConversionService)
    {
        $this->leadToDealConversionService = $leadToDealConversionService;
    }

    /*
    * Constructor
    *
    * @param Request $request
    *
    * @return response
    */
    public function moveConvertedLeadFilesToDeal(Request $request)
    {
        try {
            $zapikey = $request->zapikey;
            $data = $request->all();

            $result = $this->leadToDealConversionService->moveConvertedLeadFilesToDeal($zapikey, $data);

            if ($result) {
                return $this->respondOk(['message' => 'Lead Files moved Successfullly']);
            } else {
                return $this->respondServerError(['message' => 'An error occured!']);
            }
        } catch (\Exception $e) {
            Log::error('LeadToDealConversionController::moveConvertedLeadFilesToDeal()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => 'Something went wrong!']);
        }
    }
}
