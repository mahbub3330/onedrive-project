<?php

namespace App\Http\Controllers;

use App\Services\DealModuleService;
use App\Util\HandleResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class DealModulesController extends Controller
{
    use HandleResponse;

    /** @var DealModuleService $dealModuleService */
    protected DealModuleService $dealModuleService;

    /*
    * Constructor
    *
    * @param DealModuleService $dealModuleService
    *
    * @return void
    */
    public function __construct(DealModuleService $dealModuleService)
    {
        $this->dealModuleService = $dealModuleService;
    }

    /**
     * Create Deals folders from settings
     *
     * @param $zapikey
     * @param Request $request
     * @return JsonResponse
     *
     */

    public function createFoldersFromSettings($zapikey, Request $request): JsonResponse
    {
        try {
            $dealInfo = $request->deal;
            $templateId = $request->templateId;

            $result = $this->dealModuleService->createFoldersFromSettings($zapikey, $dealInfo, $templateId);

            if ($result) {
                return $this->respondOk(['message' => 'Hierarchy Folders Created Successfullly!']);
            } else {
                return $this->respondServerError(['message' => 'An error occured!']);
            }
        } catch (\Exception $e) {
            Log::error('DealModulesController::createFoldersFromSettings()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => 'Something went wrong!']);
        }
    }

}
