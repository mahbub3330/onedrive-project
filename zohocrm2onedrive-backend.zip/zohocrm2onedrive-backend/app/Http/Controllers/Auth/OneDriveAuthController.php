<?php

namespace App\Http\Controllers\Auth;

use App\Api\test;
use App\Http\Controllers\Controller;
use App\Interfaces\UserRepositoryInterface;
use App\Models\User;
use App\Repositories\TestRep;
use App\Services\UserService;
use App\Util\HandleResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Laravel\Socialite\Facades\Socialite;

class OneDriveAuthController extends Controller
{
    use HandleResponse;

    protected $userService;
    protected $userRepository;

    public function __construct(UserService $userService, UserRepositoryInterface $userRepository)
    {
        $this->userService = $userService;
        $this->userRepository = $userRepository;
    }

    public function redirect($zapikey)
    {
        $userData = $this->userService->getByZapikey($zapikey);

        if (!$userData){
            return $this->respondServerError([
                'message' => 'Something went wrong while trying to authenticate'
            ]);
        }

        $parameters = [
            'token_access_type' => 'offline',
            'state' => $zapikey
        ];

        try {
            return Socialite::driver('graph')
                ->scopes(['offline_access', 'files.read', 'files.read.all',
                    'files.readwrite', 'files.readwrite.all', 'User.ReadWrite.All', 'Directory.ReadWrite.All'])
                ->with($parameters)
                ->redirect();
        }catch (\Throwable $exception){
            return $this->respondServerError([
                'message' => 'Something went wrong while trying to authenticate'
            ]);
        }

    }

    public function handleCallback(Request $request)
    {
        try {
            $response = Socialite::driver('graph')->stateless()->user();
            $zapikey = $request->state;
            $userId = $this->userService->getByZapikey($zapikey)->id;

            $data = [
                'onedrive_id' => $response->id,
                'name' => $response->name,
                'email' => $response->email,
                'picture' => $response->avatar,
                'access_token' => $response->token,
                'access_token_fetched_at' => Carbon::now(),
                'refresh_token' => $response->refreshToken,
                'expires_in' => $response->expiresIn,
                'is_authorized' => true,
            ];
            try {
                User::UpdateOrCreate(['id' => $userId], $data);
            } catch (\Exception $e) {
                return $this->respondServerError([
                    'message' => 'Server Error'. $e->getMessage()
                ]);
            }
            return redirect(env("ONEDRIVE_WEBAPP_REDIRECT_URI"));
        }catch (\Exception $exception){
            return  $this->respondServerError([
                'message' => 'Server Error' . $exception->getMessage()
            ]);
        }

    }

    public function revokeToken($zapikey)
    {
        $user =  $this->userService->getByZapikey($zapikey);
        $this->userService->revokeAccessToken($user);
    }

}
