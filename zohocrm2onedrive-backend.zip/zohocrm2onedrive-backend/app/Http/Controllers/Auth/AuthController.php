<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Util\HandleResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    use HandleResponse;
    /*
    *This function is used for creating user in portal DB
    *
    * @param Request $request
    *
    * return response
    */
    public function OnExtensionInstallation(Request $request)
    {
        $zapikey 		= $request->input('zapikey');
        $response 		= new \stdClass();

        if ($zapikey !="") {
            $data = array();
            $data['zapikey']= $zapikey;
            $data['password']= Hash::make($zapikey);

            $whereClause = array();
            $whereClause['zapikey']= $zapikey;

            try {
                User::UpdateOrCreate($whereClause, $data);

                $response = $this->respondOk(['message' => 'All things have been placed successfully.']);
            } catch (\Exception $e) {
                return $e->getMessage();
                $response = $this->respondUnauthorized(['message' => 'Unauthorized access!!!']);
            }
        } else {
            $response = $this->respondUnauthorized(['message' => 'Unauthorized access!!!']);
        }
        return $response;
    }
}
