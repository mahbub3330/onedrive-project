<?php

namespace App\Http\Controllers;

use App\Http\Resources\MainFolderResource;
use App\Services\MainFolderService;
use App\Util\HandleResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class MainFolderController extends Controller
{
    use HandleResponse;

    /** @var MainFolderService $mainFolderService */
    protected $mainFolderService;

    /*
    * Constructor
    *
    * @param MainFolderService $mainFolderService
    *
    * @return void
    */
    public function __construct(MainFolderService $mainFolderService)
    {
        $this->mainFolderService = $mainFolderService;
    }


    public function getMainFolderForPlugin($zapikey, $zohoId, Request $request)
    {
        try {
            $moduleName = strtolower($request->moduleName);

            $mainFolder = $this->mainFolderService->getMainFolderForPlugin($moduleName, $zapikey, $zohoId);

            if ($mainFolder) {
                return $this->respondOk(['mainFolder' => new MainFolderResource($mainFolder)]);
            } else {
                return $this->respondNotFound();
            }
        } catch (\Exception $e) {
            Log::error('MainFolderController::getMainFolderForPlugin()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => 'Something went wrong!']);
        }
    }

    /*
   * Get contents of a folder inside a main folder
   *
   * @param string $zapikey zapikey of the user
   * @param string $zohoId zoho id of the the record
   * @param Request $request
   *
   * @return response
   */
    public function getFolderContents($zapikey, $zohoId, Request $request)
    {
        try {
            $moduleName = strtolower($request->moduleName);
            $folderId = $request->folderId ?? null;

            return $this->mainFolderService->getContentsList($moduleName, $zapikey, $zohoId, $folderId);
        } catch (\Exception $e) {
            Log::error('MainFolderController::getFolderContents()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => 'Something went wrong!']);
        }
    }

    public function getPaginatedFolderContents($zapikey, $zohoId, Request $request)
    {
        try {
            $moduleName = strtolower($request->moduleName);
            $nextPage = $request->cursor;

            return $this->mainFolderService->getPaginatedFolderContents($moduleName, $zapikey, $zohoId, $nextPage);
        } catch (\Exception $e) {
            Log::error('MainFolderController::getFolderContents()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => 'Something went wrong!']);
        }
    }


    /*
   * Create a folder inside a main folder
   *
   * @param string $zapikey zapikey of the user
   * @param string $zohoId zoho id of the the record
   * @param Request $request
   *
   * @return response
   */
    public function createFolder($zapikey, $zohoId, Request $request)
    {
        try {
            $folder = $this->mainFolderService->createFolder($zapikey, $request->parentFolderId, $request->folderName);

            if ($folder) {
                return $this->respondOk([
                    'message' => 'The folder has been created',
                    'folder' => $folder
                ]);
            } else {
                return $this->respondServerError(['message' => "Something went wrong!"]);
            }
        } catch (\Exception $e) {
            Log::error('MainFolderController::createFolder()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => "Something went wrong!"]);
        }
    }

    /*
   * Share a file or folder inside a mainfolder
   *
   * @param string $zapikey zapikey of the user
   * @param string $zohoId zoho id of the the record
   * @param Request $request
   *
   * @return response
   */
    public function shareContent($zapikey, $zohoId, Request $request)
    {
        try {
            $emails = $request->emails;
            $contentId = $request->get('content');
            $accessType = $request->accessType;
            $shareMessage = $request->shareMessage ?? null;

            $result = $this->mainFolderService->shareContent($zapikey, $contentId, $emails, $accessType, $shareMessage);

            if ($result) {
                return response()->json($result);
                return $this->respondOk(['message' => 'The Content has been shared']);
            } else {
                return $this->respondServerError(['message' => 'Something went wrong!']);
            }
        } catch (\Exception $e) {
            Log::error('MainFolderController::shareContent()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => 'Something went wrong!']);
        }
    }

    /*
    * Rename a file or folder inside a mainfolder
    *
    * @param string $zapikey zapikey of the user
    * @param string $zohoId zoho id of the the record
    * @param Request $request
    *
    * @return response
    */
    public function renameContent($zapikey, $zohoId, Request $request)
    {
        try {
            $content = $request->get('content');
            $newName = $request->newName;

            $result = $this->mainFolderService->renameContent($zapikey, $content, $newName);

            if ($result) {
                return $this->respondOk(['message' => 'The Content has been renamed']);
            } else {
                return $this->respondServerError(['message' => 'Something went wrong!']);
            }
        } catch (\Exception $e) {
            Log::error('MainFolderController::renameContent()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => 'Something went wrong!']);
        }
    }

    /*
    * Delete a file or folder inside a mainfolder
    *
    * @param string $zapikey zapikey of the user
    * @param string $zohoId zoho id of the the record
    * @param Request $request
    *
    * @return response
    */
    public function deleteContent($zapikey, $zohoId, Request $request)
    {
        try {
            $content = $request->get('content');

            $result = $this->mainFolderService->deleteContent($zapikey, $content);

            if ($result) {
                return $this->respondOk(['message' => 'The Content has been deleted']);
            } else {
                return $this->respondServerError(['message' => 'Something went wrong!']);
            }
        } catch (\Exception $e) {
            Log::error('MainFolderController::deleteContent()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => 'Something went wrong!']);
        }
    }

    /*
    * Move a file or folder inside a mainfolder
    *
    * @param string $zapikey zapikey of the user
    * @param string $zohoId zoho id of the the record
    * @param Request $request
    *
    * @return response
    */
    public function moveContent($zapikey, $zohoId, Request $request)
    {
        try {
            $itemId = $request->itemId;
            $parentId = $request->parentId;

            $result = $this->mainFolderService->moveContent($zapikey, $itemId, $parentId);

            if ($result) {
                return $this->respondOk(['message' => 'The Content has been moved']);
            } else {
                return $this->respondServerError(['message' => 'Something went wrong!']);
            }
        } catch (\Exception $e) {
            Log::error('MainFolderController::moveContent()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => 'Something went wrong!']);
        }
    }


    /*
    * Upload files inside a main folder
    *
    * @param string $zapikey zapikey of the user
    * @param string $zohoId zoho id of the the record
    * @param Request $request
    *
    * @return response
    */
    public function uploadFiles($zapikey, $zohoId, Request $request)
    {
        $files = $request->file('files');
        $parentFolderId = $request->parentFolderId;

        try {
            $result = $this->mainFolderService->uploadFiles($zapikey, $zohoId, $files, $parentFolderId);

            if ($result) {
                return $this->respondOk(['message' => 'The file(s) have been uploaded.']);
            } else {
                return $this->respondServerError(['message' => 'Something went wrong!']);
            }
        } catch (\Exception $e) {
            Log::error('MainFolderController::uploadFiles()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => "Something went wrong!"]);
        }
    }

    /*
   * Delete multiple files or folders inside a mainfolder
   *
   * @param string $zapikey zapikey of the user
   * @param string $zohoId zoho id of the the record
   * @param Request $request
   *
   * @return response
   */
    public function deleteContentsBatch($zapikey, $zohoId, Request $request)
    {
        try {
            $entries = $request->entries;

            $result = $this->mainFolderService->deleteContentsBatch($zapikey, $entries);

            if ($result) {
                return $this->respondOk(['message' => 'The Contents has been deleted']);
            } else {
                return $this->respondServerError(['message' => 'Something went wrong!']);
            }
        } catch (\Exception $e) {
            Log::error('MainFolderController::deleteContentsBatch()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => 'Something went wrong!']);
        }
    }

    /*
    * Move multiple contents inside a mainfolder
    *
    * @param string $zapikey zapikey of the user
    * @param string $zohoId zoho id of the record
    * @param Request $request
    *
    * @return response
    */
    public function moveContentsBatch($zapikey, $zohoId, Request $request)
    {
        try {
            $parentPreferenceId = $request->parentId;
            $itemIds = $request->itemIds;

            $result = $this->mainFolderService->moveContentsBatch($zapikey, $parentPreferenceId, $itemIds);

            if ($result) {
                return $this->respondOk(['message' => 'The Contents has been moved']);
            } else {
                return $this->respondServerError(['message' => 'Something went wrong!']);
            }
        } catch (\Exception $e) {
            Log::error('MainFolderController::moveContentsBatch()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => 'Something went wrong!']);
        }
    }

}
