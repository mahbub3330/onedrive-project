<?php

namespace App\Http\Controllers;

use App\Models\HierarchyFolder;
use App\Services\UserService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HierarchyFolderController extends Controller
{
    protected $userService;

    public function __construct(UserService $userService)
    {
        $this->userService = $userService;
    }

    public function createFolder($zapikey, HierarchyFolder $hierarchyFolder, Request $request)
    {
        $request['user_id'] = $this->userService->getByZapikey($zapikey)->id;
        $hierarchyFolder->updateOrCreate(['id' => $request->id], $request->all());
        return response()->json($request->all());
    }

    public function getParentFolderOptions($templateId, $parent_id)
    {

        $options = HierarchyFolder::query()
            ->where(['template_id' => $templateId])
//            ->when($parent_id !== 'null', function ($q) use ($parent_id) {
//                return $q->where('id', $parent_id);
//            })
//            ->when($parent_id == 'null', function ($q) {
//                return $q->whereNull('parent_id');
//            })
            ->get()
            ->map(function ($item) {
                return [
                    'id' => $item->id,
                    'text' => $item->name
                ];
            })->unique('text')->values();
        return response()->json($options);
    }

    public function deleteFolder(HierarchyFolder $folder)
    {
        try {
            DB::beginTransaction();
            $folder->folders()->delete();
            $folder->delete();
            DB::commit();

            return response()->json('success');
        } catch (\Exception $exception) {
            DB::rollBack();
            return response()->json($exception->getMessage(), $exception->getCode());
        }
    }

    public function updateParentId(HierarchyFolder $folder, Request $request)
    {
        try {
            DB::beginTransaction();
            $folder->parent_id = $request->get('parentId');
            $folder->save();
            DB::commit();

            return response()->json('success');
        } catch (\Exception $exception) {
            DB::rollBack();
            return response()->json($exception->getMessage(), $exception->getCode());
        }
    }

    public function getFoldersHierarchy($templateId)
    {
        $folders = HierarchyFolder::getFoldersHierarchy($templateId);
        return response()->json($folders);
    }

}
