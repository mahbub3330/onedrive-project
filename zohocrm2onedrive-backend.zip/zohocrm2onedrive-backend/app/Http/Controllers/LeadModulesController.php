<?php

namespace App\Http\Controllers;

use App\Services\LeadModuleService;
use App\Util\HandleResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class LeadModulesController extends Controller
{
    use HandleResponse;

    /** @var LeadModuleService $leadModuleService */
    protected $leadModuleService;

    /*
    * Constructor
    *
    * @param LeadModuleService $leadModuleService
    *
    * @return void
    */
    public function __construct(LeadModuleService $leadModuleService)
    {
        $this->leadModuleService = $leadModuleService;
    }

    /*
    * Create Leads folders from settings
    *
    * @param string $zapikey zapikey of the user
    * @param Request $request
    *
    * @return response
    */
    public function createFoldersFromSettings($zapikey, Request $request)
    {
        try {
            $leadInfo = $request->lead;
            $templateId = $request->templateId;

            $result = $this->leadModuleService->createFoldersFromSettings($zapikey, $leadInfo, $templateId);

            if ($result) {
                return $this->respondOk(['message' => 'Hierarchy Folders Created Successfullly!']);
            } else {
                return $this->respondServerError(['message' => 'An error occured!']);
            }
        } catch (\Exception $e) {
            Log::error('LeadModulesController::createFoldersFromSettings()');
            Log::error($e->getMessage());
            return $this->respondServerError(['message' => 'Something went wrong!']);
        }
    }
}
