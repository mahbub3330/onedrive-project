<?php

namespace App\Http\Controllers;

use App\Services\OneDriveManageService;
use App\Services\UserService;
use Illuminate\Http\Request;

class OneDriveApiController extends Controller
{
    protected $userService;

    public function __construct(UserService $userService)
    {
        $this->userService = $userService;
    }

    public function getRootFolder($zapikey)
    {
        $user = $this->userService->getByZapikey($zapikey);
        $oneDriveManager = new OneDriveManageService($user);
        $oneDriveManager->getRootFolder();

    }

    public function getFolderInfo($zapikey, Request $request)
    {
        $user = $this->userService->getByZapikey($zapikey);
        $oneDriveManager = new OneDriveManageService($user);
        $response = $oneDriveManager->getFolderInfo($request->get('folderId'));

        return response()->json($response);
    }
    public function getFolderList($zapikey, Request $request)
    {
        $user = $this->userService->getByZapikey($zapikey);
        $oneDriveManager = new OneDriveManageService($user);
        $response = $oneDriveManager->getFolderList($request->get('folderId'));

        return response()->json($response);
    }

    public function createFolder($zapikey, Request $request)
    {
        $user = $this->userService->getByZapikey($zapikey);
        $oneDriveManager = new OneDriveManageService($user);
        $response = $oneDriveManager->createFolder($request->parentFolderId, $request->folderName);

        return response()->json($response);
    }
}
