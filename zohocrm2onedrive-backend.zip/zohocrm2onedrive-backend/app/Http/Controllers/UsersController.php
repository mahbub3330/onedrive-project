<?php

namespace App\Http\Controllers;

use App\Http\Resources\UserResource;
use App\Interfaces\UserRepositoryInterface;
use App\Services\UserService;
use App\Util\HandleResponse;
use Illuminate\Http\Request;

class UsersController extends Controller
{
    protected $service;
    protected $userRepository;
    use HandleResponse;

    public function __construct(UserService $userService, UserRepositoryInterface $userRepository)
    {
        $this->service = $userService;
    }


    public function getUserForPlugin($zapikey)
    {
        $result = $this->service->getUserForPlugin($zapikey);

        return $this->respondOk([
            'user' => new UserResource($result['user']),
            'additionalInfo' => $result['additionalInfo']
        ]);
    }

    public function setDealRootFolder($zapikey, Request $request)
    {
        $user = $this->service->getByZapikey($zapikey);

        $user = $this->service->setDealRootFolder($user, $request->all());

        return $this->respondOk(['user' => new UserResource($user)]);
    }

    public function setLeadRootFolder($zapikey, Request $request)
    {
        $user = $this->service->getByZapikey($zapikey);

        $user = $this->service->setLeadRootFolder($user, $request->all());

        return $this->respondOk(['user' => new UserResource($user)]);
    }

    public function setConvertedLeadsLocation($zapikey, Request $request)
    {
        $user = $this->service->getByZapikey($zapikey);

        $user = $this->service->setConvertedLeadsLocation($user, $request);

        if ($user) {
            return $this->respondOk(['user' => new UserResource($user)]);
        } else {
            return $this->respondServerError(['message' => "Something went wrong!"]);
        }
    }

}
