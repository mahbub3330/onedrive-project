<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Log;


class MainFolderService
{
    /** @var User */
    protected $user = null;

    /** @var UserService */
    protected UserService $userService;

    /** @var OneDriveManageService */
    protected OneDriveManageService $oneDriveManageService;

    /*
    * Constructor
    *
    * @param UserService $userService
    *
    * @return void
    */
    public function __construct(UserService $userService)
    {
        $this->userService = $userService;
    }

    /*
    * Set user by zapikey
    *
    * @param string $zapikey zapikey of the user
    * @param boolean $force if the user should be fetched even if the user is set
    *
    * @return User
    */
    public function setUserByZapkey($zapikey, $force = false)
    {
        if ($force) {
            $this->user = $this->userService->getByZapikey($zapikey);
        } else {
            $this->user = $this->user ?? $this->userService->getByZapikey($zapikey);
        }
        return $this->user;
    }

    /*
    * Set the OneDriveManagerServie
    *
    * @param User $user
    * @param boolean $force if the service should be set even if it's already set
    *
    * @return OneDriveManageService
    */
    public function setOneDriveManagerService($user, $force = false): OneDriveManageService
    {
        if ($force) {
            $this->oneDriveManageService = new OneDriveManageService($user);
        } else {
            $this->oneDriveManageService = $this->oneDriveManageService ?? new OneDriveManageService($user);
        }
        return $this->oneDriveManageService;
    }

    /*
    * Get a main folder info for a record in a module for the plugin
    *
    * @param string $moduleName
    * @param string $zapikey zapikey of the user
    * @param string $zohoId zoho id of the record
    *
    * @return MainFolder
    */


    public function getMainFolderForPlugin($moduleName, $zapikey, $zohoId): object|null
    {
        try {
            $mainFolder = $this->getMainFolder($moduleName, $zapikey, $zohoId);

            $this->setUserByZapkey($zapikey);

            $this->setOneDriveManagerService($this->user);

            // check if main folder's dropbox folder is deleted already
            $mainFolderInDropboxExists = $this->oneDriveManageService->isFolderExists($mainFolder->folder_id);
            $mainFolder->update(['folder_is_deleted' => !$mainFolderInDropboxExists]);

            return $mainFolder;
        } catch (\Exception $e) {
            return null;
        }
    }

    /*
    * Get a main folder
    *
    * @param string $moduleName
    * @param string $zapikey zapikey of the user
    * @param string $zohoId zoho id of the record
    *
    * @return object|null
    */
    public function getMainFolder($moduleName, $zapikey, $zohoId): object|null
    {
        try {
            $this->setUserByZapkey($zapikey);

            if ($this->user == null) {
                return null;
            }

            $whereClause = [
                'zoho_id' => $zohoId
            ];

            return $this->user->mainFolders($moduleName)->where($whereClause)->first();
        } catch (\Exception $e) {
            return null;
        }
    }

    /*
    * Get contents of a folder inside a main folder
    *
    * @param string $moduleName
    * @param string $zapikey zapikey of the user
    * @param string $zohoId zoho id of the record
    * @param string $folderId
    *
    * @return array
    */
    public function getContentsList($moduleName, $zapikey, $zohoId, $folderId)
    {
        $mainFolder = $this->getMainFolder($moduleName, $zapikey, $zohoId);
        $folderId = $folderId ?? $mainFolder->folder_id;

        $this->setUserByZapkey($zapikey);
        $this->setOneDriveManagerService($this->user);

        $contents = $this->oneDriveManageService->getFolderContents($folderId);
        $hierarchyFolderIds = explode(',', $mainFolder->hierarchy_folder_ids);

        foreach ($contents['value'] as &$entry) {
            if (isset($entry['folder'])) {
                $entry['.tag'] = 'folder';
                $entry['is_hierarchy_folder'] = in_array($entry['id'], $hierarchyFolderIds);
            } else {
                $entry['.tag'] = 'file';
            }

        }

        return $contents;
    }

    public function getPaginatedFolderContents($moduleName, $zapikey, $zohoId, $nextPage)
    {
        $mainFolder = $this->getMainFolder($moduleName, $zapikey, $zohoId);
        $this->setUserByZapkey($zapikey);
        $this->setOneDriveManagerService($this->user);
        $contents = $this->oneDriveManageService->getPaginatedFolderContents($nextPage);
        $hierarchyFolderIds = explode(',', $mainFolder->hierarchy_folder_ids);

        foreach ($contents['value'] as &$entry) {
            if (isset($entry['folder'])) {
                $entry['.tag'] = 'folder';
                $entry['is_hierarchy_folder'] = in_array($entry['id'], $hierarchyFolderIds);
            } else {
                $entry['.tag'] = 'file';
            }

        }

        return $contents;
    }


    public function createFolder($zapikey, $parentFolderId, $folderName)
    {
        $this->setUserByZapkey($zapikey);

        $this->setOneDriveManagerService($this->user);

        try {
            $this->setUserByZapkey($zapikey);

            $this->setOneDriveManagerService($this->user);

            return $this->oneDriveManageService->createFolder($parentFolderId, $folderName);
        } catch (\Exception $e) {
            Log::error('MainFolderService::createFolder()');
            Log::error($e->getMessage());
            return false;
        }

    }

    /*
    * Share a file or folder inside a mainfolder
    *
    * @param string $zapikey zapikey of the user
    * @param stdClass $content
    * @param string[] $emails
    * @param string $accessType
    * @param string $shareMessage
    *
    * @return boolean
    */
    public function shareContent($zapikey, $contentId, $emails, $accessType, $shareMessage)
    {
        try {
            $this->setUserByZapkey($zapikey);
            $this->setOneDriveManagerService($this->user);

            $result = $this->oneDriveManageService->shareFile($contentId, $emails, $accessType, $shareMessage);

            return !isset($result['status']);

            return true;
        } catch (\Exception $e) {
            Log::error('MainFolderService::renameContent()');
            Log::error($e->getMessage());
            return false;
        }

    }

    /*
    * Rename a file or folder inside a mainfolder
    *
    * @param string $zapikey zapikey of the user
    * @param stdClass $content
    * @param string $newName
    *
    * @return boolean
    */
    public function renameContent($zapikey, $content, $newName)
    {
        try {
            $this->setUserByZapkey($zapikey);
            $this->setOneDriveManagerService($this->user);

            $this->oneDriveManageService->rename($content['id'], $newName);

            return true;
        } catch (\Exception $e) {
            Log::error('MainFolderService::renameContent()');
            Log::error($e->getMessage());
            return false;
        }
    }

    /*
   * Delete a file or folder inside a mainfolder
   *
   * @param string $zapikey zapikey of the user
   * @param stdClass $content
   *
   * @return boolean
   */
    public function deleteContent($zapikey, $content)
    {
        try {
            $this->setUserByZapkey($zapikey);
            $this->setOneDriveManagerService($this->user);

            $this->oneDriveManageService->delete($content['id']);

            return true;
        } catch (\Exception $e) {
            Log::error('MainFolderService::deleteContent()');
            Log::error($e->getMessage());
            return false;
        }
    }

    /*
   * Move a file or folder inside a mainfolder
   *
   * @param string $zapikey zapikey of the user
   * @param stdClass $content
   * @param string $destinationFullPath
   *
   * @return response
   */
    public function moveContent($zapikey, $itemId, $parentReferenceId)
    {
        try {
            $this->setUserByZapkey($zapikey);
            $this->setOneDriveManagerService($this->user);
            $this->oneDriveManageService->move($itemId, $parentReferenceId);

            return true;
        } catch (\Exception $e) {
            Log::error('MainFolderService::moveContent()');
            Log::error($e->getMessage());
            return false;
        }

    }

    /*
    * Upload files inside a main folder
    *
    * @param string $zapikey zapikey of the user
    * @param string $zohoId
    * @param array $files
    * @param string $parentFolderId
    *
    * @return boolean
    */
    public function uploadFiles($zapikey, $zohoId, $files, $parentFolderId)
    {
        try {
            $this->setUserByZapkey($zapikey);
            $this->setOneDriveManagerService($this->user);

            $result = $this->oneDriveManageService->uploadFiles($files, $parentFolderId);

            return $result;
        } catch (\Exception $e) {
            Log::error('MainFolderService::uploadFiles()');
            Log::error($e->getMessage());
            return false;
        }
    }

    /*
    * Delete multiple files or folders inside a mainfolder
    *
    * @param string $zapikey zapikey of the user
    * @param array $entries
    *
    * @return boolean
    */
    public function deleteContentsBatch($zapikey, $items)
    {
        try {
            $this->setUserByZapkey($zapikey);
            $this->setOneDriveManagerService($this->user);

            return $this->oneDriveManageService->deleteBatch($items);
        } catch (\Exception $e) {
            Log::error('MainFolderService::deleteContentsBatch()');
            Log::error($e->getMessage());
            return false;
        }
    }

    /*
    * Move multiple contents inside a mainfolder
    *
    * @param string $zapikey zapikey of the user
    * @param array $entries
    *
    * @return boolean
    */
    public function moveContentsBatch($zapikey, $parentPreferenceId, $itemIds)
    {
        try {
            $this->setUserByZapkey($zapikey);
            $this->setOneDriveManagerService($this->user);

            return $this->oneDriveManageService->moveBatch($parentPreferenceId, $itemIds);
        } catch (\Exception $e) {
            Log::error('MainFolderService::moveContentsBatch()');
            Log::error($e->getMessage());
            return false;
        }
    }
}
