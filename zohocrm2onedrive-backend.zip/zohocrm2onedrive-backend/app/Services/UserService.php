<?php

namespace App\Services;

use App\Api\OneDriveApi;
use App\Interfaces\UserRepositoryInterface;
use App\Models\HierarchyFolder;
use App\Models\User;

class UserService
{
    private $userRepository;

    public function __construct(UserRepositoryInterface $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    public function getByZapikey($zapikey)
    {
        return $this->userRepository->getByZapikey($zapikey);
    }

    public function getUserForPlugin($zapikey)
    {
        $user = $this->getByZapikey($zapikey);
        // check if converted lead target folder in changed
        $user = $this->updateConvertLeadTargetFolderInfoIfNeeded($user);

        $additionalInfo = [
            'dealRootFolderExists' => $user->access_token ? (new OneDriveApi($user))->isFolderExists($user->deal_root_folder_id) : false,
            'leadRootFolderExists' => $user->access_token ? (new OneDriveApi($user))->isFolderExists($user->lead_root_folder_id) : false,
        ];

        return compact('user', 'additionalInfo');
    }

    public function setDealRootFolder(User $user, $data)
    {
        $updateArray = [
            'deal_root_folder_id' => $data['folderId'],
            'deal_root_folder_name' => $data['folderName']
        ];

        return $this->userRepository->updateFromArray($user, $updateArray);
    }
    public function setLeadRootFolder(User $user, $data)
    {
        $updateArray = [
            'lead_root_folder_id' => $data['folderId'],
            'lead_root_folder_name' => $data['folderName']
        ];

        return $this->userRepository->updateFromArray($user, $updateArray);
    }

    public function setConvertedLeadsLocation($user, $request)
    {
        try {
            $folderName = HierarchyFolder::where('id', $request->folderId)->first()->name;

            $user = $this->userRepository->updateFromArray($user, [
                'converted_lead_target_template_id' => $request->templateId,
                'converted_lead_target_folder_id' => $request->folderId,
                'converted_lead_target_folder_name' => $folderName
            ]);
            return $user;
        } catch (\Exception $e) {
            Log::error("UserService::setConvertedLeadsLocation()");
            Log::error($e->getMessage());
            return false;
        }
    }

    public function revokeAccessToken(User $user)
    {
        (new OneDriveAuthenticationService($user))->revokeToken();

        $this->userRepository->updateFromArray($user, [
            'name' => null,
            'email' => null,
            'access_token' => null,
            'access_token_fetched_at' => null,
            'expires_in' => null,
            'refresh_token' => null,
            'onedrive_id' => null,
            'is_authorized' => false,
            'picture' => null
        ]);
    }

    /*
    * Update user's leads files move location data during lead conversion if needed
    *
    * @param User $user
    *
    * @return User
    */
    public function updateConvertLeadTargetFolderInfoIfNeeded($user)
    {
        $hierarchyFolder = HierarchyFolder::query()->where('id', $user->converted_lead_target_folder_id)->first();
        if (!$hierarchyFolder) {
            $user = $this->userRepository->updateFromArray($user, [
                'converted_lead_target_folder_id' => null,
                'converted_lead_target_folder_name' => null,
            ]);
        } elseif ($user->converted_lead_target_folder_name !== $hierarchyFolder->name) {
            $user = $this->userRepository->updateFromArray($user, [
                'converted_lead_target_folder_name' => $hierarchyFolder->name
            ]);
        }

        return $user;
    }



}
