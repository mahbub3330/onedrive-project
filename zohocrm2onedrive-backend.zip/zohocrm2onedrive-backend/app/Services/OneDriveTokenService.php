<?php

namespace App\Services;

use App\Models\User;
use Carbon\Carbon;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Http;
use Microsoft\Graph\Graph;

class OneDriveTokenService
{
    protected $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }

    public function getToken(): string
    {
        if (!$this->isTokenRefreshNeeded()) {
            return $this->user->access_token;
        }
        return $this->renewToken();
    }

    public function isTokenRefreshNeeded(): bool
    {
        return Carbon::now()->diffInSeconds($this->user->access_token_fetched_at) > $this->user->expires_in;
    }

    public function renewToken(): string
    {
        $client = new Client();
        $url = 'https://login.microsoftonline.com/common/oauth2/v2.0/token';
        $headers = [
            'Content-Type' => 'application/x-www-form-urlencoded'
        ];
        $formParams = [
            'client_id' => config('services.graph.client_id'),
            'client_secret' => config('services.graph.client_secret'),
            'grant_type' => 'refresh_token',
            'refresh_token' => $this->user->refresh_token
        ];

        $response = $client->request('POST', $url, [
            'headers' => $headers,
            'form_params' => $formParams,
            'http_errors' => false
        ]);

        if ($response->getStatusCode() != 200) {
            return (json_decode($response->getBody()->getContents())->error_description) ?? 'Something Went Wrong!';
        }

        $responseBody = json_decode($response->getBody()->getContents());
        $this->user->update([
            'access_token' => $responseBody->access_token,
            'access_token_fetched_at' => Carbon::now(),
            'expires_in' => $responseBody->expires_in
        ]);

        return $this->user->access_token;
    }

    public function revokeToken()
    {
        $graph = new Graph();
        $graph->setBaseUrl("https://graph.microsoft.com/")
            ->setApiVersion("v1.0")
            ->setAccessToken($this->user->access_token);

        $graph->createRequest("POST", "/me/revokeSignInSessions")
            ->addHeaders(array("Content-Type" => "application/json"))
            ->setReturnType(\Microsoft\Graph\Model\User::class)
            ->setTimeout("1000")
            ->execute();


    }


}
