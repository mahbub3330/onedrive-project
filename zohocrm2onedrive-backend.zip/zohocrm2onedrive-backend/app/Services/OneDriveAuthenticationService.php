<?php

namespace App\Services;

use App\Api\ClientApi;
use App\Models\User;
use Carbon\Carbon;
use Exception;

class OneDriveAuthenticationService
{

    protected $user;

    protected $refreshTokenUrl = 'https://login.microsoftonline.com/common/oauth2/v2.0/token';
    protected $revokeAccessUrl = 'https://graph.microsoft.com/v1.0/me/revokeSignInSessions';

    protected $access_token;

    public function __construct(User $user)
    {
        $this->user = $user;
        $this->validateToken();
    }

    private function validateToken()
    {
        if ($this->isTokenRefreshNeeded()) {
            $this->performTokenRefresh();
        }

        $this->access_token = $this->user->access_token;

    }

    private function performTokenRefresh()
    {
        try {
            $this->refreshAccessToken();
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    private function refreshAccessToken()
    {
        $url = $this->refreshTokenUrl;
        $options = $this->generateRefreshTokenOptions();

        $response = $this->getClient()->post(url: $url, action: 'POST', options: $options)->getResult();


        if (isset($response->error)) throw new \Exception($response->error_description?? 'Something Went Wrong!');

        $this->user->update([
            'access_token' => $response->access_token,
            'access_token_fetched_at' => Carbon::now(),
            'expires_in' => $response->expires_in
        ]);


    }

    private function generateRefreshTokenOptions()
    {
        $options = [];
        $options['headers'] = [
            'Content-Type' => 'application/x-www-form-urlencoded'
        ];
        $options['form_params'] = [
            'client_id' => config('services.graph.client_id'),
            'client_secret' => config('services.graph.client_secret'),
            'grant_type' => 'refresh_token',
            'refresh_token' => $this->user->refresh_token
        ];
        $options['http_errors'] = false;
        return $options;
    }

    private function getClient()
    {
        return new  ClientApi();
    }

    public function getAccessToken()
    {
        if ($this->isTokenRefreshNeeded()) {
            $this->performTokenRefresh();
        }

        return $this->access_token;
    }

    private function isTokenRefreshNeeded(): bool
    {
        return Carbon::now()->diffInSeconds($this->user->access_token_fetched_at) + 60 > $this->user->expires_in;
    }

    public function revokeToken()
    {
        $url = $this->revokeAccessUrl;
        $options = $this->generateRevokeAccessOptions();
        $response = $this->getClient()->post(url: $url, action: 'POST', options: $options)->getResult();

        if (isset($response->error)) throw new \Exception($response->error->message ?? 'Something Went Wrong!');


    }

    private function generateRevokeAccessOptions()
    {
        $options = [];
        $options['headers'] = [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $this->getAccessToken()
        ];

        $options['http_errors'] = false;

        return $options;
    }

}
