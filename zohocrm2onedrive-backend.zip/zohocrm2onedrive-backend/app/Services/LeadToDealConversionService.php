<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;

class LeadToDealConversionService
{
    /** @var UserService */
    protected UserService $userService;

    /** @var DealModuleService */
    protected DealModuleService $dealModuleService;

    /** @var MainFolderService */
    protected MainFolderService $mainFolderService;

    /** @var OneDriveManageService */
    protected OneDriveManageService $oneDriveManageService;

    /*
    * Constructor
    *
    * @param UserService $userService
    * @param DealModuleService $dealModuleService
    * @param MainFolderService $mainFolderService
    *
    * @return void
    */

    public function __construct(UserService $userService, DealModuleService $dealModuleService, MainFolderService $mainFolderService)
    {
        $this->userService = $userService;
        $this->dealModuleService = $dealModuleService;
        $this->mainFolderService = $mainFolderService;
    }


    public function moveConvertedLeadFilesToDeal($zapikey, $data)
    {
        try {
            $user = $this->userService->getByZapikey($zapikey)->first();
            $this->oneDriveManageService = new OneDriveManageService($user);

            $leadId = $data['leadId'];
            $existingLeadMainFolder = $this->mainFolderService->getMainFolder('leads', $zapikey, $leadId);
            if (!$existingLeadMainFolder) {
                return false;
            }
            $templateId = $user->converted_lead_target_template_id;
            $sourcePathId = $this->oneDriveManageService->getFolderInfo($existingLeadMainFolder->folder_id)->getId();

            $dealInfo = $this->constructDealInfo($data);
            $this->dealModuleService->createFoldersFromSettings($zapikey, $dealInfo,$templateId, $leadId);
            $createdDealMainFolder = $this->dealModuleService->getMainFolder();

            // to do id should be same
//            $destinationFolderPath = $createdDealMainFolder->converted_lead_folder_onedrive_path ?? $this->getDefaultLeadMovePath($createdDealMainFolder);
            $destinationFolderPath = $createdDealMainFolder->converted_lead_folder_onedrive_path ?? $createdDealMainFolder->folder_id;
            $destinationFolder = $this->oneDriveManageService->createFolder($destinationFolderPath, 'Archive');
            $this->oneDriveManageService->move($sourcePathId, $destinationFolder->getId());

            return true;
        } catch (\Exception $e) {
            Log::error('LeadToDealConversionService::moveConvertedLeadFilesToDeal()');
            Log::error($e->getMessage());
            return false;
        }
    }

    /*
   * Construct a data structure for the new deal from the webhook request data
   *
   * @param array $data
   *
   * @return array
   */
    public function constructDealInfo($data): array
    {
        return [
            'id' => $data['dealId'],
            'Deal_Name' => $data['dealName'],
            'Account_Name' => [
                'id' => $data['accountId'],
                'name' => $data['accountName'],
                'type' => 'Account_Name',
            ],
            'Contact_Name' => [
                'id' => $data['contactId'],
                'name' => $data['contactName'],
                'type' => 'Contact_Name',
            ],
            'Owner' => [
                'id' => $data['ownerId'],
                'name' => $data['ownerName'],
                'type' => 'Owner',
            ],
        ];
    }

    /*
    * Get default path for the lead files to move if no folder is specified in
    * the deal hierarchy folders tree
    *
    * @param App\Models\MainFolder $dealMainFolder
    *
    * @return string|boolean
    */
    public function getDefaultLeadMovePath($dealMainFolder)
    {
        try {
            return $this->oneDriveManageService->getFolderInfo($dealMainFolder->folder_id)->getId();
        } catch (\Exception $e) {
            Log::error("LeadToDealConversionService::getDefaultLeadMovePath()");
            Log::error($e->getMessage());
            return null;
        }
    }

}
