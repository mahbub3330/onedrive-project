<?php

namespace App\Services;

use App\Api\OneDriveApi;
use App\Models\User;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Kunnu\Dropbox\DropboxFile;

class OneDriveManageService
{
    protected $user;
    private $auth;
    protected $oneDriveApi;

    public function __construct(User $user)
    {
        $this->setUser($user);
        $this->setOneDriveApi(new OneDriveApi($user));
    }

    public function setUser($user)
    {
        $this->user = $user;
    }

    public function setOneDriveApi(OneDriveApi $oneDriveApi)
    {
        $this->oneDriveApi = $oneDriveApi;
    }

    public function getRootFolder()
    {
        $this->oneDriveApi->getRootFolder();
    }

    public function getFolderInfo($folderId)
    {
        return $this->oneDriveApi->getFolderInfo($folderId);
    }
    public function getFolderList($folderId)
    {
        return $this->oneDriveApi->getFolderList($folderId);
    }

    public function createFolder($parentFolderId, $folderName)
    {
        return $this->oneDriveApi->createFolder($parentFolderId, $folderName);
    }

    public function isFolderExists($folderId)
    {
        return $this->oneDriveApi->isFolderExists($folderId);
    }

    public function getFolderContents($folderId)
    {
        return $this->oneDriveApi->getFolderContents($folderId);
    }

    public function getPaginatedFolderContents($nextPage)
    {
        return $this->oneDriveApi->getPaginatedFolderContents($nextPage);
    }

    public function shareFile($itemId, $emails, $accessType, $shareMessage)
    {
        return $this->oneDriveApi->shareLink($itemId, $emails, $accessType, $shareMessage);
    }

    public function rename($itemId, $newName)
    {
        return $this->oneDriveApi->renameFolder($itemId, $newName);
    }

    public function delete($itemId)
    {
        return $this->oneDriveApi->deleteFolder($itemId);
    }

    public function move($itemId, $parentReferenceId)
    {
        return $this->oneDriveApi->moveItem($itemId, $parentReferenceId);
    }

    /*
    * Upload files inside a folder
    *
    * @param array $files
    * @param string $parentFolderId
    *
    * @return boolean
    */
    public function uploadFiles($files, $parentFolderId)
    {
        try {
            foreach ($files as $file) {
                $path = $file->store('files');
                $fullPath = storage_path('app/' . $path);
                $fileName = $file->getClientOriginalName();
                $this->oneDriveApi->uploadFile($fullPath, $fileName, $parentFolderId);

            }

            return true;
        } catch (\Exception $e) {
            Log::error('OneDriveManagerService::uploadFiles()');
            Log::error($e->getMessage());
            return false;
        }
    }

    public function deleteBatch($items)
    {
        try {
            return $this->oneDriveApi->batchDelete($items);
        } catch (\Exception $e) {
            Log::error('OneDriveManagerService::deleteBatch()');
            Log::error($e->getMessage());
            return false;
        }
    }

    public function moveBatch($parentReferenceId, $itemIds)
    {
        try {
            return $this->oneDriveApi->moveBatch($parentReferenceId, $itemIds);
        } catch (\Exception $e) {
            Log::error('OneDriveManagerService::moveBatch()');
            Log::error($e->getMessage());
            return false;
        }
    }


}
