<?php

namespace App\Services;

use App\Models\AccountOrContact;
use App\Models\HierarchyFolder;
use App\Models\MainFolder;
use App\Models\Template;
use App\Models\User;
use App\Repositories\AccountOrContactRepository;
use App\Repositories\MainFolderRepository;
use Illuminate\Support\Facades\Log;
use App\Services\OneDriveManageService;

class LeadModuleService
{
    /** @var UserService */
    protected UserService $userService;


    /** @var AccountOrContactRepository */
    protected AccountOrContactRepository $accountOrContactRepository;

    /** @var MainFolderRepository */
    protected MainFolderRepository $mainFolderRepository;

    /** @var array */
    protected array $hierarchyFolderIds = [];

    /** @var string */
    protected ?string $convertedLeadFolderOneDrivePath = null;

    /** @var MainFolder */
    protected array|MainFolder $mainFolder = [];

    /** @var OneDriveManageService */
    protected \App\Services\OneDriveManageService $oneDriveMangeService;

    /*
   * Constructor
   *
   * @param UserService $userService
   * @param AccountOrContactRepository $accountOrContactRepository
   * @param MainFolderRepository $mainFolderRepository
   *
   * @return void
   */
    public function __construct(UserService $userService, AccountOrContactRepository $accountOrContactRepository, MainFolderRepository $mainFolderRepository)
    {
        $this->userService = $userService;
        $this->accountOrContactRepository = $accountOrContactRepository;
        $this->mainFolderRepository = $mainFolderRepository;
    }

    /*
    * Create Leads folders from settings
    *
    * @param string $zapikey zapikey of the user
    * @param array $leadInfo
    * @param string|null $convertedLeadZohoID if it's a deal which is being converted from
    *                                           a deal then the zoho id of the lead that the deal is being converted from
    *
    * @return boolean
    */
    public function createFoldersFromSettings($zapikey, $leadInfo, $templateId, $convertedLeadZohoID = null): bool
    {
        try {

            $user = $this->userService->getByZapikey($zapikey)->first();
            $this->oneDriveMangeService = new OneDriveManageService($user);
            $existingParentFolderId = $this->getExistingParentFolderIdOfMainLeadFolder($user, $leadInfo);
            $newMainFolderName = $this->getNewFolderName($leadInfo);

            if ($existingParentFolderId) {
                $createdMainLeadFolder = $this->oneDriveMangeService->createFolder($existingParentFolderId, $newMainFolderName);
                $accountOrContact = $this->accountOrContactRepository->findOneByCondition(['folder_id' => $existingParentFolderId]);
            } else {
                $parentFolderCandidate = $this->getParentFolderCandidateInfoForMainLeadFolder($leadInfo);
                $dealRootFolderLocation = $this->getLeadRootFolderLocation($user);

                $createdParentFolderOfMainLeadFolder = $this->oneDriveMangeService->createFolder($dealRootFolderLocation, $parentFolderCandidate['name']);
                $accountOrContact = $this->accountOrContactRepository->updateOrCreateFromArray(
                    ['zoho_id' => $parentFolderCandidate['zohoId']],
                    [
                        'user_id' => $user->id,
                        'module_name' => 'leads',
                        'type' => $parentFolderCandidate['type'],
                        'zoho_id' => $parentFolderCandidate['zohoId'],
                        'folder_id' => $createdParentFolderOfMainLeadFolder->getId(),
                    ]
                );
                $createdMainLeadFolder = $this->oneDriveMangeService->createFolder($createdParentFolderOfMainLeadFolder->getId(), $newMainFolderName);
            }
            $this->createHierarchyFolderInsideLeadMainFolder($createdMainLeadFolder->getId(), $user, $templateId);

            $this->mainFolder = $this->mainFolderRepository->updateOrCreateFromArray(
                ['zoho_id' => $leadInfo['id']],
                [
                    'user_id' => $user->id,
                    'account_or_contact_id' => $accountOrContact->id,
                    'module_name' => 'leads',
                    'zoho_id' => $leadInfo['id'],
                    'folder_id' => $createdMainLeadFolder->getId(),
                    'hierarchy_folder_ids' => implode(',', $this->hierarchyFolderIds),
                    'converted_lead_folder_onedrive_path' => $this->convertedLeadFolderOneDrivePath,
                    'converted_lead_zoho_id' => $convertedLeadZohoID,
                    'folder_is_deleted' => false,
                ]
            );

            return true;
        } catch (\Exception $e) {
            throw $e;
            Log::error($e->getMessage());
            return false;
        }
    }

    /*
   * Create Deals folders from settings
   *
   * @param User $user
   * @param array $leadInfo
   *
   * @return string|null
   */
    public function getExistingParentFolderIdOfMainLeadFolder($user, $leadInfo)
    {
        try {
            $targetZohoFolderInfo = $this->getParentFolderCandidateInfoForMainLeadFolder($leadInfo);
            $location = null;
            $account = $user->accountOrContacts('leads')
                ->where(['zoho_id' => $targetZohoFolderInfo['zohoId'], 'folder_id' => null])
                ->first();

            if ($account) {
                if ($this->parentFolderDataIsValid($user, $account, $leadInfo)) {
                    $location = $account->folder_id;
                } else {
                    $this->accountOrContactRepository->updateFromArray($account, [
                        'folder_id' => null
                    ]);
                }
            }
        } catch (\Exception $e) {
            throw $e;
            Log::error($e->getMessage());
        }

        return $location;
    }

    /*
    * If the data in account or contact found for a record can be used
    *
    * @param User $user
    * @param AccountOrContact $account
    * @param array $leadInfo
    *
    * @return string|null
    */
    public function parentFolderDataIsValid(User $user, AccountOrContact $account, $leadInfo): bool
    {
        if (!$this->oneDriveMangeService->isFolderExists($account->folder_id)) {
            return false;
        }

        $parentFolder = $this->oneDriveMangeService->getFolderInfo($account->folder_id);

        if ($parentFolder['id'] !== $user->deal_root_folder_id) {
            return false;
        }

        return true;
    }

    /*
    * Get the info on the parent folder candidate of the new deal folder that will be created
    *
    * @param array $leadInfo
    *
    * @return array
    */
    public function getParentFolderCandidateInfoForMainLeadFolder($leadInfo): array
    {
        $candidateFields = ['Account_Name', 'account_name', 'Contact_Name', 'contact_name', 'Owner', 'owner', 'Company', 'company'];
        $targetFolderInfo = [];
        foreach ($candidateFields as $key => $candidate) {
            if (isset($leadInfo[$candidate]) && isset($leadInfo[$candidate]['id']) && isset($leadInfo[$candidate]['name'])) {
                $targetFolderInfo['name'] = $leadInfo[$candidate]['name'];
                $targetFolderInfo['zohoId'] = $leadInfo[$candidate]['id'];
                $targetFolderInfo['type'] = $candidate;
                break;
            }

            if ($key + 1 === count($candidateFields)) {
                $targetFolderInfo['name'] = 'Uncategorized';
                $targetFolderInfo['zohoId'] = 'uncategorized';
                $targetFolderInfo['type'] = 'lead_self';
            }
        }

        return $targetFolderInfo;
    }

    /*
    * Get the new Lead folder's name
    *
    * @param array $leadInfo
    *
    * @return string
    */
    public function getNewFolderName($leadInfo)
    {
        return $leadInfo['Full_Name'];
    }

    /*
   * Create hierarchy folders inside a deal main folder
   *
   * @param string $createdMainLeadFolderId
   * @param User $user
   *
   * @return void
   */
    public function createHierarchyFolderInsideLeadMainFolder($createdMainLeadFolderId, $user, $templateId): void
    {
        $hierarchyFolderTree = HierarchyFolder::getFoldersHierarchy($templateId);

        $this->createHierarchyFoldersRecursively($user, $createdMainLeadFolderId, $hierarchyFolderTree);
    }

    /*
    * Create hierarchy folders recursive under parent folder in dropbox
    *
    * @param User $user
    * @param string $parentId
    * @param array $tree
    *
    * @return boolean
    */
    public function createHierarchyFoldersRecursively($user, $parentId, $tree): bool
    {
        foreach ($tree as $folder) {
            $createdFolder = $this->oneDriveMangeService->createFolder($parentId, $folder['name']);
            $this->checkAndHandleIfFolderIsConvertedLeadLocationFolder($user, $folder, $createdFolder);
            $this->hierarchyFolderIds[] = $createdFolder->getId();
            $this->createHierarchyFoldersRecursively($user, $createdFolder->getId(), $folder['children']);
        }

        return true;
    }

    /*
    * Check if the created folder is the target where converted lead's files will be saved
    * & save it's path in the mainfolders data
    *
    * @param User $user
    * @param array $folder
    * @param Kunnu\Dropbox\Models\FolderMetadata $createdFolder
    *
    * @return void
    */
    public function checkAndHandleIfFolderIsConvertedLeadLocationFolder($user, $folder, $createdFolder): void
    {
        if ($folder['id'] === $user->converted_lead_target_folder_id) {
            $this->converted_lead_folder_onedrive_path = $createdFolder->getPathDisplay();
        }
    }

    /*
    * Get the main folder instance
    *
    *
    * @return MainFolder $mainFolder
    */
    public function getMainFolder(): MainFolder|array
    {
        return $this->mainFolder;
    }

    /*
    * Get lead root folder location
    *
    * @param User $user
    *
    * @return string
    */
    public function getLeadRootFolderLocation($user)
    {
        $leadRootFolderExists = $this->oneDriveMangeService->isFolderExists($user->lead_root_folder_id);

        if ($leadRootFolderExists) {
            $location = $user->lead_root_folder_id;
        } else {
            $location = 'root';
        }

        return $location;
    }


}
