<?php

namespace App\Services;

use App\Models\AccountOrContact;
use App\Models\HierarchyFolder;
use App\Models\MainFolder;
use App\Models\User;
use App\Repositories\AccountOrContactRepository;
use App\Repositories\MainFolderRepository;

class DealModuleService
{
    /** @var UserService */
    protected UserService $userService;


    /** @var AccountOrContactRepository */
    protected AccountOrContactRepository $accountOrContactRepository;

    /** @var MainFolderRepository */
    protected MainFolderRepository $mainFolderRepository;

    /** @var array */
    protected array $hierarchyFolderIds = [];

    /** @var string */
    protected ?string $convertedLeadFolderOneDrivePath = null;

    /** @var MainFolder */
    protected array|MainFolder $mainFolder = [];

    /** @var OneDriveManageService */
    protected \App\Services\OneDriveManageService $oneDriveMangeService;

    /*
   * Constructor
   *
   * @param UserService $userService
   * @param AccountOrContactRepository $accountOrContactRepository
   * @param MainFolderRepository $mainFolderRepository
   *
   * @return void
   */
    public function __construct(UserService $userService, AccountOrContactRepository $accountOrContactRepository, MainFolderRepository $mainFolderRepository)
    {
        $this->userService = $userService;
        $this->accountOrContactRepository = $accountOrContactRepository;
        $this->mainFolderRepository = $mainFolderRepository;
    }

    /*
    * Create Deals folders from settings
    *
    * @param string $zapikey zapikey of the user
    * @param array $dealInfo
    * @param string|null $convertedLeadZohoID if it's a deal which is being converted from
    *                                           a deal then the zoho id of the lead that the deal is being converted from
    *
    * @return boolean
    */
    public function createFoldersFromSettings($zapikey, $dealInfo, $templateId, $convertedLeadZohoID = null): bool
    {
        try {

            $user = $this->userService->getByZapikey($zapikey)->first();
            $this->oneDriveMangeService = new OneDriveManageService($user);
            $existingParentFolderId = $this->getExistingParentFolderIdOfMainDealFolder($user, $dealInfo);
            $newMainFolderName = $this->getNewFolderName($dealInfo);

            if ($existingParentFolderId) {
                $createdMainDealFolder = $this->oneDriveMangeService->createFolder($existingParentFolderId, $newMainFolderName);
                $accountOrContact = $this->accountOrContactRepository->findOneByCondition(['folder_id' => $existingParentFolderId]);
            } else {
                $parentFolderCandidate = $this->getParentFolderCandidateInfoForMainDealFolder($dealInfo);
                $dealRootFolderLocation = $this->getDealRootFolderLocation($user);

                $createdParentFolderOfMainDealFolder = $this->oneDriveMangeService->createFolder($dealRootFolderLocation, $parentFolderCandidate['name']);
                $accountOrContact = $this->accountOrContactRepository->updateOrCreateFromArray(
                    ['zoho_id' => $parentFolderCandidate['zohoId']],
                    [
                        'user_id' => $user->id,
                        'module_name' => 'deals',
                        'type' => $parentFolderCandidate['type'],
                        'zoho_id' => $parentFolderCandidate['zohoId'],
                        'folder_id' => $createdParentFolderOfMainDealFolder->getId(),
                    ]
                );
                $createdMainDealFolder = $this->oneDriveMangeService->createFolder($createdParentFolderOfMainDealFolder->getId(), $newMainFolderName);
            }
            $this->createHierarchyFolderInsideDealMainFolder($createdMainDealFolder->getId(), $user, $templateId);

            $this->mainFolder = $this->mainFolderRepository->updateOrCreateFromArray(
                ['zoho_id' => $dealInfo['id']],
                [
                    'user_id' => $user->id,
                    'account_or_contact_id' => $accountOrContact->id,
                    'module_name' => 'deals',
                    'zoho_id' => $dealInfo['id'],
                    'folder_id' => $createdMainDealFolder->getId(),
                    'hierarchy_folder_ids' => implode(',', $this->hierarchyFolderIds),
                    'converted_lead_folder_onedrive_path' => $this->convertedLeadFolderOneDrivePath,
                    'converted_lead_zoho_id' => $convertedLeadZohoID,
                    'folder_is_deleted' => false,
                ]
            );

            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /*
   * Create Deals folders from settings
   *
   * @param User $user
   * @param array $dealInfo
   *
   * @return string|null
   */
    public function getExistingParentFolderIdOfMainDealFolder($user, $dealInfo)
    {
        try {
            $targetZohoFolderInfo = $this->getParentFolderCandidateInfoForMainDealFolder($dealInfo);
            $location = null;
            $account = $user->accountOrContacts('deals')
                ->where(['zoho_id' => $targetZohoFolderInfo['zohoId'], 'folder_id' => null])
                ->first();

            if ($account) {
                if ($this->parentFolderDataIsValid($user, $account, $dealInfo)) {
                    $location = $account->folder_id;
                } else {
                    $this->accountOrContactRepository->updateFromArray($account, [
                        'folder_id' => null
                    ]);
                }
            }
        } catch (\Exception $e) {
            throw $e;
        }

        return $location;
    }

    /*
    * If the data in account or contact found for a record can be used
    *
    * @param User $user
    * @param AccountOrContact $account
    * @param array $dealInfo
    *
    * @return string|null
    */
    public function parentFolderDataIsValid(User $user, AccountOrContact $account, $dealInfo): bool
    {
        if (!$this->oneDriveMangeService->isFolderExists($account->folder_id)) {
            return false;
        }

        $parentFolder = $this->oneDriveMangeService->getFolderInfo($account->folder_id);

        if ($parentFolder['id'] !== $user->deal_root_folder_id) {
            return false;
        }

        return true;
    }

    /*
    * Get the info on the parent folder candidate of the new deal folder that will be created
    *
    * @param array $dealInfo
    *
    * @return array
    */
    public function getParentFolderCandidateInfoForMainDealFolder($dealInfo): array
    {
        $candidateFields = ['Account_Name', 'account_name', 'Contact_Name', 'contact_name', 'Owner', 'owner', 'Company', 'company'];
        $targetFolderInfo = [];
        foreach ($candidateFields as $key => $candidate) {
            if (isset($dealInfo[$candidate]) && isset($dealInfo[$candidate]['id']) && isset($dealInfo[$candidate]['name'])) {
                $targetFolderInfo['name'] = $dealInfo[$candidate]['name'];
                $targetFolderInfo['zohoId'] = $dealInfo[$candidate]['id'];
                $targetFolderInfo['type'] = $candidate;
                break;
            }

            if ($key + 1 === count($candidateFields)) {
                $targetFolderInfo['name'] = 'Uncategorized';
                $targetFolderInfo['zohoId'] = 'uncategorized';
                $targetFolderInfo['type'] = 'deal_self';
            }
        }

        return $targetFolderInfo;
    }

    /*
    * Get the new Deal folder's name
    *
    * @param array $dealInfo
    *
    * @return string
    */
    public function getNewFolderName($dealInfo)
    {
        return $dealInfo['Deal_Name'];
    }

    /*
   * Create hierarchy folders inside a deal main folder
   *
   * @param string $createdMainDealFolderId
   * @param User $user
   *
   * @return void
   */
    public function createHierarchyFolderInsideDealMainFolder($createdMainDealFolderId, $user, $templateId): void
    {
        $hierarchyFolderTree = HierarchyFolder::getFoldersHierarchy($templateId);

        $this->createHierarchyFoldersRecursively($user, $createdMainDealFolderId, $hierarchyFolderTree);
    }

    /*
    * Create hierarchy folders recursive under parent folder in dropbox
    *
    * @param User $user
    * @param string $parentId
    * @param array $tree
    *
    * @return boolean
    */
    public function createHierarchyFoldersRecursively($user, $parentId, $tree): bool
    {
        foreach ($tree as $folder) {
            $createdFolder = $this->oneDriveMangeService->createFolder($parentId, $folder['name']);
            $this->checkAndHandleIfFolderIsConvertedLeadLocationFolder($user, $folder, $createdFolder);
            $this->hierarchyFolderIds[] = $createdFolder->getId();
            $this->createHierarchyFoldersRecursively($user, $createdFolder->getId(), $folder['children']);
        }

        return true;
    }

    /*
    * Check if the created folder is the target where converted lead's files will be saved
    * & save it\'s path in the main folder\'s data
    *
    * @param User $user
    * @param array $folder
    * @param Kunnu\Dropbox\Models\FolderMetadata $createdFolder
    *
    * @return void
    */
    public function checkAndHandleIfFolderIsConvertedLeadLocationFolder($user, $folder, $createdFolder): void
    {
        if ($folder['id'] === $user->converted_lead_target_folder_id) {
            $this->convertedLeadFolderOneDrivePath = $createdFolder->getId();
        }
    }

    /*
    * Get the main folder instance
    *
    *
    * @return MainFolder $mainFolder
    */
    public function getMainFolder(): MainFolder|array
    {
        return $this->mainFolder;
    }

    /*
    * Get deal root folder location
    *
    * @param User $user
    *
    * @return string
    */
    public function getDealRootFolderLocation($user)
    {
        $dealRootFolderExists = $this->oneDriveMangeService->isFolderExists($user->deal_root_folder_id);

        if ($dealRootFolderExists) {
            $location = $user->deal_root_folder_id;
        } else {
            $location = 'root';
        }

        return $location;
    }


}
