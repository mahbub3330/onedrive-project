<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MainFolder extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'account_or_contact_id',
        'module_name',
        'zoho_id',
        'folder_id',
        'folder_is_deleted',
        'hierarchy_folder_ids',
        'converted_lead_folder_onedrive_path',
        'converted_lead_zoho_id',
    ];
}
