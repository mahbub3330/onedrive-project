<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HierarchyFolder extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'user_id',
        'parent_id',
        'template_id',
    ];

    public function parent()
    {
        return $this->belongsTo(HierarchyFolder::class, 'parent_id', 'id')->withDefault();
    }

    public function folders()
    {
        return $this->hasMany(HierarchyFolder::class, 'parent_id', 'id');
    }

    public static function test()
    {
       $templates = Template::query()->get();
       foreach ($templates as $template)
       {
           $template['hierarchy_folders'] = self::getFoldersHierarchy($template->id);
       }
       return $templates;
    }

    public static function getFoldersHierarchy($templateId)
    {
        $rootFolders = [];

        $allFolders  = HierarchyFolder::query()->where('template_id', $templateId)->get()->sortBy('parent_id')->values();
        if ($allFolders && $allFolders->isNotEmpty())
        {
            $rootFolders = $allFolders->whereNull('parent_id');

            self::formatHierarchy($rootFolders, $allFolders);
        }


        return $rootFolders;
    }

    private static function formatHierarchy($rootFolders, $allFolders)
    {
        foreach ($rootFolders as $folder) {
            $folder->children = $allFolders->where('parent_id', $folder->id)->values();

            if ($folder->children->isNotEmpty()) {
                self::formatHierarchy($folder->children, $allFolders);
            }
        }
    }

//    public static function getFoldersHierarchy()
//    {
//
//        $allFolders = HierarchyFolder::query()->get();
//
//        $rootFolders = $allFolders
//            ->whereNull('parent_id');
//
//        self::formatHierarchy($rootFolders, $allFolders);
//        return $rootFolders;
//    }
//
//    private static function formatHierarchy($rootFolders, $allFolders)
//    {
//        foreach ($rootFolders as $folder) {
//            $folder->children = $allFolders->where('parent_id', $folder->id)->values();
//
//            if ($folder->children->isNotEmpty()) {
//                self::formatHierarchy($folder->children, $allFolders);
//            }
//        }
//    }


}
