<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'zapikey',
        'access_token',
        'access_token_fetched_at',
        'expires_in',
        'refresh_token',
        'onedrive_id',
        'is_authorized',
        'picture',
        'deal_root_folder_id',
        'deal_root_folder_name',
        'lead_root_folder_id',
        'converted_lead_target_folder_id',
        'converted_lead_target_template_id',
        'converted_lead_target_folder_name',
        'lead_root_folder_name',
        'email_verified_at',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        'access_token',
        'refreshToken',
        'expires_in'
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function templates($moduleName = 'deals')
    {
        return $this->hasMany(Template::class, 'user_id', 'id')->where('module_name', $moduleName);
    }

    public function accountOrContacts($moduleName = 'deals')
    {
        return $this->hasMany(AccountOrContact::class)->where('module_name', $moduleName);
    }

    /*
    * A User has many MainFolders
    *
    * @param string|null $moduleName
    *
    * @return Illuminate\Database\Eloquent\Relations\HasMany
    */

    public function mainFolders($moduleName = null): HasMany
    {
        if (!$moduleName) {
            return $this->hasMany(MainFolder::class, 'user_id', 'id');
        } else {
            return $this->hasMany(MainFolder::class, 'user_id', 'id')->where('module_name', $moduleName);
        }
    }
}
