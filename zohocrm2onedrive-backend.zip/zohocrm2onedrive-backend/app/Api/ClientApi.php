<?php

namespace App\Api;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

class ClientApi
{
    private $client;

    public function __construct()
    {
        $this->setClient(new Client());
    }

    public function setClient($client)
    {
        $this->client = $client;

        return $this->client;
    }

    public function post($url, $action = 'POST', $options = [])
    {
        try {
            $res = $this->client->request($action, $url, $options);
        }catch (RequestException $e){
            if ($e->hasResponse()){
                $res = $e->getResponse();
            }else{
                throw new \Exception($e->getMessage());
            }
        }

        return new ClientApiResponse($res);
    }

}
