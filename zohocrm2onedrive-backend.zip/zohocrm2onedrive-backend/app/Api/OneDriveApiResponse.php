<?php

namespace App\Api;

class OneDriveApiResponse
{

}
