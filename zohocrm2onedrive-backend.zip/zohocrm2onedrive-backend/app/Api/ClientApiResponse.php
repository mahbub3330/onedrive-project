<?php

namespace App\Api;

use GuzzleHttp\Psr7\Response;

class ClientApiResponse
{
    protected $response;

    protected $result;

    protected $status;


    public function __construct(Response $response)
    {
        $this->setResponse($response);
    }

    public function setResponse(Response $response)
    {
        $this->response = $response;
        return $this;
    }

    private function getContents()
    {
        return json_decode($this->response->getBody()->getContents());
    }

    public function getResult()
    {
        return $this->getContents();
    }

    public function getStatus()
    {
        return $this->response->getStatusCode();
    }


}
