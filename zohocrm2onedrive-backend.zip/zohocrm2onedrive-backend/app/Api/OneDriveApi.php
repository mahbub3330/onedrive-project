<?php

namespace App\Api;

use App\Models\User;
use App\Services\OneDriveAuthenticationService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\File;
use Microsoft\Graph\Graph;

class OneDriveApi
{

    private $auth;
    private $graphApi;
    protected $baseUrl = "https://graph.microsoft.com/";
    protected $version = "v1.0";
    protected $response = null;

    public function __construct(User $user)
    {
        $this->setAuth(new OneDriveAuthenticationService($user));
        $this->setGraphApi(new Graph());
    }

    public function setAuth(OneDriveAuthenticationService $auth)
    {
        $this->auth = $auth;
        return $this;
    }

    public function setGraphApi(Graph $graph)
    {
        $this->graphApi = $graph;
        return $this;
    }

    public function setBaseUrl($baseUrl)
    {
        $this->baseUrl = $baseUrl;
    }

    public function setVersion($version)
    {
        $this->version = $version;
    }

    public function setApiBasic()
    {
        $this->graphApi->setBaseUrl($this->baseUrl)
            ->setApiVersion($this->version)
            ->setAccessToken($this->auth->getAccessToken());
        return $this;
    }


    public function getRootFolder($parentFolderId = 'roots')
    {
        $parentFolderId = "root";

        $this->setApiBasic();
        try {
            $res = $this->graphApi->createRequest("GET", "/me/drive/items/{$parentFolderId}/children")
                ->addHeaders(array("Content-Type" => "application/json"))
                ->setReturnType(\Microsoft\Graph\Model\DriveItem::class)
                ->setTimeout("1000")
                ->execute();
        } catch (\Exception $e) {
            $res = [
                'message' => $e->getMessage(),
                'status' => $e->getCode()
            ];
        }

        return $res;
    }

    public function getFolderInfo($folderId)
    {
        $this->setApiBasic();
        try {
            $res = $this->graphApi->createRequest("GET", "/me/drive/items/{$folderId}")
                ->addHeaders(array("Content-Type" => "application/json"))
                ->setTimeout("1000")
                ->setReturnType(\Microsoft\Graph\Model\DriveItem::class)
                ->execute();
        } catch (\Exception $e) {
            $res = [
                'message' => $e->getMessage(),
                'status' => $e->getCode()
            ];
        }

        return $res;
    }

    public function isFolderExists($folderId)
    {
        $this->setApiBasic();
        try {
            $res = $this->graphApi->createRequest("GET", "/me/drive/items/{$folderId}")
                ->addHeaders(array("Content-Type" => "application/json"))
                ->setTimeout("1000")
                ->execute();
            return $res->getStatus() == 200;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function deleteFolder($folderId)
    {
        $this->setApiBasic();
        try {
            $res = $this->graphApi->createRequest("DELETE", "/me/drive/items/{$folderId}")
                ->addHeaders(array("Content-Type" => "application/json"))
                ->setTimeout("1000")
                ->execute();
            return $res->getStatus() == 200;
        } catch (\Exception $e) {
            return false;
        }
    }


    public function shareLink($itemId, $emails, $accessType, $shareMessage)
    {
        $emailArray = [];
        foreach ($emails as $email) {
            $emailArray[] = ['email' => $email];
        }
        $recipients = collect($emailArray);
        $this->setApiBasic();
        $body = array(
            "requireSignIn" => true,
            "sendInvitation" => true,
            "roles" => [$accessType],
            "recipients" => $recipients,
            "message" => $shareMessage
        );


        try {
            $res = $this->graphApi->createRequest("POST", "/me/drive/items/{$itemId}/invite")
                ->attachBody(($body))
                ->setTimeout("1000")
                ->setReturnType(\Microsoft\Graph\Model\Event::class)
                ->execute();
        } catch (\Exception $e) {
            $res = [
                'message' => $e->getMessage(),
                'status' => $e->getCode()
            ];
        }

        return $res;
    }

    public function createLink($itemId)
    {
        $this->setApiBasic();
        $body = [
            "type" => "view",
            "scope" => "anonymous"
        ];

        try {
            $res = $this->graphApi->createRequest("POST", "/me/drive/items/{$itemId}/createLink")
                ->addHeaders(array("Content-Type" => "application/json"))
                ->attachBody(json_encode($body))
                ->setTimeout("1000")
                ->setReturnType(\Microsoft\Graph\Model\DriveItem::class)
                ->execute();
        } catch (\Exception $e) {
            $res = [
                'message' => $e->getMessage(),
                'status' => $e->getCode()
            ];
        }

        return $res;
    }

    public function moveItem($itemId, $parentReferenceId)
    {
        $this->setApiBasic();
        $body = [
            "@microsoft.graph.conflictBehavior" => "rename",
            "parentReference" => ["id" => $parentReferenceId]
        ];


        try {
            $res = $this->graphApi->createRequest("PATCH", "/me/drive/items/{$itemId}")
                ->addHeaders(array("Content-Type" => "application/json"))
                ->attachBody(json_encode($body))
                ->setTimeout("1000")
                ->setReturnType(\Microsoft\Graph\Model\DriveItem::class)
                ->execute();
        } catch (\Exception $e) {
            $res = [
                'message' => $e->getMessage(),
                'status' => $e->getCode()
            ];
        }
        return $res;
    }

    public function createFolder($parentFolderId, $folderName)
    {
        $this->setApiBasic();
        $url = "/me/drive/items/{$parentFolderId}/children";
        if ($parentFolderId == 'root') {
            $url = "/me/drive/{$parentFolderId}/children";
        }
        $body = [
            "name" => $folderName,
            "folder" => ["childCount" => 0],
            "@microsoft.graph.conflictBehavior" => "rename"
        ];

        try {
            $res = $this->graphApi->createRequest("POST", $url)
                ->addHeaders(array("Content-Type" => "application/json"))
                ->attachBody(json_encode($body))
                ->setReturnType(\Microsoft\Graph\Model\DriveItem::class)
                ->setTimeout("1000")
                ->execute();
        } catch (\Exception $e) {
            $res = [
                'message' => $e->getMessage(),
                'status' => $e->getCode()
            ];
        }
        return $res;
    }

    public function getFolderList($folderId)
    {
        $this->setApiBasic();
        try {
            $res = $this->graphApi->createRequest("GET", "/me/drive/items/{$folderId}/children")
                ->addHeaders(array("Content-Type" => "application/json"))
                ->setReturnType(\Microsoft\Graph\Model\DriveItem::class)
                ->setTimeout("1000")
                ->execute();
        } catch (\Exception $e) {
            $res = [
                'message' => $e->getMessage(),
                'status' => $e->getCode()
            ];
        }

        return $res;
    }

    public function renameFolder($itemId, $newName)
    {
        $this->setApiBasic();
//        $id = '01ORP54TSO4SP66Q4HVNEYQXWLCOMVARDP';
        $body = [
            "name" => $newName,
            "@microsoft.graph.conflictBehavior" => "rename"
        ];

        try {
            $res = $this->graphApi->createRequest("PATCH", "/me/drive/items/{$itemId}")
                ->addHeaders(array("Content-Type" => "application/json"))
                ->attachBody(json_encode($body))
                ->setTimeout("1000")
                ->setReturnType(\Microsoft\Graph\Model\DriveItem::class)
                ->execute();
        } catch (\Exception $e) {
            $res = [
                'message' => $e->getMessage(),
                'status' => $e->getCode()
            ];
        }

        return $res;
    }

    public function getFolderContents($folderId)
    {
        $this->setApiBasic();
        try {
            $res = $this->graphApi->createCollectionRequest("GET", "/me/drive/items/{$folderId}/children")
                ->addHeaders(array("Content-Type" => "application/json"))
                ->setPageSize(15);
            $res = $res->getPage();
        } catch (\Exception $e) {
            $res = [
                'message' => $e->getMessage(),
                'status' => $e->getCode()
            ];
        }

        return $res;
    }

    public function getPaginatedFolderContents($nextPage)
    {
        $this->setApiBasic();
        try {
            $res = $this->graphApi->createCollectionRequest("GET", $nextPage)
                ->addHeaders(array("Content-Type" => "application/json"));
            $res = $res->getPage();
        } catch (\Exception $e) {
            $res = [
                'message' => $e->getMessage(),
                'status' => $e->getCode()
            ];
        }

        return $res;
    }

    public function uploadFile($path, $fileName, $parentId)
    {
        $this->setApiBasic();
        // 1. create upload session
        $file = $path;
        $reqBody = [
            "@microsoft.graph.conflictBehavior" => "rename | fail | replace",
            "description" => "description",
            "fileSystemInfo" => ["@odata.type" => "microsoft.graph.fileSystemInfo"],
            "name" => $fileName,
            "item" => [
                "@microsoft.graph.conflictBehavior" => "rename",
            ]
        ];
        try {
            $uploadsession = $this->graphApi->createRequest("POST", "/me/drive/items/{$parentId}:/{$fileName}:/createUploadSession")
                ->attachBody($reqBody)
                ->setReturnType(\Microsoft\Graph\Model\UploadSession::class)
                ->execute();

            $handle = fopen($file, 'r');
            $fileSize = fileSize($file);
            $fileNbByte = $fileSize - 1;
            $chunkSize = 1024 * 1024 * 4;
            $fgetsLength = $chunkSize + 1;
            $start = 0;
            while (!feof($handle)) {
                $bytes = fread($handle, $fgetsLength);
                $end = $chunkSize + $start;
                if ($end > $fileNbByte) {
                    $end = $fileNbByte;
                }
                $res = $this->graphApi->createRequest("PUT", $uploadsession->getUploadUrl())
                    ->addHeaders([
                        'Content-Length' => ($end - 1) - $start,
                        'Content-Range' => "bytes " . $start . "-" . $end . "/" . $fileSize
                    ])
                    ->setReturnType(\Microsoft\Graph\Model\UploadSession::class)
                    ->attachBody($bytes)
                    ->execute();

                $start = $end + 1;
            }

            return $res;
        } catch (\Exception $exception) {
            return $exception->getMessage();
        }
    }

    public function batchDelete($items)

    {
        $this->setApiBasic();

        $request = $this->formatBatchDeleteRequest($items);


        try {
            ($this->graphApi
                ->createRequest("POST", "/\$batch")
                ->attachBody($request)
                ->setReturnType(\Microsoft\Graph\Model\DriveItem::class)
                ->execute());

            return true;
        } catch (\Exception $exception) {
//            return $exception->getMessage();
            return false;
        }
    }

    private function formatBatchDeleteRequest($items): array
    {
        $request = [];
        for ($i = 1; $i <= count($items); $i++) {
            $temp = [
                'id' => $i,
                'method' => 'DELETE',
                'url' => '/me/drive/items/' . $items[$i - 1]['id']
            ];

            $request[] = $temp;
        }
        return [
            'requests' => $request,
            'headers' => [
                'Content-Type' => 'application/json'
            ]
        ];
    }

    public function formatMoveBatchRequest($parentReferenceId, $items): array
    {
        $request = [];
        for ($i = 1; $i <= count($items); $i++) {
            $temp = [
                'id' => $i,
                'method' => 'PATCH',
                'url' => '/me/drive/items/' . $items[$i - 1],
                'headers' => [
                    'Content-Type' => 'application/json'
                ],
                'body' => [
                    "@microsoft.graph.conflictBehavior" => "rename",
                    "parentReference" => ["id" => $parentReferenceId]
                ]

            ];

            $request[] = $temp;
        }
        return [
            'requests' => $request,

        ];
    }

    public function moveBatch($parentReferenceId, $items): bool
    {
        $this->setApiBasic();

        $request = $this->formatMoveBatchRequest($parentReferenceId, $items);

        try {
            $response = ($this->graphApi
                ->createRequest("POST", "/\$batch")
                ->attachBody($request)
                ->setReturnType(\Microsoft\Graph\Model\DriveItem::class)
                ->execute());

            return true;
        } catch (\Exception $exception) {
//            return $exception->getMessage();
            return false;
        }
    }

}


