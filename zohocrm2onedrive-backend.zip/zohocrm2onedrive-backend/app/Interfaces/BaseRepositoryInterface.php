<?php

namespace App\Interfaces;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;

interface BaseRepositoryInterface
{

    /**
     * Get the count of all models
     *
     * @return int
     */
    public function count(): int;

    /**
     * Get Models according to queries
     * @param Request $request
     * @return  Collection
     */
    public function get(Request $request);

    /**
     * Get Paginated Models.
     * @param Request $request
     * @return LengthAwarePaginator
     */
    public function paginate(Request $request): LengthAwarePaginator;

    /**
     * Store a New Model.
     * @param Request $request
     * @return Model
     */
    public function store(Request $request): Model;

    /**
     * Update an existing model.
     * @param Model $model
     * @param Request $request
     * @return Model
     */

    public function update(Model $model, Request $request): Model;

    /**
     * @param Model $model
     * @return Model
     */
    public function show(Model $model): Model;

    /**
     * Delete model by primary key id.
     * @param Model $model
     * @return boolean
     */
    public function delete(Model $model): bool;
}
