<?php
namespace App\Interfaces;

interface UserRepositoryInterface extends BaseRepositoryInterface
{

}
