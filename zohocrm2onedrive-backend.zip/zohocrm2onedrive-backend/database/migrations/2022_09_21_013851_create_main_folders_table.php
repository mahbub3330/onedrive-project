<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('main_folders', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->unsignedBigInteger('account_or_contact_id')->nullable();
            $table->string('module_name')->nullable();
            $table->string('zoho_id')->nullable();
            $table->string('folder_id')->nullable();
            $table->boolean('folder_is_deleted')->default(false);
            $table->text('hierarchy_folder_ids')->nullable();
            $table->string('converted_lead_folder_onedrive_path')->nullable();
            $table->string('converted_lead_zoho_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('main_folders');
    }
};
