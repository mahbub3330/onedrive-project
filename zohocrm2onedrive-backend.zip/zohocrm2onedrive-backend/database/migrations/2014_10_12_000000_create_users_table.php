<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable(true);
            $table->string('email')->nullable(true);
            $table->string('zapikey', 255)->nullable(true);
            $table->text('access_token', 255)->nullable(true);
            $table->timestamp('access_token_fetched_at')->nullable(true);
            $table->string('expires_in')->nullable(true);
            $table->text('refresh_token', 255)->nullable(true);
            $table->string('onedrive_id')->nullable(true);
            $table->boolean("is_authorized")->default(false); // user has authorized his dropbox
            $table->string('picture')->nullable(true);

            $table->string('deal_root_folder_id')->default('root');
            $table->string('deal_root_folder_name')->default('Home');

            $table->string('lead_root_folder_id')->default('root');
            $table->string('lead_root_folder_name')->default('Home');

            $table->unsignedBigInteger('converted_lead_target_template_id')->nullable();
            $table->unsignedBigInteger('converted_lead_target_folder_id')->nullable();
            $table->string('converted_lead_target_folder_name')->nullable();

            $table->timestamp('email_verified_at')->nullable(true);
            $table->string('password')->nullable(true);
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
};
