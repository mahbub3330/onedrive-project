const colors = require('tailwindcss/colors')

module.exports = {
    content: ['./public/**/*.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
    theme: {
        colors: {
            transparent: 'transparent',
            current: 'currentColor',
            black: colors.black,
            white: colors.white,
            blue: colors.blue,
            green: colors.green,
            indigo: colors.indigo,
            slate: colors.slate,
            gray: colors.gray,
            yellow: colors.yellow,
            red: colors.red,
            orange: colors.orange,
            purple: colors.purple,
        },
        extend: {
            spacing: {
                128: '32rem',
                160: '40rem',
                192: '48rem',
            },
            gridTemplateColumns: {
                files: '30px 1fr 150px 100px 120px 110px',
            },
            transitionDuration: {
                25: '25ms',
                50: '50ms',
            },
            maxHeight: {
                '3/4': '75%',
            },
        },
        fontFamily: {
            sans: ['Lato', 'ui-sans-serif'],
        },
    },
    plugins: [],
}
