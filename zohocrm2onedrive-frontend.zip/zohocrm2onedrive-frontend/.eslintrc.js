module.exports = {
    root: true,
    env: {
        node: true,
    },
    parserOptions: {
        parser: "@babel/eslint-parser",
    },
    rules: {
        // indent: "off",
        "no-console": process.env.NODE_ENV === "production" ? "warn" : "off",
        "no-debugger": process.env.NODE_ENV === "production" ? "warn" : "off",
        "no-unused-vars": "off",
        "vue/multi-word-component-names": "off",
        "vue/no-unused-components": "off",
        "vue/no-v-model-argument": "off",
    },
    extends: [
        "plugin:vue/essential",
        // "eslint:recommended",
        // "@vue/prettier",
        "prettier",
    ],
};
