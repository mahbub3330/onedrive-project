import axios from 'axios'

const rootFolderOption = {
    "id": null,
    "name": "Parent Folder",
    "children": []
}

export default {
    namespaced: true,

    state: {
        folders: null,
        parentFoldersOptions: []
    },

    getters: {
        folders(state) {
            return state.folders;
        },
        parentFoldersOptions(state) {
            return state.parentFoldersOptions;
        }
    },

    mutations: {
        setFolders(state, payload) {
            state.folders = payload
        },
        setParentFoldersOptions(state, payload) {
            state.parentFoldersOptions = payload
        }
    },

    actions: {
        setFolders(context, payload) {
            context.commit('setFolders', payload)
        },
        async createFolder(context, payload) {
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/createHierarchyFolder`
            return await axios.post(link, payload).then((response) => {
            }).catch(err => console.log(err))
        },
        async deleteFolder(context, payload) {
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${payload}/deleteFolder`
            return await axios.delete(link).then((response) => {
            }).catch(err => console.log(err))
        },
        async updateParentId(context, payload){
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${payload['folderId']}/updateParentId`
            return await axios.post(link, payload['data']).then((response) => {
            }).catch(err => console.log(err))
        },

        async getParentFolders(context, payload) {
            return await axios.get(`${process.env.VUE_APP_BACKEND_API_URL}/api/getHierarchyFolders/${payload}`)
                .then((res) => {
                    this.parentFolders = res.data;
                    this.parentFolders.unshift(rootFolderOption)
                    context.commit('setParentFoldersOptions', this.parentFolders)
                }).catch(err => console.log(err))
        },

    },
}
