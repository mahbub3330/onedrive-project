export default {
    namespaced: true,

    state: {
        selectedOption: {
            name: null,
            id: null
        },
        show: false
    },

    getters: {
        selectedOption(state){
            return state.selectedOption
        },
        show(state){
            return state.show
        }
    },
    mutations: {
        setSelectedOption(state, payload){
            state.selectedOption = payload;
        },
        setShow(state, payload){
            state.show = payload;
        }
    }
}