import axios from 'axios'

export default {
    namespaced: true,

    state: {
        dealZoho: {},
        dealFolderInfo: {},
        dealCurrentFolderContents: {
            entries: [],
            cursor: null,
            has_more: null,
        },
    },

    getters: {
        dealZoho(state) {
            return state.dealZoho
        },
        dealFolderInfo(state) {
            return state.dealFolderInfo
        },
        dealCurrentFolderContents(state) {
            return state.dealCurrentFolderContents
        },
    },

    mutations: {
        setDealZoho(state, payload) {
            state.dealZoho = payload
        },
        setDealFolderInfo(state, payload) {
            state.dealFolderInfo = payload
        },
        setDealCurrentFolderContents(state, payload) {
            state.dealCurrentFolderContents.entries = payload.value.sort((a, b) => {
                if (a['.tag'] == b['.tag']) {
                    return a.name.localeCompare(b.name)
                } else {
                    return a['.tag'] == 'folder' ? -1 : 1
                }
            })
            state.dealCurrentFolderContents.cursor = payload['@odata.nextLink']
            state.dealCurrentFolderContents.has_more = !!payload['@odata.nextLink']
        },
        mergeAdditionalLoadedFolderContents(state, payload) {
            state.dealCurrentFolderContents.entries = [
                ...state.dealCurrentFolderContents.entries,
                ...payload.value.sort((a, b) => {
                    if (a['.tag'] == b['.tag']) {
                        return a.name.localeCompare(b.name)
                    } else {
                        return a['.tag'] == 'folder' ? -1 : 1
                    }
                }),
            ]
            state.dealCurrentFolderContents.cursor = payload['@odata.nextLink']
            state.dealCurrentFolderContents.has_more = payload['@odata.nextLink']
        },
    },

    actions: {
        async fetchDealZoho(context, payload) {
            await ZOHO.CRM.API.getRecord({
                Entity: 'Deals',
                RecordID: payload,
            }).then((response) => {
                context.dispatch('setDealZoho', response.data[0])
            })
        },
        async fetchDealFolderInfo(context, payload) {
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload}`
            var params = {
                moduleName: 'deals',
            }
            await axios
                .get(link, { params })
                .then((res) => {
                    context.dispatch('setDealFolderInfo', res.data.mainFolder.data)
                })
                .catch((e) => {
                    if (e.response.status == 404) {
                        context.dispatch('setDealFolderInfo', {})
                    }
                })
        },
        async createDealFoldersFromSettings(context, payload) {
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/createDealFoldersFromSettings`
            var data = {
                deal: context.getters.dealZoho,
                templateId: payload
            }

            return await axios.post(link, data).then(() => {})
        },
        async fetchFolderContents(context, payload) {
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload.zohoId}/getFolderContents`
            var params = {
                moduleName: 'deals',
                folderId: payload.folderId,
            }

            return await axios.get(link, { params }).then((r) => {
                context.commit('setDealCurrentFolderContents', r.data)
                return r.data
            })
        },
        async fetchParentFolderContents(context, payload) {
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload.zohoId}/getParentFolderContents`
            var params = {
                moduleName: 'deals',
                folderId: payload.folderId,
            }

            return await axios.get(link, { params }).then((r) => {
                context.commit('setDealCurrentFolderContents', r.data.contents)
                return r.data
            })
        },
        async fetchFolderContentForDeals(context, payload) {
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload.zohoId}/getFolderContents`
            var params = {
                moduleName: payload.moduleName,
                folderId: payload.folderId,
            }

            return await axios.get(link, { params }).then((r) => {
                return r.data
            })
        },
        async loadMoreContents(context, payload) {
            const params = {
                moduleName: 'deals',
                cursor: payload.cursor,
                folderId: payload.folderId,
            }
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload.zohoId}/getPaginatedFolderContents`
            return await axios.get(link, { params }).then((r) => {
                context.commit('mergeAdditionalLoadedFolderContents', r.data)
                return r.data
            })
        },
        async loadMoreContentsForModal(context, payload) {
            const params = {
                moduleName: payload.moduleName,
                cursor: payload.cursor,
                folderId: payload.folderId,
            }
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload.zohoId}/getPaginatedFolderContents`
            return await axios.get(link, { params }).then((r) => {
                return r.data
            })
        },
        setDealZoho(context, payload) {
            context.commit('setDealZoho', payload)
        },
        setDealFolderInfo(context, payload) {
            context.commit('setDealFolderInfo', payload)
        },
        async createFolder(context, payload) {
            const data = {
                parentFolderId: payload.parentFolderId,
                folderName: payload.folderName,
            }
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload.zohoId}/createFolder`
            return await axios.post(link, data).then((r) => {
                return r.data
            })
        },
        async shareContent(context, payload) {
            const params = {
                moduleName: 'deals',
                emails: payload.emails,
                shareMessage: payload.shareMessage,
                content: payload.content,
                accessType: payload.accessType,
            }
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload.zohoId}/shareContent`
            return await axios.get(link, { params }).then((r) => {
                return r.data
            })
        },
        async renameContent(context, payload) {
            const data = {
                newName: payload.newName,
                content: payload.content,
            }
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload.zohoId}/renameContent`
            return await axios.post(link, data).then((r) => {
                return r.data
            })
        },
        async moveContent(context, payload) {
            const data = {
                itemId: payload.itemId,
                parentId: payload.parentId,
            }
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload.zohoId}/moveContent`
            return await axios.post(link, data).then((r) => {
                return r.data
            })
        },
        async moveContentsBatch(context, payload) {
            const data = {
                parentId: payload.parentId,
                itemIds: payload.itemIds
            }
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload.zohoId}/moveContentsBatch`
            return await axios.post(link, data).then((r) => {
                return r.data
            })
        },
        async deleteContent(context, payload) {
            const data = {
                content: payload.content,
            }
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload.zohoId}/deleteContent`
            return await axios.post(link, data).then((r) => {
                return r.data
            })
        },
        async deleteContentsBatch(context, payload) {
            const data = {
                entries: payload.entries,
            }
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload.zohoId}/deleteContentsBatch`
            return await axios.post(link, data).then((r) => {
                return r.data
            })
        },
        async uploadFiles(context, payload) {
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/mainFolders/${payload.zohoId}/uploadFiles`

            let data = new FormData()

            for (var i = 0; i < payload.filelist.length; i++) {
                data.append('files[]', payload.filelist[i])
            }
            data.append('parentFolderId', payload.parentFolderId)

            let config = {
                header: {
                    'content-type': 'multipart/form-data',
                },
            }

            return await axios.post(link, data, config).then((r) => {
                return r.data
            })
        },
    },
}
