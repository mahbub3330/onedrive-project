import axios from 'axios'

export default {
    namespaced: true,

    state: {
        templates: [],
        module_name: 'deals'
    },

    getters: {
        templates(state) {
            return state.templates
        },
        moduleName(state){
            return state.module_name;
        }
    },

    mutations: {
        setTemplates(state, payload) {
            state.templates = payload
        },
        setModuleName(state, payload){
            state.module_name = payload
        }
    },

    actions: {
        setTemplates(context, payload) {
            context.commit('setTemplates', payload)
        },
        setModuleName(context, payload) {
            context.commit('setModuleName', payload)
        },
        async fetchTemplates(context, payload) {
            return await axios.get(`${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/getTemplates`, {
                params: {module_name: payload.moduleName}
            })
                .then((res) => {
                    context.commit("setTemplates", res.data)
                }).catch(err => console.log(err))
        },


        async setDealRootFolder(context, payload) {
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/setDealRootFolder`
            await axios
                .post(link, {
                    folderId: payload.folderId,
                    folderName: payload.folderName,
                })
                .then((res) => {
                    context.dispatch('fetchUser')
                })
        },
        async setLeadRootFolder(context, payload) {
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/setLeadRootFolder`
            await axios
                .post(link, {
                    folderId: payload.folderId,
                    folderName: payload.folderName,
                })
                .then((res) => {
                    context.dispatch('fetchUser')
                })
        },
    },
}
