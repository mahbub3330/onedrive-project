import axios from 'axios'

export default {
    namespaced: true,

    state: {
        selectedFolderToMove: null,
        selectedTemplateForLeadConversion: null
    },

    getters: {
        selectedFolderToMove(state) {
            return state.selectedFolderToMove
        },
        selectedTemplateForLeadConversion(state) {
            return state.selectedTemplateForLeadConversion;
        }
    },

    mutations: {
        setSelectedFolderToMove(state, payload) {
            state.selectedFolderToMove = payload
        },
        setSelectedTemplateForLeadConversion(state, payload) {
            state.selectedTemplateForLeadConversion = payload
        }
    },

    actions: {
        async setConvertedLeadsLocation(context, payload) {
            const data = {
                folderId: payload.folderId,
                templateId: payload.templateId
            }
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${context.rootGetters['zoho/zapikey']}/setConvertedLeadsLocation`
            return await axios.post(link, data).then((r) => {
                return r.data
            })
        },
        setSelectedFolderToMove(context, payload) {
            context.commit('setSelectedFolderToMove', payload)
        },
        setSelectedTemplateForLeadConversion(context, payload){
            context.commit('setSelectedTemplateForLeadConversion', payload)
        }
    },
}
