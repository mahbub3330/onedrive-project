import {createStore}  from "vuex";
import pluginUser from "@/store/modules/pluginUserStore";
import zoho from "@/store/modules/zohoStore";
import oneDrive from "@/store/modules/oneDriveStore";
import template from "@/store/modules/templateStore";
import nestedSelectedOption from "@/store/modules/nestedSelectedOptionStore";
import hierarchyFolder from "@/store/modules/hierarchyFolderStore";
import leadConversion from "@/store/modules/leadConversionStore";
import deal from "@/store/modules/dealStore";
import lead from "@/store/modules/leadStore";
export default createStore({
    modules:
        {
            pluginUser,
            zoho,
            oneDrive,
            template,
            nestedSelectedOption,
            hierarchyFolder,
            leadConversion,
            deal,
            lead
        }
})