import {createRouter, createWebHistory} from "vue-router";
/* eslint-disable */
import Test from "@/views/Test";
import settings from "@/views/Settings";
import OneDriveAuthSuccess from "@/views/OneDriveAuthSuccess";

const routes = [
    {
        path: "/settings",
        name: "settings",
        component: settings
    },
    {
        path:"/onedriveauth/success",
        name: "onedriveauth.success",
        component: OneDriveAuthSuccess
    },
    {
        path: "/deals-widget",
        name: "widgets.deals",
        component: () => import("../views/Deals/Widget.vue"),
    },
    {
        path: "/leads-widget",
        name: "widgets.leads",
        component: () => import("../views/Leads/Widget.vue"),
    },
    {
        path: "/test",
        name: "test",
        component: Test
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

export default router;