<template>
    <div
        class="fixed top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
        :class="{
            'opacity-0 invisible pointer-events-none scale-75': !isVisible,
        }"
    >
        <div class="px-10 py-5 bg-white rounded-lg ring-2 w-160">
            <div class="flex items-center mt-2 mb-4 ml-2">
                <slot name="title">Share "{{ content ? content.name : '' }}" {{ contentType }}</slot>
            </div>
            <div class="flex items-center gap-2">
                <div :class="contentType == 'file' ? 'w-full' : 'w-3/4'" class="border-2">
                    <span class="border border-gray-600 rounded-md mr-2 my-0.5 px-2 py-0 inline-block"
                          v-for="(email, index) in emails" :key="email">
                        <span class="mr-1">{{ email }}</span>
                        <button class="text-red-300 hover:text-red-900" @click="deleteEmail(index)">x</button>
                    </span>
                    <input
                        ref="emailInput"
                        v-model="email"
                        type="text"
                        placeholder="example@gmail.com"
                        @keyup.space="addEmail"
                        @keyup.ctrl.v="addEmail"
                        @keyup.enter="addEmail"
                        class="ml-2 focus:outline-none"
                    />
                </div>
                <div class="w-1/4" v-if="contentType == 'folder'">
                    <app-select :options="getAccessTypes()" v-model:selectedOption="selectedAccessType">
                        <template v-slot:title>{{ selectedAccessType.label }}</template>
                    </app-select>
                </div>

            </div>
            <div v-if="emailNullError" class="flex items-center text-red-500 mt-2 mb-4 ml-2">Email Can't be empty!</div>
            <div class="flex items-center mt-2">
                <input class="w-full pl-1 border-2" type="string" v-model="shareMessage"
                       placeholder="Custom message..."/>
            </div>

            <div v-if="!sharingInProgress" class="flex gap-2 justify-center mt-2">
                <button @click="shareButtonClicked"
                        class="w-1/2 px-4 text-sm font-semibold text-white bg-green-500 border-2 border-green-500 shadow leading-6 rounded-md hover:bg-green-600">
                    Share {{ contentType }}
                </button>
                <button @click="cancelled"
                        class="w-1/2 px-4 text-sm font-semibold text-white bg-blue-500 border-2 border-blue-500 shadow leading-6 rounded-md hover:bg-blue-600">
                    Cancel
                </button>
            </div>

            <div v-if="sharingInProgress" class="flex justify-center mt-4">
                <loading paddingClass="px-3 py-1" bgColorClass="bg-gray-400">Sharing...</loading>
            </div>
        </div>

        <div
            class="fixed z-10 top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
            :class="{
                'opacity-0 invisible pointer-events-none scale-75': !showSharingSuccessMessage,
            }"
        >
            <div class="px-10 py-5 bg-white rounded-lg ring-2 w-96">
                <div class="flex items-center mt-2 mb-4 ml-2 text-center">
                    {{ 'The ' + contentType + ' has been shared.' }}
                </div>
                <div class="flex justify-center mt-2">
                    <button
                        @click="okButtonOfSuccessDialogueClicked"
                        class="w-1/4 px-4 text-sm font-semibold text-white bg-green-500 border-2 border-green-500 shadow leading-6 rounded-md hover:bg-green-600 transition ease-in-out duration-150"
                    >
                        Ok
                    </button>
                </div>
            </div>
        </div>

        <div
            class="fixed z-10 top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
            :class="{
                'opacity-0 invisible pointer-events-none scale-75': !showErrorModal,
            }"
        >
            <div class="px-10 py-5 bg-white rounded-lg ring-2 w-96">
                <div class="flex items-center text-red-500 mt-2 mb-4 ml-2">Sharing Failed! Please Try again.</div>
                <div class="flex justify-center mt-2">
                    <button
                        @click="okButtonOfErrorModalClicked"
                        class="w-1/4 px-4 text-sm font-semibold text-white bg-gray-500 border-2 border-green-500 shadow leading-6 rounded-md transition ease-in-out duration-150"
                    >
                        Ok
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import {mapGetters} from 'vuex'
import Loading from '@/components/Loading.vue'
import AppSelect from '@/components/AppSelect.vue'
import utils from '@/utils'

export default {
    name: 'components.shareContentModal',
    components: {
        Loading,
        AppSelect,
    },
    props: {
        isVisible: {
            type: Boolean,
            default: false,
        },
        content: {
            type: Object,
            required: true,
        },
        recordZohoId: {
            type: String,
            required: true,
        },
    },
    data: () => ({
        email: null,
        emails: [],
        shareMessage: null,
        selectedAccessType: {label: 'Viewer', id: "read"},
        // showInvalidEmailMessage: false,
        showSharingSuccessMessage: false,
        sharingInProgress: false,
        showErrorModal: false,
        emailNullError: false
    }),
    computed: {
        ...mapGetters({}),
        contentType() {
            return this.content ? this.content['.tag'] : ''
        },
    },
    watch: {
        isVisible(v) {
            if (v) {
                setTimeout(() => {
                    this.$refs.emailInput.focus()
                }, 100)
            }
        },
    },
    mounted() {
        this.init()
    },
    methods: {
        init() {
        },
        getAccessTypes() {
            if (this.content && this.content['.tag'] == 'folder') {
                return [{label: 'Viewer', id: 'read'}, {label: 'Editor', id: 'write'}]
            } else {
                return [{label: 'Viewer', id: 'read'}]
            }
        },
        async shareButtonClicked() {
            if (this.email && utils.isValidEmail(this.email.trim())) {
                this.emails.push(this.email.trim())
                this.email = null
            }

            // this.sharingInProgress = true


            if (  !(this.emails!= null && this.emails.length > 0) ) {
                this.emailNullError = true
                return 0;
            }
            this.emailNullError = false
            const payload = {
                zohoId: this.recordZohoId,
                emails: this.emails,
                shareMessage: this.shareMessage,
                content: this.content.id,
                accessType: this.selectedAccessType.id,
            }
            await this.$store
                .dispatch('deal/shareContent', payload)
                .then(() => {
                    this.showSharingSuccessMessage = true
                    this.sharingInProgress = false
                })
                .catch(() => {
                    this.sharingInProgress = false
                    this.showErrorModal = true
                })


        },
        addEmail() {
            if (utils.isValidEmail(this.email.trim())) {
                this.emails.push(this.email.trim())
                this.email = null
                this.$refs.emailInput.focus()
            } else {
                this.email = this.email.trim()
            }
        },
        deleteEmail(idx) {
            this.emails.splice(idx, 1)
            this.$refs.emailInput.focus()
        },
        cancelled() {
            this.$emit('update:isVisible', false)
            this.resetData()
        },
        okButtonOfSuccessDialogueClicked() {
            this.resetData()
            this.$emit('update:isVisible', false)
            this.$emit('shareSucceeded', this.content)
        },
        okButtonOfErrorModalClicked() {
            this.resetData()
            this.$emit('update:isVisible', false)
            this.$emit('shareFailed', this.content)
        },
        resetData() {
            this.email = null
            this.emails = []
            this.shareMessage = null
            this.selectedAccessType = {label: 'Viewer', id: 'read'}
            // this.showInvalidEmailMessage = false
            this.showSharingSuccessMessage = false
            this.sharingInProgress = false
            this.showErrorModal = false
        },
    },
}
</script>
