<template>
    <div
        class="fixed top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
        :class="{
            'opacity-0 invisible pointer-events-none scale-75': !isVisible,
        }"
    >
        <div class="px-10 py-5 bg-white rounded-lg ring-2 max-h-3/4 overflow-auto">
            <div class="flex items-center mt-2 mb-4 ml-2">
                <slot name="title">Upload Files</slot>
            </div>
            <div class="flex w-full items-center justify-center text-center">
                <div class="p-12 bg-gray-100 border border-gray-300" @dragover="dragover" @dragleave="dragleave" @drop="drop">
                    <input type="file" multiple name="fields[files][]" id="files" class="w-px h-px opacity-0 overflow-hidden absolute" ref="file" @input="onChange" />

                    <label for="files" class="block cursor-pointer">
                        <div>Drop your Files here <span class="text-red-400">(Max 150MB)</span></div>
                    </label>
                    <ul class="mt-4" v-if="filelist.length" v-cloak>
                        <li class="text-sm p-1" :class="{ 'text-red-500': exceedsSizeLimit(file) }" v-for="file in filelist" :key="file">
                            {{ file.name }} - ({{ bytesToSize(file.size) }})<button
                                class="ml-2 px-2 py-1 border-2 rounded-md text-white"
                                :class="{ 'bg-red-400': exceedsSizeLimit(file), 'bg-gray-500': !exceedsSizeLimit(file) }"
                                type="button"
                                @click="remove(filelist.indexOf(file))"
                                title="Remove file"
                            >
                                Remove
                            </button>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="flex justify-center">
                <p v-if="largeFileDragged" class="mt-4 text-red-500">Please remove the file(s) that exceeds 150MB size</p>
            </div>

            <div v-if="!uploadingInProgress" class="flex gap-2 justify-center mt-2">
                <button
                    v-if="!largeFileDragged && filelist.length"
                    @click="uploadButtonClicked"
                    class="w-1/2 px-4 text-sm font-semibold text-white bg-green-500 border-2 border-green-500 shadow leading-6 rounded-md hover:bg-green-600 transition ease-in-out duration-150"
                >
                    Upload File(s)
                </button>
                <button
                    @click="cancelled"
                    class="w-1/2 px-4 text-sm font-semibold text-white bg-blue-500 border-2 border-blue-500 shadow leading-6 rounded-md hover:bg-blue-600 transition ease-in-out duration-150"
                >
                    Cancel
                </button>
            </div>
            <div v-if="uploadingInProgress" class="flex justify-center mt-4">
                <loading paddingClass="px-3 py-1" bgColorClass="bg-gray-400">Uploading File(s)...</loading>
            </div>
        </div>
        <div
            class="fixed z-10 top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
            :class="{
                'opacity-0 invisible pointer-events-none scale-75': !showErrorModal,
            }"
        >
            <div class="px-10 py-5 bg-white rounded-lg ring-2 w-96">
                <div class="flex items-center text-red-500 mt-2 mb-4 ml-2">Upload Failed! Please Try again.</div>
                <div class="flex justify-center mt-2">
                    <button
                        @click="okButtonOfErrorModalClicked"
                        class="w-1/4 px-4 text-sm font-semibold text-white bg-gray-500 border-2 border-green-500 shadow leading-6 rounded-md transition ease-in-out duration-150"
                    >
                        Ok
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped>
[v-cloak] {
    display: none;
}
</style>

<script>
import Loading from '@/components/Loading.vue'
import utils from '@/utils'

export default {
    name: 'components.uploadFiles',
    components: {
        Loading,
    },
    props: {
        isVisible: {
            type: Boolean,
            default: false,
        },
        parentFolderId: {
            type: String,
            required: true,
        },
        recordZohoId: {
            type: String,
            required: true,
        },
    },
    data: () => ({
        filelist: [], // Store our uploaded files
        uploadingInProgress: false,
        showErrorModal: false,
    }),
    computed: {
        largeFileDragged() {
            var result = false
            this.filelist.forEach((i) => {
                if (this.exceedsSizeLimit(i)) result = true
            })
            return result
        },
    },
    methods: {
        onChange() {
            this.filelist = [...this.$refs.file.files]
        },
        exceedsSizeLimit(file) {
            return file.size > 150 * 1024 * 1024
        },
        bytesToSize(bytes) {
            return utils.bytesToSize(bytes)
        },
        remove(i) {
            this.filelist.splice(i, 1)
            this.$refs.file.value = ''
        },
        dragover(event) {
            event.preventDefault()
            // Add some visual fluff to show the user can drop its files
            if (!event.currentTarget.classList.contains('bg-green-300')) {
                event.currentTarget.classList.remove('bg-gray-100')
                event.currentTarget.classList.add('bg-green-300')
            }
        },
        dragleave(event) {
            // Clean up
            event.currentTarget.classList.add('bg-gray-100')
            event.currentTarget.classList.remove('bg-green-300')
        },
        drop(event) {
            event.preventDefault()
            this.$refs.file.files = event.dataTransfer.files
            this.onChange() // Trigger the onChange event manually
            // Clean up
            event.currentTarget.classList.add('bg-gray-100')
            event.currentTarget.classList.remove('bg-green-300')
        },
        async uploadButtonClicked() {
            this.uploadingInProgress = true
            var payload = {
                zohoId: this.recordZohoId,
                filelist: this.filelist,
                parentFolderId: this.parentFolderId,
            }

            await this.$store
                .dispatch('deal/uploadFiles', payload)
                .then(() => {
                    // this.filelist = []
                    this.uploadingInProgress = false
                    this.$emit('update:isVisible', false)
                    this.$emit('uploadSucceeded')
                })
                .catch(() => {
                    this.uploadingInProgress = false
                    this.showErrorModal = true
                })
            this.resetData()
        },
        cancelled() {
            this.$emit('update:isVisible', false)
            this.resetData()
        },
        okButtonOfErrorModalClicked() {
            this.showErrorModal = false
            this.$emit('update:isVisible', false)
            this.$emit('uploadFailed', this.content)
        },
        resetData() {
            this.filelist = []
            this.$refs.file.value = ''
        },
    },
}
</script>
