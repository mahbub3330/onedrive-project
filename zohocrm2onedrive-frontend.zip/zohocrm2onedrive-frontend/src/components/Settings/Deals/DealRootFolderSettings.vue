<template>
    <div>
        <div class="flex flex-row justify-between">
            <div class="w-1/3 flex gap-2 items-center">
                <app-label>Deals Location:</app-label>
                <Popper
                    content="Default location will choose the 'Home' as the root location whereas Custom location will allow the user to choose folder location as per the business requirements where all the Accounts/Contacts folders will be created."
                    :hover="true"
                >
                    <ion-icon class="w-5 h-5 text-blue-900 pt-2" name="information-circle-outline"></ion-icon>
                </Popper>
            </div>
            <div class="w-2/3">
                <app-input :value="pluginUser.deal_root_folder_name" :disabled="true"></app-input>
            </div>
        </div>

        <div v-if="!pluginUserAdditionalInfo['dealRootFolderExists']" class="flex flex-row justify-between">
            <div class="w-1/3"></div>
            <div class="w-2/3">
                <p class="text-xs text-red-500">Default deal folder moved or deleted from drive, please select again.</p>
            </div>
        </div>

        <div class="flex flex-row justify-between mt-2">
            <div class="w-1/3"></div>
            <div class="w-2/3">
                <button
                    type="button"
                    class="inline-flex items-center px-4 py-1 text-sm font-semibold text-white bg-blue-500 shadow leading-6 rounded-md hover:bg-blue-600 transition ease-in-out duration-150"
                    @click.prevent="chooseRootLocationClicked"
                >
                    Choose Custom Location
                </button>
            </div>
        </div>

        <!-- Root Folder Chooser -->
        <module-root-folder-chooser
            v-model:isVisible="showChooseRootFolderDialogueBox"
            :folderId="pluginUserAdditionalInfo['dealRootFolderExists'] ? pluginUser.deal_root_folder_id : 'root'"
            :folderName="pluginUserAdditionalInfo['dealRootFolderExists'] ? pluginUser.deal_root_folder_name : 'Home'"
            @folderChosen="dealRootFolderChosen"
            moduleName="Deals"
        >
            <template v-slot:title> Choose Deal Custom Folder </template>
        </module-root-folder-chooser>
        <!-- end:Root Folder Chooser -->
    </div>
</template>

<script>
import axios from 'axios'
import AppLabel from '@/components/AppLabel.vue'
import AppInput from '@/components/AppInput.vue'
import ModuleRootFolderChooser from '@/components/ModuleRootFolderChooser.vue'
import Popper from 'vue3-popper'

import { mapGetters } from 'vuex'
export default {
    name: 'components.dealRootFolderSettings',
    components: {
        AppLabel,
        AppInput,
        ModuleRootFolderChooser,
        Popper,
    },
    data: () => ({
        showChooseRootFolderDialogueBox: false,
    }),
    computed: {
        ...mapGetters({
            userIsAdmin: 'zoho/isAdmin',
            zapikey: 'zoho/zapikey',
            pluginUser: 'pluginUser/user',
            pluginUserAdditionalInfo: 'pluginUser/additionalInfo',
        }),
    },
    mounted() {},
    methods: {
        chooseRootLocationClicked() {
            this.showChooseRootFolderDialogueBox = true
        },
        dealRootFolderChosen(e) {
            const payload = {
                folderId: e.folderId,
                folderName: e.folderName,
            }
            this.$store.dispatch('pluginUser/setDealRootFolder', payload)
        },
    },
}
</script>
