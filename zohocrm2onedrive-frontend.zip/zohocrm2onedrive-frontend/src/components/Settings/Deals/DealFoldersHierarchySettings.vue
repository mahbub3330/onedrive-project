<template>
    <div class="mt-4">
        <div>
            <button
                class="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
                @click.prevent="openHierarchyDialogueBox = true"
            >
                Add Hierarchy Template
            </button>
            <hierarchy-template
                v-model:is-visible="openHierarchyDialogueBox"
                :module-name="moduleName"
                @fetchTemplates="fetchTemplates"
                @storeTemplate="createTemplate"
                :form="templateForm"
            />

        </div>
        <div class="flex gap-2 items-center mt-4">
            <app-label>Client Template & Hierarchy Management:</app-label>
            <Popper
                content="Provide the folder template which will be created for each Deal folder in OneDrive."
                :hover="true"
            >
                <ion-icon class="w-5 h-5 text-blue-900 pt-2" name="information-circle-outline"></ion-icon>
            </Popper>
        </div>

        <div class="mt-4">
            <accordion v-for="template in templates" :title="template.name" @deleteItem="deleteItem(template.id)"
                       @editItem="editItem(template.id)">
                <div class="mt-4">
                    <hierarchy-folders
                        :fetchingHetchHierarchyFoldersTree="fetchingHetchHierarchyFoldersTree"
                        :hierarchyFoldersTree="template.hierarchy_folders"
                        :template="template"
                        @setHierarchyFoldersTree="setHierarchyFoldersTree"
                    ></hierarchy-folders>
                </div>
            </accordion>
            <div v-if="!templates.length" class="flex justify-center mt-6">
                <p class="text-red-500">No Template Created! Please Add Hierarchy Template</p>
            </div>
        </div>
    </div>
</template>

<script>
import AppLabel from '@/components/AppLabel.vue'
import HierarchyFolders from '@/components/HierarchyFolders.vue'
import {mapGetters, mapState} from 'vuex'
import Popper from 'vue3-popper'
import HierarchyTemplate from "@/components/HierarchyTemplate";
import axios from "axios";
import Accordion from "@/components/Accordion";

const forms = {
    id: null,
    name: null,
    module_name: 'deals'
}
export default {
    name: 'components.dealFoldersHierarchySettings',
    components: {
        AppLabel,
        HierarchyFolders,
        Popper,
        HierarchyTemplate,
        Accordion
    },
    data: () => ({
        fetchingHetchHierarchyFoldersTree: false,
        openHierarchyDialogueBox: false,
        // templates: [],
        active: null,
        templateForm: {...forms},
    }),
    watch: {},
    computed: {
        ...mapGetters({
            zapikey: 'zoho/zapikey',
            templates: 'template/templates',
            moduleName: 'template/moduleName'
        }),
    },
   async mounted() {
        await this.fetchTemplates()
    },
    methods: {
        async init() {
            // await this.fetchHetchHierarchyFoldersTree()
        },
        async fetchTemplates() {
            await this.$store
                .dispatch('template/fetchTemplates', {
                    moduleName: this.moduleName,
                })
        },
        createTemplate(data) {
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${this.zapikey}/createTemplate`
            axios.post(link, data).then((response) => {
                this.templateForm = {...forms}
                this.fetchTemplates()
            }).catch(err => console.log(err))
        },

        deleteItem(id) {
            var link = `${process.env.VUE_APP_BACKEND_API_URL}/api/users/${id}/deleteTemplate`
            axios.delete(link).then((response) => {
                this.templateForm = {...forms}
                this.fetchTemplates()
            }).catch(err => console.log(err))
        },

        editItem(id) {
            let item = this.templates.find(val => val.id === id)
            this.templateForm = {...this.templateForm, name: item.name, id: item.id}
            this.openHierarchyDialogueBox = true
        },

        async fetchHetchHierarchyFoldersTree() {
            this.fetchingHetchHierarchyFoldersTree = true
            await this.$store
                .dispatch('hierarchyFolders/fetchHierarchyFoldersTree', {
                    moduleName: 'deals',
                })
                .then(() => {
                    this.fetchingHetchHierarchyFoldersTree = false
                })
        },
        async setHierarchyFoldersTree(foldersTree) {
            this.$store
                .dispatch('hierarchyFolders/setHierarchyFoldersTree', {
                    moduleName: 'deals',
                    foldersTree: foldersTree,
                })
                .then(() => {
                    this.$store.dispatch('pluginUser/fetchUser')
                })
        },
    },
}
</script>
