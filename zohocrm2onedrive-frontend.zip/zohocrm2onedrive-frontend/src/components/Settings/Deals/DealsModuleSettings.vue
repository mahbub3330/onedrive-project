<template>
    <div>
        <deal-root-folder-settings> </deal-root-folder-settings>
        <deal-folders-hierarchy-settings></deal-folders-hierarchy-settings>
    </div>
</template>

<script>
import DealRootFolderSettings from "@/components/Settings/Deals/DealRootFolderSettings.vue";
import DealFoldersHierarchySettings from "@/components/Settings/Deals/DealFoldersHierarchySettings.vue";
export default {
    name: "components.dealsModuleSettings",
    components: {
        DealRootFolderSettings,
        DealFoldersHierarchySettings,
    },
};
</script>
