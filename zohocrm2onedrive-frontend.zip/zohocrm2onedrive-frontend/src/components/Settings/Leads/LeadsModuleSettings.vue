<template>
    <div>
        <lead-root-folder-settings> </lead-root-folder-settings>
        <converted-lead-location-settings></converted-lead-location-settings>
        <lead-folders-hierarchy-settings></lead-folders-hierarchy-settings>
    </div>
</template>

<script>
import LeadRootFolderSettings from '@/components/Settings/Leads/LeadRootFolderSettings.vue'
import ConvertedLeadLocationSettings from '@/components/Settings/Leads/ConvertedLeadLocationSettings.vue'
import LeadFoldersHierarchySettings from '@/components/Settings/Leads/LeadFoldersHierarchySettings.vue'
export default {
    name: 'components.leadsModuleSettings',
    components: {
        LeadRootFolderSettings,
        LeadFoldersHierarchySettings,
        ConvertedLeadLocationSettings,
    },
}
</script>
