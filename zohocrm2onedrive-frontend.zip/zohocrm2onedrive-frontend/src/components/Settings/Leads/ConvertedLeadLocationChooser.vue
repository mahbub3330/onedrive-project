<template>
    <div
        class="fixed z-10 top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
        :class="{
            'opacity-0 invisible pointer-events-none scale-75': !isVisible,
        }"
    >
        <div class="p-2 bg-white rounded-lg ring-2 w-128">
            <div class="px-4">
                <div class="grid place-items-left">
                    <h2 class="text-lg">
                        <slot>Template Name</slot>
                    </h2>
                </div>
                <div class="">
                    <select class="w-full px-2 py-1 border-2 rounded"
                            @change="fetchFolders($event)">
                        <option disabled value="">Please select one</option>
                        <option v-for="option in dealTemplateOptions" :selected="pluginUser.converted_lead_target_template_id == option.id" :value="option.id">{{ option.name }}</option>
                    </select>
                </div>
                <div v-if="selectedTemplateForLeadConversion" class="grid place-items-left">
                    <h2 class="text-lg">
                        <slot>Folder Name</slot>
                    </h2>
                </div>
                <nested-selectable-folder-node :folders="folders"></nested-selectable-folder-node>
            </div>

            <div class="flex gap-2 justify-center mt-4">
                <button
                    @click="submitButtonClicked"
                    class="w-1/2 px-4 text-sm font-semibold text-white bg-green-500 border-2 border-green-500 shadow leading-6 rounded-md hover:bg-green-600 transition ease-in-out duration-150"
                >
                    Submit
                </button>
                <button
                    @click="cancelled"
                    class="w-1/2 px-4 text-sm font-semibold text-white bg-blue-500 border-2 border-blue-500 shadow leading-6 rounded-md hover:bg-blue-600 transition ease-in-out duration-150"
                >
                    Cancel
                </button>
            </div>
        </div>
    </div>
</template>

<script>
import NestedSelectableFolderNode from '@/components/NestedSelectableFolderNode.vue'
import {mapState, mapGetters} from 'vuex'
import axios from "axios";

export default {
    name: 'components.convertedLeadLocationChooser',
    components: {
        NestedSelectableFolderNode,
    },
    data: () => ({
        dealTemplateOptions: [],
        selectedTemplateId: null,
        folders: []
    }),
    computed: {
        // ...mapState({
        //     hierarchyFoldersTree: (state) => state.hierarchyFolders.hierarchyFoldersTree.deals,
        // }),
        ...mapGetters({
            selectedFolderToMove: 'leadConversion/selectedFolderToMove',
            pluginUser: 'pluginUser/user',
            zapikey: 'zoho/zapikey',
        }),
        selectedTemplateForLeadConversion: {
            get() {
                return this.$store.state.leadConversion.selectedTemplateForLeadConversion
            },
            set(v) {
                this.$store.state.leadConversion.selectedTemplateForLeadConversion = v
            },
        },
    },
    props: {
        isVisible: {
            type: Boolean,
            default: false,
        },
    },
    watch: {
        isVisible(v) {
            if (v) {
                this.$store.dispatch('leadConversion/setSelectedFolderToMove', this.pluginUser.converted_lead_target_folder_id)
            }
        },
        // selectedTemplateForLeadConversion(val) {
        //     this.templateWiseFolder(val)
        // }
    },
    async mounted() {
        await this.fetchDealTemplates()
        this.templateWiseFolder(this.pluginUser.converted_lead_target_template_id)
        this.selectedTemplateId = this.pluginUser.converted_lead_target_template_id

    },
    methods: {
        cancelled() {
            this.$emit('update:isVisible', false)
        },
        submitButtonClicked() {
            this.$emit('update:isVisible', false)
            this.$store
                .dispatch('leadConversion/setConvertedLeadsLocation', {
                    folderId: this.selectedFolderToMove,
                    templateId: this.selectedTemplateId
                })
                .then(async () => {
                    await this.$store.dispatch('pluginUser/fetchUser')
                })
        },
        async fetchDealTemplates() {
            await axios.get(`${process.env.VUE_APP_BACKEND_API_URL}/api/users/${this.zapikey}/fetchDealTemplateOptions`, {
                params: {'module_name': 'deals'}
            }).then((res) => {
                this.dealTemplateOptions = res.data
            }).catch(err => console.log('err', err))
        },
        fetchFolders(event) {
            this.selectedTemplateId = event.target.value;
            this.templateWiseFolder(event.target.value)
        },

        templateWiseFolder(templateId) {
            axios.get(`${process.env.VUE_APP_BACKEND_API_URL}/api/getHierarchyFolders/${templateId}`).then((res) => {
                this.folders = res.data
            }).catch(err => console.log('err', err))
        }
    },
}
</script>
