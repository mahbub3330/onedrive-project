<template>
    <div class="my-4">
        <div class="flex flex-row justify-between">
            <div class="w-1/3 flex gap-2 items-center">
                <app-label>Converted Lead Location:</app-label>
                <Popper
                    content='Choose the location from the Deal hierarchy folders where the "Leads" folder will be migrated with all the subfolders. If nothing is chosen then "Archives" folder will be created directly under the Deal folder.'
                    :hover="true"
                >
                    <ion-icon class="w-5 h-5 text-blue-900 pt-2" name="information-circle-outline"></ion-icon>
                </Popper>
            </div>
            <div class="w-2/3">
                <app-input :value="pluginUser.converted_lead_target_folder_name" :disabled="true"></app-input>
            </div>
        </div>

        <div class="flex flex-row justify-between mt-2">
            <div class="w-1/3"></div>
            <div class="w-2/3">
                <button
                    type="button"
                    class="inline-flex items-center px-4 py-1 text-sm font-semibold text-white bg-blue-500 shadow leading-6 rounded-md hover:bg-blue-600 transition ease-in-out duration-150"
                    @click.prevent="chooseConvertedLeadsLocationClicked"
                >
                    Choose Converted Leads Location
                </button>
            </div>
        </div>

        <!-- Root Folder Chooser -->
        <converted-lead-location-chooser  v-model:isVisible="showConvertedLeadLocationDialogueBox" moduleName="Leads">
            <template v-slot:title> Choose Converted Lead Files Location</template>
        </converted-lead-location-chooser>
        <!-- end:Root Folder Chooser -->
    </div>
</template>

<script>
import AppLabel from '@/components/AppLabel.vue'
import AppInput from '@/components/AppInput.vue'
import ConvertedLeadLocationChooser from '@/components/Settings/Leads/ConvertedLeadLocationChooser.vue'
import Popper from 'vue3-popper'
import { mapGetters } from 'vuex'
export default {
    name: 'components.convertedLeadLocationSettings',
    components: {
        AppLabel,
        AppInput,
        Popper,
        ConvertedLeadLocationChooser,
    },
    data: () => ({
        showConvertedLeadLocationDialogueBox: false,
    }),
    computed: {
        ...mapGetters({
            pluginUser: 'pluginUser/user',
        }),
    },
    methods: {
        chooseConvertedLeadsLocationClicked() {
            this.showConvertedLeadLocationDialogueBox = true
        },
        convertedLeadLocationChosen() {},
    },
}
</script>
