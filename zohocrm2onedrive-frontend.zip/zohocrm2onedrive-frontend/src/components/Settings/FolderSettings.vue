<template>
    <div>
        <!-- Tabs for switching between Deals & Leads Module settings components -->
        <div>
            <app-tabs :tabList="tabList" @tabChanged="tabChanged" activeBgColorClass="bg-gray-400" activeBorderClass="border-gray-400"> </app-tabs>
        </div>

        <!-- component selected by the tab -->
        <section class="pt-8">
            <Transition name="fade" mode="out-in">
                <component :is="currentTabComponent"></component>
            </Transition>
        </section>
    </div>
</template>

<script>
import AppTabs from '@/components/AppTabs.vue'
import DealsModuleSettings from '@/components/Settings/Deals/DealsModuleSettings.vue'
import LeadsModuleSettings from '@/components/Settings/Leads/LeadsModuleSettings.vue'
import { mapGetters } from 'vuex'

export default {
    name: 'components.folderSettings',
    components: {
        AppTabs,
        DealsModuleSettings,
        LeadsModuleSettings,
    },
    data: () => ({
        currentTabComponent: 'DealsModuleSettings',
        tabList: [
            { text: 'Deals Module', component: 'DealsModuleSettings', name: "deals" },
            { text: 'Leads Module', component: 'LeadsModuleSettings', name: "leads" },
        ],
    }),
    computed: {
        ...mapGetters({
            zapikey: 'zoho/zapikey',
            pluginUser: 'pluginUser/user',
        }),
    },
    mounted() {},
    methods: {
        async tabChanged(e) {
            await this.setModuleName(e.tab.name)
            this.currentTabComponent = e.tab.component
        },
        async setModuleName(module) {
            await this.$store.dispatch('template/setModuleName', module)
        },
    },
}
</script>
