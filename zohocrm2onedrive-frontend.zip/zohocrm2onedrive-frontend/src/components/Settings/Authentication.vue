<template>
  <div>
    <div class="flex flex-row justify-between text-gray-700">
      <div>
        <div v-if="!pluginUser.is_authorized" class="flex gap-2 items-center">
          <h3 class="text-lg text-gray-700 font-bold">Authorize OneDrive</h3>
          <Popper content="Click the 'Authorize OneDrive' button to authorize your currently logged in OneDrive account." :hover="true">
            <ion-icon class="w-5 h-5 text-blue-900 pt-2" name="information-circle-outline"></ion-icon>
          </Popper>
        </div>
        <h3 v-else class="text-lg text-gray-700 font-bold">OneDrive Info</h3>
        <p v-if="!pluginUser.is_authorized" class="mt-1 text-gray-600 text-sm">Please authorize your OneDrive Account for using the plugin</p>
        <p v-else class="mt-1 text-gray-600 text-sm">Your OneDrive Account Info</p>
      </div>
      <div v-if="pluginUser.picture" class="w-12 h-12 overflow-hidden bg-gray-200 rounded-full">
        <img :src="pluginUser.picture" />
      </div>
    </div>

    <div class="flex">
      <div class="w-1/3"></div>
      <div v-if="pluginUser.is_authorized" class="flex text-green-600 mt-2 mb-5">
        <p class="flex items-center">
          <ion-icon class="w-5 h-5 text-md" name="checkmark-outline"></ion-icon>
          Authorized with <i>"{{ pluginUser.email }}"</i>
        </p>
      </div>
    </div>

    <template v-if="pluginUser.is_authorized">
      <div class="flex flex-row justify-between">
        <div class="w-1/3">
          <app-label>Full Name</app-label>
        </div>
        <div class="w-2/3">
          <app-input :value="pluginUser.name" :disabled="true"></app-input>
        </div>
      </div>

      <div class="flex flex-row justify-between mt-4">
        <div class="w-1/3">
          <app-label>Email</app-label>
        </div>
        <div class="w-2/3">
          <app-input :value="pluginUser.email" :disabled="true"></app-input>
        </div>
      </div>
    </template>

    <div v-if="!pluginUser.id" class="flex justify-center mt-2">
      <loading paddingClass="px-3 py-1" bgColorClass="bg-gray-400">Processing...</loading>
      <!-- <p class="ml-4">Fetching Folders...</p> -->
    </div>
    <div v-if="pluginUser.id && !pluginUser.is_authorized" class="flex flex-row mt-8 gap-4">
      <a
          class="block px-4 py-2 text-center bg-gray-300 hover:bg-gray-500 border-2 border-gray-300 hover:border-gray-500 hover:text-white rounded-lg w-52"
          target="_blank"
          href="#"
          @click.prevent="handleAuthClick"
      >
        Authorize OneDrive
      </a>
    </div>

    <div v-if="pluginUser.is_authorized" class="flex flex-row mt-5">
      <div class="w-1/3"></div>
      <a class="block px-4 py-2 text-center bg-white border-2 border-gray-500 rounded-lg w-36 hover:bg-gray-500 hover:text-white" href="#" @click.prevent="handleRevokeClick"> Revoke </a>
    </div>

    <!-- Overlay for checking if user has authorized the app from dropbox -->
    <div v-if="authenticating" class="fixed top-0 left-0 flex items-center justify-center w-screen h-screen bg-slate-300">
      <loading>Authenticating...</loading>
    </div>
    <!-- end:Overlay for checking if user has authorized the app from dropbox -->

    <!-- Confirmation box for revoking token -->
    <y-n-dialogue :isVisible="showRevokeConfirmation" @yesClicked="revokeConfirmed" @noClicked="revokeCanceled">Do you want to revoke your OneDrive Permissions?</y-n-dialogue>
  </div>
</template>

<script>
import AppLabel from '@/components/AppLabel.vue'
import AppInput from '@/components/AppInput.vue'
import Loading from '@/components/Loading.vue'
import YNDialogue from '@/components/YNDialogue.vue'
import Popper from 'vue3-popper'
import axios from 'axios'
import { mapGetters } from 'vuex'

export default {
  name: 'components.authentication',
  components: {
    AppLabel,
    AppInput,
    Loading,
    YNDialogue,
    Popper,
  },
  data() {
    return {
      authenticating: false,
      showRevokeConfirmation: false,
    }
  },
  computed: {
    ...mapGetters({
      zapikey: 'zoho/zapikey',
      pluginUser: 'pluginUser/user',
    }),
    authUrl() {
      return process.env.VUE_APP_BACKEND_API_URL + '/' + 'onedriveauth' + '/' + this.zapikey
    },
  },
  methods: {
    handleAuthClick() {
      // open onedriveauth page
      this.authenticating = true
      window.open(this.authUrl)

      // check and reload page if onedriveauth page asks to reload current window
      localStorage.setItem('reloadPage', false)
      setInterval(() => {
        var reloadPage = JSON.parse(localStorage.getItem('reloadPage'))
        if (reloadPage == true) {
          localStorage.setItem('reloadPage', false)
          this.authenticating = false
          window.location.reload()
        }
      }, 1000)
    },

    handleRevokeClick() {
      this.showRevokeConfirmation = true
    },

    revokeConfirmed() {
      this.$store.dispatch('zoho/revokeToken')
      this.showRevokeConfirmation = false
    },

    revokeCanceled() {
      this.showRevokeConfirmation = false
    },
  },
  mounted() {},
}
</script>
