<template>
    <div
        class="fixed z-10 top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
        :class="{
            'opacity-0 invisible pointer-events-none scale-75': !isVisible,
        }"
    >
        <div class="p-2 bg-white rounded-lg ring-2 w-128">
            <div class="grid place-items-center">
                <h2 class="text-lg">
                    <slot name="title">Choose Folder</slot>
                </h2>
            </div>
            <div class="flex items-center mt-2 mb-4 ml-2">
                <ion-icon v-if="currentFolderId !== 'root'" @click="goToParentFolder" class="w-6 h-6"
                          name="arrow-back-outline"></ion-icon>
                &nbsp;
                <img class="inline w-7 h-7 mr-1" src="@/assets/img/db-folder.png"/>
                {{ currentFolderName }}
            </div>

            <div class="px-2 pb-2">
                <input v-model="searchTerm" class="w-full px-2 py-1 border-2 rounded" type="text"
                       placeholder="Search folder by name"/>
            </div>
            <div class="px-2 py-2 max-h-96 overflow-auto">
                <ul class="flex flex-col gap-2">
                    <li class="flex items-center gap-4">
                        <p class="font-bold">#</p>
                        <p class="font-bold">Folder(s)</p>
                        <button v-if="addingFolder" class="px-2 ml-auto mr-2 text-white bg-gray-400 rounded-full"
                                @click="addFolderCanceled">Cancel
                        </button>
                        <button v-else class="px-2 ml-auto mr-2 text-white bg-gray-400 rounded-full"
                                @click="addingFolder = true">Add Folder
                        </button>
                    </li>
                    <li v-if="addingFolder" class="flex">
                        <input class="w-2/3 px-2 border-2 rounded" type="text" v-model="addFolderName"
                               @keyup.enter="addFolderConfirmed"/>
                        <button class="w-1/4 px-2 ml-auto text-white bg-green-500 rounded-full"
                                @click="addFolderConfirmed">Confirm
                        </button>
                    </li>

                    <li class="flex items-center mb-2 gap-4"
                        v-if="currentFolderId == 'root' && 'onedrive home'.includes(searchTerm.toLowerCase())">
                        <input type="radio" value="root" v-model="selectedFolderId"/>
                        <p class="flex items-center gap-1">
                            <span>
                                <img class="inline w-8 h-8 scale-110" src="@/assets/img/db-folder-main.png"/>
                            </span>
                            OneDrive Home
                        </p>
                    </li>

                    <li v-for="folder in folderListFilter"
                        :key="folder.id" class="flex items-center gap-4">
                        <input type="radio" :value="folder.id" v-model="selectedFolderId"/>
                        <p :class="['flex', 'items-center',((folder.folder.childCount && folder.folder.childCount > 0) ? 'cursor-pointer gap-1' : '')]"
                           @click="folderClicked(folder)">
                            <span>
                                <img class="inline w-7 h-7" src="@/assets/img/db-folder.png"/>
                            </span>
                            {{ folder.name }}
                        </p>

                    </li>
                    <li v-if="fetchingFolderList" class="flex justify-center">
                        <loading paddingClass="px-3 py-1" bgColorClass="bg-gray-400">Fetching...</loading>
                        <!-- <p class="ml-4">Fetching Folders...</p> -->
                    </li>
                </ul>
            </div>

            <div v-if="!fetchingFolderList" class="flex justify-center px-2 py-2 gap-4">
                <button @click="folderChosen" :disabled="!selectedFolderId"
                        class="px-4 py-1 text-white bg-green-400 rounded-md"
                        :class="{ 'cursor-not-allowed': !selectedFolderId }">Submit
                </button>

                <button class="px-4 py-1 text-gray-700 bg-white ring-1 ring-inset ring-gray-700 rounded-md"
                        @click="modalCancelled">Cancel
                </button>
            </div>
        </div>
    </div>
</template>

<script>
import {mapGetters} from 'vuex'
import Loading from '@/components/Loading.vue'

export default {
    name: 'components.moduleRootFolderChooser',
    components: {
        Loading,
    },
    props: {
        isVisible: {
            type: Boolean,
            default: false,
        },
        folderId: {
            type: String,
            required: true,
        },
        folderName: {
            type: String,
            required: true,
        },
        moduleName: {
            type: String,
            default: 'Deals',
        }
    },

    watch: {
        'isVisible': function (status) {
            if (status === true) {
                this.init()
            }
        }
    },
    data: () => ({
        searchTerm: '',
        selectedFolderId: null,
        folderList: [],
        fetchingFolderList: false,
        currentFolderId: '',
        currentFolderName: '',
        addingFolder: false,
        addFolderName: '',
        parentReference: false
    }),
    computed: {
        ...mapGetters({
            zapikey: 'zoho/zapikey',
        }),
        folderListFilter(){
            return this.folderList.filter((val) => val.name.toLowerCase().includes(this.searchTerm.toLowerCase()))
        },
    },

    methods: {
        init() {
            this.currentFolderId = this.folderId
            this.currentFolderName = this.folderName
            this.selectedFolderId = this.folderId
            this.getFolderList(this.folderId)
        },

        async getFolderList(folderId) {
            this.folderList = []
            this.fetchingFolderList = true
            await this.$store
                .dispatch('oneDrive/fetchFolderList', {
                    folderId: folderId,
                    zapikey: this.zapikey,
                })
                .then((res) => {
                    if (!res.data['status']) {
                        this.folderList = res.data.filter(val => "folder" in val)
                    }
                    this.fetchingFolderList = false
                    this.parentReference = false
                })
        },

        folderClicked(folder) {
            if (folder.folder.childCount > 0) {
                this.currentFolderId = folder.id
                this.currentFolderName = folder.name;
                this.getFolderList(folder.id)
            }
        },

        async goToParentFolder() {
            this.parentReference = true
            let parentId = this.folderList.length > 0 ?this.folderList[0].parentReference.id : this.folderId;
            await this.fetchCurrentFolderInfo(parentId)
        },

        async fetchParentFolderInfo(folderId) {
            this.fetchingFolderList = true;
            await this.$store
                .dispatch('oneDrive/fetchFolderInfo', {
                    folderId: folderId,
                    zapikey: this.zapikey,
                })
                .then((res) => {
                    this.currentFolderId = res.data.name == 'root' ? 'root' : res.data.id
                    this.currentFolderName = res.data.name == 'root' ? 'Home' : res.data.name
                    this.getFolderList(res.data.id)
                    if (!this.parentReference) this.fetchingFolderList = false
                })
        },

        async fetchCurrentFolderInfo(folderId) {
            this.fetchingFolderList = true;
            await this.$store
                .dispatch('oneDrive/fetchFolderInfo', {
                    folderId: folderId,
                    zapikey: this.zapikey,
                })
                .then((res) => {
                    if (res.data.name !== 'root')this.fetchParentFolderInfo(res.data.parentReference.id)
                    if (!this.parentReference) this.fetchingFolderList = false
                })
        },

        addFolderConfirmed() {
            this.$store
                .dispatch('oneDrive/createFolder', {
                    parentFolderId: this.currentFolderId,
                    folderName: this.addFolderName,
                    zapikey: this.zapikey,
                })
                .then((res) => {
                    this.addFolderName = ''
                    this.addingFolder = false
                    this.getFolderList(this.currentFolderId)
                }).catch(err => console.log('err', err))
        },

        addFolderCanceled() {
            this.addingFolder = false
            this.addFolderName = ''
        },

        folderChosen() {
            var chosenFolderData = {
                folderId: this.selectedFolderId,
                folderName: null,
            }
            chosenFolderData.folderName = this.folderList.find((i) => i.id === this.selectedFolderId)?.name
            if (this.selectedFolderId === 'root') {
                chosenFolderData.folderName = 'Home'
            }
            this.$emit('folderChosen', chosenFolderData)
            this.$emit('update:isVisible', false)
        },

        modalCancelled() {
            this.$emit('update:isVisible', false)
        },
    },
}
</script>
