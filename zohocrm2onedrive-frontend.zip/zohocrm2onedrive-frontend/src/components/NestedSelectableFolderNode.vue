<template>
    <div>

        <div v-for="folder in folders" :key="folder.id">
            <div class="flex items-center gap-2">
                <input v-model="selectedFolderToMove" :value="folder.id" type="radio"/>
                <span class="folder-icon text-gray-500">
                    <i class="fa-solid fa-folder"></i>
                </span>
                <p class="">{{ folder.name }}</p>
            </div>
            <div class="pl-6">
                <nested-selectable-folder-node :folders="folder.children"></nested-selectable-folder-node>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'components.nestedSelectableFolderNode',
    computed: {
        selectedFolderToMove: {
            get() {
                return this.$store.state.leadConversion.selectedFolderToMove
            },
            set(v) {
                this.$store.state.leadConversion.selectedFolderToMove = v
            },
        },
    },
    props: {
        folders: {
            type: Array,
            default: () => [],
        },
    },
    mounted() {},
}
</script>
