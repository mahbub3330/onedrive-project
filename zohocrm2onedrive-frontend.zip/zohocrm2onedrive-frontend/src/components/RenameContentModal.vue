<template>
    <div
        class="fixed top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
        :class="{
            'opacity-0 invisible pointer-events-none scale-75': !isVisible,
        }"
    >
        <div class="px-10 py-5 bg-white rounded-lg ring-2 w-128">
            <div class="flex items-center mt-2 mb-4 ml-2">
                <slot name="title">Rename "{{ content ? content.name : '' }}" {{ contentType }}</slot>
            </div>
            <input class="w-full pl-1 border-2" type="string" v-model="newName" placeholder="Enter New Name" />
            <div v-if="!renamingInProgress" class="flex gap-2 justify-center mt-2">
                <button
                    @click="renameButtonClicked"
                    class="w-1/2 px-4 text-sm font-semibold text-white bg-green-500 border-2 border-green-500 shadow leading-6 rounded-md hover:bg-green-600 transition ease-in-out duration-150"
                >
                    Rename {{ contentType }}
                </button>
                <button
                    @click="cancelled"
                    class="w-1/2 px-4 text-sm font-semibold text-white bg-blue-500 border-2 border-blue-500 shadow leading-6 rounded-md hover:bg-blue-600 transition ease-in-out duration-150"
                >
                    Cancel
                </button>
            </div>
            <div v-if="renamingInProgress" class="flex justify-center mt-4">
                <loading paddingClass="px-3 py-1" bgColorClass="bg-gray-400">Renaming...</loading>
            </div>
        </div>
        <div
            class="fixed z-10 top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
            :class="{
                'opacity-0 invisible pointer-events-none scale-75': !showErrorModal,
            }"
        >
            <div class="px-10 py-5 bg-white rounded-lg ring-2 w-96">
                <div class="flex items-center text-red-500 mt-2 mb-4 ml-2">Renaming Failed! Please Try again.</div>
                <div class="flex justify-center mt-2">
                    <button
                        @click="okButtonOfErrorModalClicked"
                        class="w-1/4 px-4 text-sm font-semibold text-white bg-gray-500 border-2 border-green-500 shadow leading-6 rounded-md transition ease-in-out duration-150"
                    >
                        Ok
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Loading from '@/components/Loading.vue'

export default {
    name: 'components.renameContentModal',
    components: {
        Loading,
    },
    props: {
        isVisible: {
            type: Boolean,
            default: false,
        },
        content: {
            type: Object,
            required: true,
        },
        recordZohoId: {
            type: String,
            required: true,
        },
    },
    data: () => ({
        newName: null,
        renamingInProgress: false,
        showErrorModal: false,
    }),
    computed: {
        ...mapGetters({}),
        contentType() {
            return this.content ? this.content['.tag'] : ''
        },
    },
    watch: {
        content: {
            deep: true,
            handler(cc) {
                this.newName = cc.name
            },
        },
    },
    mounted() {
        this.init()
    },
    methods: {
        init() {
            // this.newName = this.content.name
        },
        async renameButtonClicked() {
            this.renamingInProgress = true

            const payload = {
                zohoId: this.recordZohoId,
                newName: this.newName,
                content: this.content,
            }
            await this.$store
                .dispatch('deal/renameContent', payload)
                .then(() => {
                    this.renamingInProgress = false

                    this.$emit('update:isVisible', false)
                    this.$emit('renameSucceeded', this.content)
                })
                .catch(() => {
                    this.renamingInProgress = false
                    this.showErrorModal = true
                })
        },
        cancelled() {
            this.$emit('update:isVisible', false)
        },
        okButtonOfErrorModalClicked() {
            this.showErrorModal = false
            this.$emit('update:isVisible', false)
            this.$emit('renameFailed', this.content)
        },
    },
}
</script>
