<template>
    <div
        class="fixed z-10 top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
        :class="{
            'opacity-0 invisible pointer-events-none scale-75': !isVisible,
        }"
    >
        <div class="p-2 bg-white rounded-lg ring-2 w-128">

            <div class="grid place-items-left">
                <h2 class="text-lg">
                    <slot name="title">Parent Folder</slot>
                </h2>
            </div>
            <div class="pb-2">
                <multilevel-select
                    :options="parentFolderOptions"
                />
            </div>
            <div class="grid place-items-left">
                <h2 class="text-lg">
                    <slot name="title">Folder Name</slot>
                </h2>
            </div>

            <div class="px-2 pb-2">
                <input v-model="name" class="w-full px-2 py-1 border-2 rounded" type="text"
                       placeholder="Enter Folder Name"/>
                <span v-if="invalidNameError" class="text-red-500">Please Enter a valid Name!</span>
                <span v-if="duplicateNameError"
                      class="text-red-500">Folder name should be unique in each hierarchy!</span>
            </div>

            <div class="flex justify-center px-2 py-2 gap-4">
                <button @click.prevent="createTemplate" class="px-4 py-1 text-white bg-green-400 rounded-md">Submit
                </button>

                <button class="px-4 py-1 text-gray-700 bg-white ring-1 ring-inset ring-gray-700 rounded-md"
                        @click="modalCancelled">Cancel
                </button>
            </div>
        </div>
    </div>
</template>

<script>
import Loading from "@/components/Loading";
import {mapGetters} from "vuex";
import MultilevelSelect from "@/components/MultilevelSelect";
import axios from "axios";
import lodash from "lodash";
import utils from "@/utils";

export default {
    name: "CreateHierarchyFolder",
    components: {
        MultilevelSelect,
        Loading,
    },
    props: {
        isVisible: {
            type: Boolean,
            default: false,
        },
        form: {
            type: Object,
            required: false
        },
        parentFolderOptions: {
            type: Array,
            required: false
        }
    },
    watch: {
        'form': function (val) {
            this.parent_id = val.parent_id
            this.name = val.name
            if (val.id || val.parent_id) {
                this.setSelectedOption(val)
            } else {
                this.clearSelectedOption()
            }
        },
    },
    data: () => ({
        name: null,
        parent_id: '',
        parentName: null,
        invalidNameError: false,
        duplicateNameError: false,
        childFolders: []

    }),
    computed: {
        ...mapGetters({
            zapikey: 'zoho/zapikey',
            selectedOptions: "nestedSelectedOption/selectedOption",
            moduleName: 'template/moduleName'
        }),
        isNewParentHierarchyFolderNameValid() {
            return utils.isValidFolderName(this.name)
        },

    },
    methods: {
        checkDuplicateName(parentId) {
            if (parentId == null) {
                let validName = this.parentFolderOptions.find(val => val.name.toLowerCase() === this.name.toLowerCase())
                if (validName !== undefined) return true
            }

            let options = [...this.parentFolderOptions]
            let folders = this.findChildrens(this.parent_id, options)
            let validName = folders.find(val => val.name.toLowerCase() == this.name.trim().toLowerCase())
            if (validName !== undefined) return true

        },
        createTemplate() {
            if (!this.isNewParentHierarchyFolderNameValid || this.name == null) {
                this.invalidNameError = true
                return
            }
            // if (this.checkDuplicateName(this.parent_id)){
            //     this.duplicateNameError = true
            //     return;
            // }
            this.invalidNameError = false
            this.duplicateNameError = false

            let data = {...this.form, name: this.name, parent_id: this.selectedOptions.id}
            this.$emit('storeFolder', data)
            this.modalCancelled();
        },
        clearSelectedOption() {
            let data = {
                name: "Parent Folder",
                id: null
            }
            this.$store.commit('nestedSelectedOption/setSelectedOption', data)
        },
        setSelectedOption(val) {
            let name = this.findParentName(this.parentFolderOptions, val.parent_id)
            let data = {
                name: name,
                id: val.parent_id
            }
            this.$store.commit('nestedSelectedOption/setSelectedOption', data)
        },
        findParentName(data, parentId) {
            for (let index = 0; index < data.length; index++) {
                if (data[index].id === parentId) {
                    this.parentName = data[index].name
                    break
                }
                if (data[index]['children'].length > 0) {
                    this.findParentName(data[index].children, parentId)
                }
            }
            return this.parentName;
        },

        findChildrens(parentId, options) {
            for (let index = 0; index < options.length; index++) {
                if (options.findIndex(val => val.parent_id == parentId) == -1) {
                    this.findChildrens(parentId, options[index]['children'])
                }
                if (options.findIndex(val => val.parent_id == parentId) != -1) {
                    this.childFolders = options[index]['children'];
                    break;
                }

            }

            return this.childFolders;
        },

        modalCancelled() {
            this.name = null
            this.$store.commit('nestedSelectedOption/setShow', false)
            this.$emit('update:isVisible', false)
        },


    }
}
</script>

<style scoped>

</style>