<template>
    <div>
        <div class="relative">
            <div class="px-2 pb-2">
                <input v-model="selectedOption.name" @click="showSelectedOption" readonly
                       class="w-full px-2 py-1 border-2 rounded" type="text"
                       placeholder="Search folder by name"/>
            </div>
            <div class="mb-1 rounded-sm bg-white" v-show="show">

                <NestedSelectOption
                    :options="options"
                    :depth="0"
                />

            </div>
        </div>
    </div>
</template>

<script>
import NestedSelectOption from "@/components/NestedSelectOption";
import {mapGetters} from "vuex";

export default {
    name: "MultilevelSelect",
    components: {
        NestedSelectOption
    },
    props: ['options'],
    computed: {
        ...mapGetters({
            show: 'nestedSelectedOption/show',
            selectedOption: 'nestedSelectedOption/selectedOption'
        }),
    },

    methods: {
        showSelectedOption() {
            let payload = this.show === false;
            this.$store.commit('nestedSelectedOption/setShow', payload)
        },
    }
}

</script>

<style scoped>
.dropdown-submenu {
    position: relative;
}

.dropdown-submenu .dropdown-menu {
    top: 0;
    left: 100%;
    margin-top: -1px;
}
</style>