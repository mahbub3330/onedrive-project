<template>
    <div>
        <div>
            <button
                class="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
                @click.prevent="openCreateHierarchyFolder()"
            >
                Add Hierarchy Folder
            </button>
            <create-hierarchy-folder
                v-model:is-visible="openCreateHierarchyFolderDialogueBox"
                :form="folderForm"
                :parentFolderOptions="parentFolders"
                @storeFolder="createFolder"
            />

        </div>
        <div class="mt-4">
            <nested-draggable
                :folders="hierarchyFoldersTree"
                :depth="0"
                :template="template"
            />
            <div v-if="!hierarchyFoldersTree.length" class="flex justify-center mt-6">
                <p class="text-red-500">No Folder Created! Please Add Hierarchy Folder</p>
            </div>
        </div>
        <y-n-dialogue
            :is-visible="deleteConfirm"
            @yesClicked="yesClicked"
            @noClicked="noClicked"
        />
    </div>
</template>

<script>
import AppInput from '@/components/AppInput.vue'
import NestedDraggable from '@/components/NestedDraggable.vue'
import Loading from '@/components/Loading.vue'
import {mapGetters} from 'vuex'
import _ from 'lodash'
import utils from '@/utils'
import CreateHierarchyFolder from "@/components/CreateHierarchyFolder";
import axios from "axios";
import YNDialogue from "@/components/YNDialogue";
import MultilevelSelect from "@/components/MultilevelSelect";

const createFolderform = {
    id: null,
    name: 'New Folder',
    template_id: null,
    parent_id: null

}
const rootFolderOption = {
    "id": null,
    "name": "Parent Folder"
}

export default {
    name: 'components.hierarchyFolders',
    components: {
        AppInput,
        NestedDraggable,
        Loading,
        CreateHierarchyFolder,
        YNDialogue,
        MultilevelSelect
    },
    props: {
        hierarchyFoldersTree: {
            type: Array,
            default: () => [],
        },
        template: {
            type: Object,
            required: false,
        },
        fetchingHetchHierarchyFoldersTree: {
            type: Boolean,
            default: false,
        },
    },
    data: () => ({
        foldersTree: [],
        editing: false,
        addingParentFolder: false,
        newParentFolderName: 'New Folder',
        totalFolders: 0,
        maxFolders: 20,
        folderIndexCount: 0,


        openCreateHierarchyFolderDialogueBox: false,
        // moduleName: 'deals',
        folderForm: {...createFolderform},
        deleteConfirm: false,
        deleteFolderId: null

    }),
    watch: {

        // hierarchyFoldersTree(newValue) {
        //     this.resetFoldersTree(newValue)
        // },
        // foldersTree: {
        //     deep: true,
        //     handler(newValue) {
        //         this.totalFolders = this.countTotalFolders(newValue)
        //         this.setReferencesToFolders(newValue)
        //     },
        // },
    },
    computed: {
        ...mapGetters({
            zapikey: 'zoho/zapikey',
            parentFolders: "hierarchyFolder/parentFoldersOptions",
            moduleName: 'template/moduleName'
        }),
        isNewParentHierarchyFolderNameValid() {
            return utils.isValidFolderName(this.newParentFolderName)
        },
    },
    mounted() {
    },
    methods: {

        async deleteFolder(folderId) {
            this.deleteConfirm = true
            this.deleteFolderId = folderId
        },
        async editFolder(folder) {
            this.folderForm = {...folder}
            await this.fetchParentFolderOptions(this.folderForm.template_id)
            this.openCreateHierarchyFolderDialogueBox = true
        },
        openCreateHierarchyFolder() {
            this.folderForm = {
                ...createFolderform,
                template_id: this.template.id,
            }
            this.fetchParentFolderOptions(this.template.id)
            this.openCreateHierarchyFolderDialogueBox = true
        },

        async fetchParentFolderOptions(templateId) {
            await this.$store.dispatch('hierarchyFolder/getParentFolders', templateId)
        },

        async createFolder(data) {
            await this.$store.dispatch('hierarchyFolder/createFolder', data).then(res => {
                this.fetchTemplates()
            })
        },
       async yesClicked() {
            this.deleteConfirm = false
            await this.$store.dispatch('hierarchyFolder/deleteFolder', this.deleteFolderId).then(res => {
                this.fetchTemplates()
            })
        },
        noClicked() {
            this.deleteConfirm = false
        },

        fetchTemplates() {
            console.log('module name is', this.moduleName)
            this.$store
                .dispatch('template/fetchTemplates', {
                    moduleName: this.moduleName,
                })
        },
    },
}
</script>
