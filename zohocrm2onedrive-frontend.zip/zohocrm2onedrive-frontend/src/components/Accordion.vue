<template>
    <div class="">
        <div class="tab__header">
            <div href="#" style="background-color:#19374d" class="tab__link p-4 block bg-blue-dark hover:bg-blue-darker no-underline text-white border-b-2 border-white flex justify-between">
                <div>
                    <strong>{{title}}</strong>
                </div>
                <div class="justify-end">
                    <button class="cursor-pointer gap-1" type="button" @click.prevent="editItem"><i class="fa fa-edit"> </i></button>   &nbsp;
                    <button class="cursor-pointer gap-1" type="button" @click.prevent="deleteItem"><i class="fa fa-trash"> </i></button> &nbsp;
                    <span class="down-Arrow cursor-pointer gap-1" v-show="!active" @click.prevent="active = !active">&#9660;</span>
                    <span class="up-Arrow cursor-pointer gap-1" v-show="active" @click.prevent="active = !active">&#9650;</span>
                </div>
            </div>

        </div>
        <div class="tab__content p-2" v-show="active"><slot /></div>
        <y-n-dialogue
            :is-visible="deleteConfirm"
            @yesClicked="yesClicked"
            @noClicked="noClicked"
        />
    </div>
</template>

<script>
import YNDialogue from "@/components/YNDialogue";
export default {
    name: "Accordion",
    components: {
        YNDialogue
    },
    data() {
        return {
            active: false,
            deleteConfirm: false
        }
    },
    props: [
        'title'
    ],
    methods: {
        deleteItem(){
            // this.$emit('deleteItem')
            this.deleteConfirm = true
        },
        editItem(){
            this.$emit('editItem')
        },
        yesClicked(){
            this.deleteConfirm = false
            this.$emit('deleteItem')
        },
        noClicked(){
            this.deleteConfirm = false
        }
    }
}
</script>

<style scoped>

</style>