<template>
    <div
        class="fixed top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
        :class="{
            'opacity-0 invisible pointer-events-none scale-75': !isVisible,
        }"
    >
        <div class="px-10 py-5 bg-white rounded-lg ring-2 w-128">
            <div class="grid place-items-left">
                <h2 class="text-lg">
                    <slot>Template Name</slot>
                </h2>
            </div>
            <div class="">
                <select class="w-full px-2 py-1 border-2 rounded" v-model="templateId">
                    <option disabled :value="null" selected>Please select one</option>
                    <option v-for="option in templateOptions"  :value="option.id">{{ option.name }}</option>
                </select>
            </div>
            <div  class="flex gap-2 justify-center mt-2">
                <button
                    :disabled="templateId == null"
                    @click="createFolderButtonClicked"
                    class="w-1/2 px-4 text-sm font-semibold text-white bg-green-500 border-2 border-green-500 shadow leading-6 rounded-md"
                    :class="templateId !== null ? 'hover:bg-green-600 transition ease-in-out duration-150': null"
                >
                    Create Template Folders
                </button>
                <button
                    @click="cancelled"
                    class="w-1/2 px-4 text-sm font-semibold text-white bg-blue-500 border-2 border-blue-500 shadow leading-6 rounded-md hover:bg-blue-600 transition ease-in-out duration-150"
                >
                    Cancel
                </button>
            </div>
        </div>

    </div>

</template>

<script>

export default {
    name: "TemplateSelect",

    props: {
        isVisible: {
            type: Boolean,
            default: false,
        },
        templateOptions: {
            type: Array,
            required: false,
            default: []
        },
    },
    data: () => ({
        templateId: null,
    }),
    methods: {

        async createFolderButtonClicked() {
            this.$emit('selectedTemplate', this.templateId)
            this.$emit('update:isVisible', false)
        },
        cancelled() {
            this.templateId = null
            this.$emit('update:isVisible', false)
        },
    },
}
</script>

<style scoped>

</style>