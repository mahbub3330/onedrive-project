<template>

    <div class="ml-2">
        <div v-for="option in options" :key="option.id" >
            <div class="flex items-center gap-2 mt-0.5">
                <span class="folder-icon text-gray-500">
                    <i class="fa-solid fa-folder"></i>
                </span>
<!--                :class="folder.name == 'Item 1' ? 'bg-blue-500 text-blue-700 font-semibold' : null"-->

                <p class="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-1
                         px-3 border border-transparent-500 hover:border-transparent rounded"

                   :class="selectedOption.id == option.id? 'bg-blue-500 text-red-700 font-semibold' : null"
                   @click="showSelectedOption(option)"
                >
                    {{ option.name }}
                </p>
            </div>
            <div class="pl-6">
                <nested-select-option :depth="depth + 1 " :options="option.children" />
            </div>
        </div>
    </div>
</template>

<script>
import {mapGetters} from "vuex";

export default {
    name: "NestedSelectOption",
    props: ['options', 'depth'],
    computed: {
        ...mapGetters({
            show: 'nestedSelectedOption/show',
            selectedOption: 'nestedSelectedOption/selectedOption'
        }),
    },
    methods: {
        showSelectedOption(option){
            let payload = this.show === false;
            this.$store.commit('nestedSelectedOption/setShow', payload)
            let data = {
                name: option.name,
                id: option.id ? option.id : null
            }
            this.$store.commit('nestedSelectedOption/setSelectedOption', data)
        },
    }
}
</script>

<style scoped>

</style>