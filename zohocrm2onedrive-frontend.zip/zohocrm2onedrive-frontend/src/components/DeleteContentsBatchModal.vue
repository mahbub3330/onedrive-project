<template>
    <div>
        <div
            class="fixed top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
            :class="{
                'opacity-0 invisible pointer-events-none scale-75': !isVisible,
            }"
        >
            <div class="bg-white rounded-lg ring-2 p-2">
                <div class="px-8 py-4">
                    <h3 v-if="entries.length == 1">Delete this item?</h3>
                    <h3 v-else>Delete these items?</h3>
                </div>

                <div v-if="!deletingInProgress" class="flex justify-center gap-10">
                    <button class="bg-red-400 text-white py-1 w-1/2 rounded-md" @click.prevent="deleteContentsConfirmed">Yes</button>
                    <button class="bg-green-400 text-white py-1 w-1/2 rounded-md" @click.prevent="$emit('update:isVisible', false)">Cancel</button>
                </div>
                <div v-else class="flex justify-center">
                    <loading paddingClass="px-3 py-1" bgColorClass="bg-gray-400">Deleting...</loading>
                </div>
            </div>
        </div>
        <div
            class="fixed z-10 top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
            :class="{
                'opacity-0 invisible pointer-events-none scale-75': !showErrorModal,
            }"
        >
            <div class="px-10 py-5 bg-white rounded-lg ring-2 w-96">
                <div class="flex items-center text-red-500 mt-2 mb-4 ml-2">Deleting Failed! Please Try again.</div>
                <div class="flex justify-center mt-2">
                    <button
                        @click="okButtonOfErrorModalClicked"
                        class="w-1/4 px-4 text-sm font-semibold text-white bg-gray-500 border-2 border-green-500 shadow leading-6 rounded-md transition ease-in-out duration-150"
                    >
                        Ok
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Loading from '@/components/Loading.vue'
export default {
    name: 'components.DeleteContentsBatchModal',
    components: {
        Loading,
    },
    props: {
        isVisible: {
            type: Boolean,
            default: false,
        },
        recordZohoId: {
            type: String,
            required: true,
        },
        entries: {
            required: true,
        },
    },
    data: () => ({
        deletingInProgress: false,
        showErrorModal: false,
    }),
    computed: {},
    methods: {
        async deleteContentsConfirmed() {
            this.deletingInProgress = true
            const payload = {
                zohoId: this.recordZohoId,
                entries: this.entries,
            }

            await this.$store
                .dispatch('deal/deleteContentsBatch', payload)
                .then(() => {
                    this.deletingInProgress = false
                    this.$emit('update:isVisible', false)
                    this.$emit('batchDeleteSucceeded', this.entries)
                })
                .catch(() => {
                    this.deletingInProgress = false
                    this.showErrorModal = true
                })
        },
        okButtonOfErrorModalClicked() {
            this.showErrorModal = false
            this.$emit('update:isVisible', false)
            this.$emit('batchDeleteFailed', this.content)
        },
    },
}
</script>
