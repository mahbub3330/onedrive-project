<template>
    <div
        class="fixed top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
        :class="{
            'opacity-0 invisible pointer-events-none scale-75': !isVisible,
        }"
    >
        <div class="px-10 py-5 bg-white rounded-lg ring-2 w-128">
            <div class="flex items-center mt-2 mb-4 ml-2">
                <slot name="title">Create Folder</slot>
            </div>
            <input class="w-full pl-1 border-2" type="string" v-model="newFolderName" @keyup.enter="createFolderButtonClicked" placeholder="Enter New Name" />
            <div v-if="!creatingFolderInProgress" class="flex gap-2 justify-center mt-2">
                <button
                    @click="createFolderButtonClicked"
                    class="w-1/2 px-4 text-sm font-semibold text-white bg-green-500 border-2 border-green-500 shadow leading-6 rounded-md hover:bg-green-600 transition ease-in-out duration-150"
                >
                    Create Folder
                </button>
                <button
                    @click="cancelled"
                    class="w-1/2 px-4 text-sm font-semibold text-white bg-blue-500 border-2 border-blue-500 shadow leading-6 rounded-md hover:bg-blue-600 transition ease-in-out duration-150"
                >
                    Cancel
                </button>
            </div>
            <div v-if="creatingFolderInProgress" class="flex justify-center mt-4">
                <loading paddingClass="px-3 py-1" bgColorClass="bg-gray-400">Creating Folder...</loading>
            </div>
        </div>
        <div
            class="fixed z-10 top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
            :class="{
                'opacity-0 invisible pointer-events-none scale-75': !showErrorModal,
            }"
        >
            <div class="px-10 py-5 bg-white rounded-lg ring-2 w-96">
                <div class="flex items-center text-red-500 mt-2 mb-4 ml-2">Couldn't Create Folder! Please Try again.</div>
                <div class="flex justify-center mt-2">
                    <button
                        @click="okButtonOfErrorModalClicked"
                        class="w-1/4 px-4 text-sm font-semibold text-white bg-gray-500 border-2 border-green-500 shadow leading-6 rounded-md transition ease-in-out duration-150"
                    >
                        Ok
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Loading from '@/components/Loading.vue'

export default {
    name: 'components.createFolderModal',
    components: {
        Loading,
    },
    props: {
        isVisible: {
            type: Boolean,
            default: false,
        },
        recordZohoId: {
            type: String,
            required: true,
        },
        parentFolderId: {
            type: String,
            required: true,
        },
    },
    data: () => ({
        newFolderName: null,
        creatingFolderInProgress: false,
        showErrorModal: false,
    }),
    computed: {
        ...mapGetters({}),
    },
    mounted() {},
    methods: {
        async createFolderButtonClicked() {
            this.creatingFolderInProgress = true

            const payload = {
                zohoId: this.recordZohoId,
                parentFolderId: this.parentFolderId,
                folderName: this.newFolderName,
            }
            await this.$store
                .dispatch('deal/createFolder', payload)
                .then(() => {
                    this.creatingFolderInProgress = false

                    this.$emit('update:isVisible', false)
                    this.$emit('createFolderSucceeded')
                    this.newFolderName = null
                })
                .catch(() => {
                    this.creatingFolderInProgress = false
                    this.showErrorModal = true
                })
        },
        okButtonOfErrorModalClicked() {
            this.showErrorModal = false
            this.newFolderName = null
            this.$emit('update:isVisible', false)
            this.$emit('createFolderFailed', this.content)
        },
        cancelled() {
            this.newFolderName = null
            this.showErrorModal = false
            this.$emit('update:isVisible', false)
        },
    },
}
</script>
