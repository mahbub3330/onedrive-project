<template>
    <div>
        <draggable class="dragArea" :class="{ 'pl-8': depth }" tag="ul" handle=".folder-icon" :onEnd="endMove"
                   :list="folders" :group="{ name: 'g1' }" item-key="name">
            <template #item="{ element }">
                <li :id="element.id">
                    <div class="mb-1 rounded-sm bg-white">

                        <div class="flex">
                            <p class="overflow-hidden">
                            <span class="folder-icon text-gray-700 p-1 bg-gray-300 cursor-move">
                                <i class="fa-solid fa-folder"></i>
                            </span>
                                {{ element.name }}
                            </p>
                            <div class="ml-auto mr-2 text-gray-500 flex gap-2 items-center">
                                <i @click="editFolder(element)" class="fa-solid cursor-pointer fa-pen-to-square"></i>

                                <i @click="openCreateHierarchyFolder(element)"
                                   class="fa-solid cursor-pointer fa-folder-plus"></i>

                                <i @click="deleteFolder(element)"
                                   class="fa-solid cursor-pointer fa-folder-minus text-red-500"></i>
                            </div>
                        </div>
                    </div>
                    <nested-draggable :depth="depth + 1" :template="template" :folders="element.children"/>
                </li>
            </template>
        </draggable>

        <create-hierarchy-folder
            v-show="showCreateFolder"
            v-model:is-visible="openCreateHierarchyFolderDialogueBox"
            :module-name="moduleName"
            :form="folderForm"
            :parentFolderOptions="parentFolders"
            @storeFolder="createFolder"
        />

        <y-n-dialogue
            v-show="showDeleteModal"
            :is-visible="deleteConfirm"
            @yesClicked="yesClicked"
            @noClicked="noClicked"
        />
    </div>
</template>
<script>
import draggable from 'vuedraggable'
import {mapGetters} from 'vuex'
import CreateHierarchyFolder from "@/components/CreateHierarchyFolder";
import YNDialogue from "@/components/YNDialogue";

const createFolderform = {
    id: null,
    name: 'New Folder',
    template_id: null,
    parent_id: null

}
export default {
    name: 'nested-draggable',
    components: {
        draggable,
        CreateHierarchyFolder,
        YNDialogue
    },
    props: {
        folders: {
            type: Array,
            default: () => [],
        },
        depth: {
            type: Number,
            required: true,
        },
        template: {
            type: Object,
            required: false,
        },
    },
    data: () => ({
        openCreateHierarchyFolderDialogueBox: false,
        folderForm: {...createFolderform},
        // moduleName: 'deals',
        deleteConfirm: false,
        deleteFolderId: null,
        showCreateFolder: false,
        showDeleteModal: false
    }),
    computed: {
        ...mapGetters({
            // folders: 'hierarchyFolder/folders',
            parentFolders: "hierarchyFolder/parentFoldersOptions",
            moduleName: 'template/moduleName'
        }),
    },
    mounted() {
    },
    methods: {
        async editFolder(folder) {
            await this.fetchParentFolderOptions(this.template.id)
            this.folderForm = {...folder}
            this.showCreateFolder = true
            this.openCreateHierarchyFolderDialogueBox = true

        },
        async openCreateHierarchyFolder(element) {
            await this.fetchParentFolderOptions(this.template.id)
            this.folderForm = {
                ...createFolderform,
                template_id: this.template.id,
                parent_id: element.id
            }

            this.showCreateFolder = true
            this.openCreateHierarchyFolderDialogueBox = true

        },
        async fetchParentFolderOptions(templateId) {
            await this.$store.dispatch('hierarchyFolder/getParentFolders', templateId)
        },
        async createFolder(data) {
            await this.$store.dispatch('hierarchyFolder/createFolder', data).then(res => {
                this.fetchTemplates()
                this.showCreateFolder = false
            })
        },
        fetchTemplates() {
            this.$store
                .dispatch('template/fetchTemplates', {
                    moduleName: this.moduleName,
                })
        },
        async yesClicked() {
            this.showDeleteModal = false
            this.deleteConfirm = false
            await this.$store.dispatch('hierarchyFolder/deleteFolder', this.deleteFolderId).then(res => {
                this.fetchTemplates()
            })
        },
        noClicked() {
            this.showDeleteModal = false
            this.deleteConfirm = false
        },
        async deleteFolder(folderId) {
            this.showDeleteModal = true
            this.deleteConfirm = true
            this.deleteFolderId = folderId.id
        },

        async endMove(evt) {
            let selectedLi = document.getElementById(evt.item.id)
            let parentId = selectedLi.parentNode.parentElement.parentElement.id;
            let payload = {
                folderId: evt.item.id,
                data: {
                    parentId: parentId
                }
            }
            await this.$store.dispatch('hierarchyFolder/updateParentId', payload).then(res => {
                this.fetchTemplates()
            })
        },


    },
}
</script>
<style scoped>
.dragArea {
    min-height: 1px;
}
</style>