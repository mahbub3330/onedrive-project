<template>
    <div :class="{ 'border-b': showHorizontalLine, horizontalLineClass: showHorizontalLine }">
        <ul class="flex gap-1 whitespace-nowrap">
            <li class="px-4 py-1.5 rounded-t-lg border border-b-0 border-gray-300" :class="tabClassName(index)" v-for="(tab, index) in tabList" :key="index" @click="handleTabClick(index)">
                <button :disabled="tab.disabled" :class="{ 'cursor-default': index == activeTabIndex }">
                    <span v-html="tab.icon"></span>
                    {{ tab.text }}
                </button>
            </li>
        </ul>
    </div>
</template>

<script>
export default {
    name: 'components.appTabs',
    props: {
        tabList: {
            type: Array,
            required: true,
        },
        activeBgColorClass: {
            type: String,
            required: false,
            default: 'bg-orange-400',
        },
        activeFgColorClass: {
            type: String,
            required: false,
            default: 'text-white',
        },
        inActiveBgColorClass: {
            type: String,
            required: false,
            default: 'bg-white',
        },
        inActiveFgColorClass: {
            type: String,
            required: false,
            default: 'text-gray-700',
        },
        activeBorderClass: {
            type: String,
            required: false,
            default: 'border-orange-400',
        },
        inActiveBorderClass: {
            type: String,
            required: false,
            default: '',
        },
        showHorizontalLine: {
            type: Boolean,
            required: false,
            default: true,
        },
        horizontalLineClass: {
            type: String,
            required: false,
            default: 'border-gray-300',
        },
    },
    data() {
        return {
            activeTabIndex: 0,
        }
    },
    computed: {},
    methods: {
        handleTabClick(idx) {
            if (this.tabList[idx].disabled) {
                return
            }

            if (this.activeTabIndex !== idx) {
                // set activeTabIndex
                this.activeTabIndex = idx

                // emit 'tabChanged' event
                this.$emit('tabChanged', {
                    tab: this.tabList[idx],
                    index: idx,
                })
            }
        },
        tabClassName(idx) {
            var isActive = idx === this.activeTabIndex

            var className = ''
            if (isActive) {
                className += this.activeBgColorClass + ' ' + this.activeFgColorClass + ' ' + this.activeBorderClass
            } else {
                className += this.inActiveBgColorClass + ' ' + this.inActiveFgColorClass + ' ' + this.inActiveBorderClass
            }

            return className
        },
    },
    mounted() {},
}
</script>
