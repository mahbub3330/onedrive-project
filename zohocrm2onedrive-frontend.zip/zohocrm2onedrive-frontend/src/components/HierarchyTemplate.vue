<template>
    <div
        class="fixed z-10 top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
        :class="{
            'opacity-0 invisible pointer-events-none scale-75': !isVisible,
        }"
    >
        <div class="p-2 bg-white rounded-lg ring-2 w-128">
            <div class="grid place-items-left">
                <h2 class="text-lg">
                    <slot name="title">Template Name</slot>
                </h2>
            </div>
            <div class="px-2 pb-2">
                <input v-model="name" class="w-full px-2 py-1 border-2 rounded" type="text"
                       placeholder="Enter Template Name"/>
            </div>

            <div class="flex justify-center px-2 py-2 gap-4">
                <button @click.prevent="createTemplate" class="px-4 py-1 text-white bg-green-400 rounded-md">Submit
                </button>

                <button class="px-4 py-1 text-gray-700 bg-white ring-1 ring-inset ring-gray-700 rounded-md"
                        @click="modalCancelled">Cancel
                </button>
            </div>
        </div>
    </div>

</template>

<script>
import Loading from "@/components/Loading";
import {mapGetters} from "vuex";
import axios from "axios";

const templateDefaultName = 'New Template'
export default {
    name: "HierarchyTemplate",
    components: {
        Loading
    },
    props: {
        isVisible: {
            type: Boolean,
            default: false,
        },
        form: {
            type: Object,
            required: false
        }
    },
    watch: {
      'form.name': function (val){
          if (val){
              this.name = val
          }
      }
    },

    data: () => ({
        name: null,
    }),
    mounted() {
        this.name = templateDefaultName
    },
    computed: {
        ...mapGetters({
            zapikey: 'zoho/zapikey',
            moduleName: 'template/moduleName'
        }),
    },
    methods: {
        createTemplate() {
            let data = {...this.form, name: this.name}
            this.$emit('storeTemplate', data)
            this.modalCancelled();

        },
        modalCancelled() {
            this.name = templateDefaultName
            this.$emit('update:isVisible', false)
        },
    }
}
</script>

<style scoped>

</style>