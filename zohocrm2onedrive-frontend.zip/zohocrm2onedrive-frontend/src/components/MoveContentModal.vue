<template>
    <div
        class="fixed top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
        :class="{
            'opacity-0 invisible pointer-events-none scale-75': !isVisible,
        }"
    >
        <div class="p-2 bg-white rounded-lg ring-2 w-128">
            <div class="grid place-items-center">
                <h2 class="text-lg">
                    <slot name="title">Choose Folder</slot>
                </h2>
            </div>
            <div class="flex items-center mt-2 mb-4 ml-2">
                <ion-icon v-if="depth" @click="goToParentFolder" class="w-6 h-6" name="arrow-back-outline"></ion-icon>
                &nbsp;
                {{ currentFolderName }}
            </div>

            <div class="px-2 py-2">
                <ul class="flex flex-col gap-2">
                    <li v-for="folder in folderList.filter((i) => i.id != content.id && i['.tag'] === 'folder')" :key="folder.id"
                        class="flex items-center gap-4">
                        <p class="flex items-center cursor-pointer gap-1" @click="folderClicked(folder)">
                            <span>
                                <img class="inline w-7 h-7" src="@/assets/img/db-folder.png"/>
                            </span>
                            {{ folder.name }}
                        </p>
                    </li>

                    <li v-if="fetchingFolderList" class="flex justify-center">
                        <loading paddingClass="px-3 py-1" bgColorClass="bg-gray-400">Fetching...</loading>
                        <!-- <p class="ml-4">Fetching Folders...</p> -->
                    </li>
                </ul>
                <div v-if="has_more" class="grid place-items-center">
                    <button
                        @click="loadMoreContents"
                        type="button"
                        class="inline-flex items-center px-4 py-2 text-sm font-semibold text-blue-500 bg-blue-100 border-2 border-blue-500 shadow leading-6 rounded-md hover:bg-blue-500 hover:text-blue-100 transition ease-in-out duration-150"
                    >
                        Load More
                    </button>
                </div>
            </div>

            <div v-if="!fetchingFolderList && !movingInProgress" class="flex justify-center px-2 py-2 gap-4">
                <button @click="folderChosen" class="px-4 py-1 text-white bg-green-400 rounded-md">Move Here</button>

                <button class="px-4 py-1 text-gray-700 bg-white ring-1 ring-inset ring-gray-700 rounded-md"
                        @click="$emit('update:isVisible', false)">Cancel
                </button>
            </div>
            <div v-if="movingInProgress" class="flex justify-center mt-4">
                <loading paddingClass="px-3 py-1" bgColorClass="bg-gray-400">Moving...</loading>
            </div>
        </div>
        <div
            class="fixed z-10 top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
            :class="{
                'opacity-0 invisible pointer-events-none scale-75': !showErrorModal,
            }"
        >
            <div class="px-10 py-5 bg-white rounded-lg ring-2 w-96">
                <div class="flex items-center text-red-500 mt-2 mb-4 ml-2">Moving Failed! Please Try again.</div>
                <div class="flex justify-center mt-2">
                    <button
                        @click="okButtonOfErrorModalClicked"
                        class="w-1/4 px-4 text-sm font-semibold text-white bg-gray-500 border-2 border-green-500 shadow leading-6 rounded-md transition ease-in-out duration-150"
                    >
                        Ok
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Loading from '@/components/Loading.vue'
import {mapGetters} from 'vuex'

export default {
    name: 'components.moveContentModal',
    components: {
        Loading,
    },
    props: {
        isVisible: {
            type: Boolean,
            default: false,
        },
        folderId: {
            type: String,
            required: true,
        },
        recordZohoId: {
            type: String,
            required: true,
        },
        content: {
            required: true,
        },
        moduleName: {
            type: String,
            default: 'Deals',
        },
    },
    data: () => ({
        currentFolderId: null,
        currentFolderName: null,
        fetchingFolderList: false,
        folderList: [],
        depth: 0,
        movingInProgress: false,
        showErrorModal: false,
        parentFolderId: null,
        fetchingFolderInfo: false,
        has_more: false
    }),
    computed: {
        ...mapGetters({
            zapikey: 'zoho/zapikey',
        }),
    },
    watch: {
        async isVisible(v) {
            if (v) {
                this.beforeFetchingFolders()
                this.depth = 0
                await this.$store
                    .dispatch('oneDrive/fetchFolderInfo', {
                        folderId: this.folderId,
                        zapikey: this.zapikey,
                    })
                    .then((res) => {
                        this.currentFolderId = res.data.id;
                        this.currentFolderName = res.data.name
                        this.parentFolderId = res.data.parentReference.id !== undefined ? res.data.parentReference.id : 'root';


                    })
                this.init()
            }
        },
    },
    methods: {
        init() {
            this.getFolderList()
        },
        async getFolderList() {
            this.beforeFetchingFolders()
            await this.$store.dispatch('deal/fetchFolderContentForDeals', {
                zohoId: this.recordZohoId,
                folderId: this.currentFolderId,
                moduleName: this.moduleName.toLowerCase()
            }).then((res) => {
                this.folderList = res.value
                this.fetchingFolderList = false
                this.has_more = res['@odata.nextLink']
            })
        },
        beforeFetchingFolders() {
            this.fetchingFolderList = true
            this.folderList = []
        },
        async folderClicked(folder) {
            this.currentFolderId = folder.id
            this.currentFolderName = folder.name
            this.parentFolderId = folder.parentReference['id']
            await this.getFolderList()

            this.depth++
        },
        async goToParentFolder() {
            if (this.fetchingFolderInfo === false) {
                let pId = this.parentFolderId;
                this.currentFolderId = pId
                this.fetchingFolderList = true
                await this.$store.dispatch('deal/fetchFolderContentForDeals', {
                    folderId: pId,
                    zohoId: this.recordZohoId,
                    moduleName: this.moduleName.toLowerCase()
                }).then((response) => {
                    this.fetchingFolderInfo = true
                    this.currentFolderName = null
                    this.has_more = response['@odata.nextLink']
                    let path = response.value[0].parentReference.path;
                    let pathArr = path.split('/');
                    this.currentFolderName = pathArr.pop();
                    this.folderList = response.value
                    this.fetchParentFolderInfo(response.value[0].parentReference.id)

                })
                this.fetchingFolderList = false

                this.depth--
            }
        },

        async fetchParentFolderInfo(folderId) {
            await this.$store
                .dispatch('oneDrive/fetchFolderInfo', {
                    folderId: folderId,
                    zapikey: this.zapikey,
                })
                .then((res) => {
                    this.parentFolderId = res.data.parentReference.id !== undefined ? res.data.parentReference.id : 'root';

                    this.fetchingFolderInfo = false
                })
        },
        async folderChosen() {
            // this.movingInProgress = true
            const payload = {
                zohoId: this.recordZohoId,
                itemId: this.content.id,
                parentId: this.currentFolderId,
            }
            await this.$store
                .dispatch('deal/moveContent', payload)
                .then(() => {
                    this.movingInProgress = false

                    this.$emit('moveSucceeded', this.content)
                    this.$emit('update:isVisible', false)
                })
                .catch(() => {
                    this.movingInProgress = false
                    this.showErrorModal = true
                })
        },
        loadMoreContents() {
            this.$store.dispatch('deal/loadMoreContentsForModal', {
                cursor: this.has_more,
                zohoId: this.recordZohoId,
                folderId: this.currentFolderId,
                moduleName: this.moduleName.toLowerCase()
            }).then((res) => {
                this.has_more = res['@odata.nextLink']
                this.folderList = [...this.folderList, ...res.value]
            })
        },
        okButtonOfErrorModalClicked() {
            this.showErrorModal = false
            this.$emit('update:isVisible', false)
            this.$emit('moveFailed', this.content)
        },
    },
}
</script>
