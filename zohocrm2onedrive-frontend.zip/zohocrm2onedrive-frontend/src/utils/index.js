const isValidEmail = (email) => {
    return String(email)
        .toLowerCase()
        .match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)
}

const isValidFolderName = (folderName) => {
    if (
        folderName &&
        folderName.trim().length == 1 &&
        folderName
            .trim()
            .toLowerCase()
            .match(/^[a-z0-9]*$/)
    ) {
        return true
    }
    return String(folderName)
        .trim()
        .toLowerCase()
        .match(/^[^-\s][^\x00-\x1f\\?*:"";<>|\/.]*[^\x00-\x1f\\?*:"";<>|\/]*[^\s^\x00-\x1f\\?*:"";<>|\/.]+$/g)
}

const bytesToSize = (bytes) => {
    var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
    if (bytes == 0) return '0 Byte'
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)))
    return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i]
}
export default {
    isValidEmail,
    isValidFolderName,
    bytesToSize,
}
