<template>
    <div class="relative">
        <div class="mx-8 mt-20 bg-white" style="min-height: 500px">
            <!-- Header Section -->
            <header class="p-6">
                <div class="flex flex-row justify-between">
                    <div class="">
                        <h2 class="text-lg text-gray-700 font-bold">OneDrive Module Settings</h2>
                        <p class="mt-2 text-gray-600 text-sm">OneDrive Settings lets you integrate and organize folders
                            right inside your CRM</p>
                    </div>

                    <!-- Tabs for switching between authentication & folder settings components -->
                    <div>
                        <app-tabs :tabList="tabList" @tabChanged="tabChanged"></app-tabs>
                    </div>
                </div>
            </header>

            <hr/>

            <!-- component selected by the tab -->
            <section class="py-6 px-80">
                <Transition name="fade" mode="out-in">
                    <component :is="currentTabComponent"></component>
                </Transition>
            </section>
        </div>

        <!-- bottom image of Oscillosoft -->
        <div class="flex flex-row-reverse mx-10 mt-4">
            <img src="@/assets/img/sass-plugin-logo.png" alt=""/>
        </div>

        <!-- Overlay for checking if user is admin -->
        <div v-if="userIsAdmin === 'inquiring' || userIsAdmin === 'no'"
             class="fixed top-0 left-0 flex items-center justify-center w-screen h-screen bg-slate-300">
            <loading v-if="userIsAdmin === 'inquiring'"></loading>

            <div v-if="userIsAdmin === 'no'" class="bg-white rounded-md h-52 w-192 text-center text-gray-700 p-16">
                <h3 class="text-3xl pb-4">Permission Denied</h3>
                <p class="">You need administrative privileges to access this module.</p>
            </div>
        </div>
        <!-- end:Overlay for checking if user is admin -->
    </div>
</template>

<script>
import AppTabs from '@/components/AppTabs.vue'
import Authentication from '@/components/Settings/Authentication.vue'
import FolderSettings from '@/components/Settings/FolderSettings.vue'
import Loading from '@/components/Loading.vue'
import {mapGetters, mapActions} from 'vuex'
import axios from 'axios'

export default {
    name: 'pages.settings',
    components: {
        AppTabs,
        Authentication,
        FolderSettings,
        Loading,
    },
    data: () => ({
        currentTabComponent: 'Authentication',
    }),
    computed: {
        ...mapGetters({
            userIsAdmin: 'zoho/isAdmin',
            zapikey: 'zoho/zapikey',
            pluginUser: 'pluginUser/user',
        }),
        tabList() {
            return [
                {
                    text: 'OneDrive Account',
                    icon: "<ion-icon class='w-3.5 h-3.5 mr-1' name='pencil-sharp'></ion-icon>",
                    component: 'Authentication',
                },
                {
                    text: 'Folder Settings',
                    icon: "<ion-icon class='w-3.5 h-3.5 mr-1' name='folder-open-sharp'></ion-icon>",
                    component: 'FolderSettings',
                    disabled: this.pluginUser.is_authorized == false,
                },
            ]
        },
    },
    async mounted() {
        await this.init()
    },
    methods: {
        async init() {
            document.body.classList.add('bg-gray-300')

            await this.$store.dispatch('zoho/initializeZohoApp')
            await this.$store.dispatch('zoho/fetchZohoSuperadminEmail')
            await this.$store.dispatch('zoho/fetchZohoCurrentUser')
            await this.$store.dispatch('zoho/fetchZohoZapiKey')


            this.$store.dispatch('pluginUser/fetchUser')
        },

        tabChanged(e) {
            this.currentTabComponent = e.tab.component
            this.$store.dispatch('template/setModuleName', 'deals')
        },
    },
}
</script>
