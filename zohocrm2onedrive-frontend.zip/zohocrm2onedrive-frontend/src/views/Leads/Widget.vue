<template>
    <div class="relative mx-4 mt-4">
        <div class="flex gap-4">
            <div class="w-1/6">
                <ion-icon @click="goToParentFolder" v-show="!(rootFolderId === currentFolderId || folderDepth === 0)" class="h-6 w-6" name="arrow-back-outline"></ion-icon>
            </div>
            <div class="flex w-full">
                <div class="flex gap-1 py-1" v-if="checkedContentIds.length">
                    <button
                        @click="moveContentsBatch"
                        v-if="!hierarchyFolderIsSelected"
                        class="w-24 px-6 text-sm font-semibold text-gray-500 bg-white ring-1 ring-gray-500 shadow leading-6 rounded-md hover:bg-gray-500 hover:text-white transition ease-in-out duration-150"
                    >
                        Move
                    </button>
                    <button
                        v-if="!hierarchyFolderIsSelected"
                        @click="deleteContentsBatch"
                        class="w-24 px-6 text-sm font-semibold text-gray-500 bg-white ring-1 ring-gray-500 shadow leading-6 rounded-md hover:bg-gray-500 hover:text-white transition ease-in-out duration-150"
                    >
                        Delete
                    </button>
                </div>
                <app-input class="ml-auto" v-model:value="searchTerm" :selectAtClick="true" placeholder="Search files..."></app-input>
            </div>
        </div>
        <div class="flex gap-4 mt-4">
            <div class="w-1/6 flex flex-col justify-start">
                <button
                    @click="uploadFilesClicked"
                    v-if="leadFolderInfo.id && !leadFolderInfo.folder_is_deleted"
                    class="w-full px-4 py-1 text-sm font-semibold text-white bg-blue-500 shadow leading-6 rounded-md hover:bg-blue-600 transition ease-in-out duration-150"
                >
                    Upload Files
                </button>
                <button
                    v-if="leadFolderInfo.id && !leadFolderInfo.folder_is_deleted"
                    @click="createFolder"
                    class="w-full px-4 py-1 text-sm font-semibold text-white bg-blue-500 shadow leading-6 rounded-md hover:bg-blue-600 transition ease-in-out duration-150 mt-3"
                >
                    Create New Folder
                </button>
                <button
                    v-if="!leadFolderInfo.id || leadFolderInfo.folder_is_deleted"
                    @click="openTemplateSelectModal"
                    class="w-full px-4 py-1 text-sm font-semibold text-white bg-blue-500 shadow leading-6 rounded-md hover:bg-blue-600 transition ease-in-out duration-150"
                >
                    Create Leads Folder
                </button>
            </div>
            <div class="w-full">
                <div class="grid gap-4 grid-cols-files bg-blue-500 text-sm text-white py-2 px-4 justify-start">
                    <input type="checkbox" @change="checkAllContentsClicked" v-model="allContentsChecked" class="h-5 w-5" />
                    <p>Name</p>
                    <p>Type</p>
                    <p>Size</p>
                    <p>Modified At</p>
                    <p>Action</p>
                </div>

                <div v-if="fetchingFolderList" class="flex justify-center mt-4">
                    <loading paddingClass="px-3 py-1" bgColorClass="bg-gray-400">Fetching...</loading>
                </div>

                <div v-if="leadFolderInfo.id && leadFolderInfo.folder_is_deleted" class="flex justify-center mt-6">
                    <p class="text-red-500">This Lead folder has been deleted! You Can create another folder to upload your files here.</p>
                </div>

                <div
                    v-show="!fetchingFolderList"
                    v-for="content in leadCurrentFolderContents.entries.filter((i) => i.name.toLowerCase().includes(searchTerm.toLowerCase()))"
                    :key="content.id"
                    class="grid gap-4 grid-cols-files items-center border borer-b-1 border-t-0 border-gray-400 text-sm px-4 py-1 justify-start"
                >
                    <input type="checkbox" @change="checkSingleContentClicked(content)" :value="content.id" v-model="checkedContentIds" class="h-5 w-5" />
                    <p @click="contentClicked(content)" class="cursor-pointer truncate">
                        <img v-if="isHierarchyFolder(content) && content.shared_folder_id" class="inline w-6 h-6 scale-110 mr-1" src="@/assets/img/db-folder-shared-lighter.png" alt="" />
                        <img v-else-if="!isHierarchyFolder(content) && content.shared_folder_id" class="inline w-6 h-6 scale-110 mr-1" src="@/assets/img/db-folder-shared-darker.png" alt="" />
                        <img v-else-if="isHierarchyFolder(content)" class="inline w-6 h-6 scale-110 mr-1" src="@/assets/img/db-folder-lighter.png" alt="" />
                        <img v-else-if="isFolder(content)" class="inline w-6 h-6 scale-110 mr-1" src="@/assets/img/db-folder-darker.png" alt="" />
                        <img v-else class="inline w-6 h-6 scale-110 mr-1" src="@/assets/img/db-file.png" alt="" />
                        {{ content.name }}
                    </p>
                    <p>{{ isFolder(content) ? 'Folder' : 'File' }}</p>
                    <p>{{ isFolder(content) ? '-' : bytesToSize(content.size) }}</p>
                    <p>{{ isFolder(content) ? '-' : new Date(content.lastModifiedDateTime).toLocaleDateString() }}</p>
                    <app-select :options="getActionList(content)" @optionPicked="actionPicked">
                        <template v-slot:title>Action</template>
                    </app-select>
                </div>
            </div>
        </div>
        <div v-if="leadCurrentFolderContents.has_more" class="grid place-items-center">
            <button
                @click="loadMoreContents"
                type="button"
                class="inline-flex items-center px-4 py-2 text-sm font-semibold text-blue-500 bg-blue-100 border-2 border-blue-500 shadow leading-6 rounded-md hover:bg-blue-500 hover:text-blue-100 transition ease-in-out duration-150"
            >
                Load More
            </button>
        </div>

        <!-- bottom image of Oscillosoft -->
        <div class="fixed bottom-0 right-2">
            <img height="40" width="100" src="@/assets/img/sass-plugin-logo.png" alt="" />
        </div>

        <!-- Overlay for checking if user has authorized the app from dropbox -->
        <div v-if="showLoadingScreen" class="fixed top-0 left-0 flex items-center justify-center w-screen h-screen bg-slate-300">
            <loading>{{ loadingText }}</loading>
        </div>
        <!-- end:Overlay for checking if user has authorized the app from dropbox -->

        <!-- Overlay for blocking page if OneDrive is not authorized -->
        <div v-if="pluginUser.id && !pluginUser.is_authorized" class="fixed top-0 left-0 flex items-center justify-center w-screen h-screen bg-slate-300">
            <button
                type="button"
                class="inline-flex items-center px-4 py-2 text-sm font-semibold text-white bg-red-500 shadow cursor-not-allowed leading-6 rounded-md hover:bg-red-600 transition ease-in-out duration-150"
                disabled
            >
                Please authorize your OneDrive account first
            </button>
        </div>
        <!-- end:Overlay for blocking page if OneDrive is not authorized -->

        <share-content-modal v-model:isVisible="showShareContentModal" :recordZohoId="leadFolderInfo.zoho_id" :content="contentToShare" @shareSucceeded="shareSucceeded"></share-content-modal>

        <rename-content-modal v-model:isVisible="showRenameContentModal" :recordZohoId="leadFolderInfo.zoho_id" :content="contentToRename" @renameSucceeded="renameSucceeded"></rename-content-modal>

        <template-select
            v-model:isVisible="showTemplateSelectModal"
            :templateOptions="dealTemplateOptions"
            @selectedTemplate="createLeadFoldersFromSettings"
        />
        <create-folder-modal
            v-model:isVisible="showCreateFolderModal"
            :parentFolderId="currentFolderId"
            :recordZohoId="leadFolderInfo.zoho_id"
            @createFolderSucceeded="createFolderSucceeded"
        ></create-folder-modal>

        <move-content-modal
            v-model:isVisible="showMoveContentModal"
            :recordZohoId="leadFolderInfo.zoho_id"
            :content="contentToMove"
            :folderId="leadFolderInfo.folder_id"
            @moveSucceeded="moveSucceeded"
            moduleName="Leads"
        >
            <template v-slot:title> Choose Destination Folder </template>
        </move-content-modal>

        <move-contents-batch-modal
            v-model:isVisible="showMoveContentsBatchModal"
            :recordZohoId="leadFolderInfo.zoho_id"
            :contents="checkedContents"
            :contentIds="checkedContentIds"
            :folderId="leadFolderInfo.folder_id"
            @moveSucceeded="moveSucceeded"
            moduleName="Leads"
        >
            <template v-slot:title> Choose Destination Folder </template>
        </move-contents-batch-modal>

        <delete-content-modal v-model:isVisible="showDeleteContentModal" :recordZohoId="leadFolderInfo.zoho_id" :content="contentToDelete" @deleteSucceeded="deleteSucceeded"></delete-content-modal>

        <delete-contents-batch-modal
            v-model:isVisible="showDeleteContentsBatchModal"
            :recordZohoId="leadFolderInfo.zoho_id"
            :entries="entriesToDelete"
            @batchDeleteSucceeded="batchDeleteSucceeded"
        ></delete-contents-batch-modal>

        <upload-files v-model:isVisible="showUploadFilesModal" :recordZohoId="leadFolderInfo.zoho_id" :parentFolderId="currentFolderId" @uploadSucceeded="uploadSucceeded"> </upload-files>
        <div
            class="fixed z-10 top-0 left-0 flex items-center justify-center w-screen h-screen bg-gray-600/50 transition-all ease-in duration-75"
            :class="{
                'opacity-0 invisible pointer-events-none scale-75': !showErrorModal,
            }"
        >
            <div class="px-10 py-5 bg-white rounded-lg ring-2 w-96">
                <div class="flex items-center text-red-500 mt-2 mb-4 ml-2">{{ modalErrorMessage }}</div>
                <div class="flex justify-center mt-2">
                    <button
                        @click="showErrorModal = false"
                        class="w-1/4 px-4 text-sm font-semibold text-white bg-gray-500 border-2 border-green-500 shadow leading-6 rounded-md transition ease-in-out duration-150"
                    >
                        Ok
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import AppInput from '@/components/AppInput.vue'
import MoveContentModal from '@/components/MoveContentModal.vue'
import MoveContentsBatchModal from '@/components/MoveContentsBatchModal.vue'
import CreateFolderModal from '@/components/CreateFolderModal.vue'
import ShareContentModal from '@/components/ShareContentModal.vue'
import RenameContentModal from '@/components/RenameContentModal.vue'
import DeleteContentModal from '@/components/DeleteContentModal.vue'
import DeleteContentsBatchModal from '@/components/DeleteContentsBatchModal.vue'
import UploadFiles from '@/components/UploadFiles.vue'
import Loading from '@/components/Loading.vue'
import AppSelect from '@/components/AppSelect.vue'
import utils from '@/utils'
import {mapGetters} from 'vuex'
import axios from "axios";
import TemplateSelect from "@/components/TemplateSelect";

export default {
    name: 'pages.leads.widget',
    components: {
        AppInput,
        Loading,
        MoveContentModal,
        MoveContentsBatchModal,
        CreateFolderModal,
        ShareContentModal,
        RenameContentModal,
        DeleteContentModal,
        DeleteContentsBatchModal,
        AppSelect,
        UploadFiles,
        TemplateSelect
    },
    data: () => ({
        leadId: null,
        currentFolderId: null,
        folderDepth: 0,
        showLoadingScreen: false,
        fetchingFolderList: false,
        loadingText: 'Please Wait...',
        searchTerm: '',
        showChooseMoveFolderDialogueBox: false,
        showCreateFolderModal: false,
        showShareContentModal: false,
        contentToShare: null,
        contentToRename: null,
        showRenameContentModal: false,
        contentToMove: null,
        showMoveContentModal: false,
        showMoveContentsBatchModal: false,
        showDeleteContentModal: false,
        contentToDelete: null,
        allContentsChecked: false,
        checkedContentIds: [],
        showDeleteContentsBatchModal: false,
        entriesToDelete: [],
        showUploadFilesModal: false,

        modulesName: 'leads',
        showTemplateSelectModal: false,
        dealTemplateOptions: [],
        showErrorModal: false,
        modalErrorMessage: null,
        parentFolderId: null,
        rootFolderId: null,
        fetchingFolderInfo: false
    }),
    computed: {
        ...mapGetters({
            zapikey: 'zoho/zapikey',
            pluginUser: 'pluginUser/user',
            leadZoho: 'lead/leadZoho',
            leadFolderInfo: 'lead/leadFolderInfo',
            leadCurrentFolderContents: 'lead/leadCurrentFolderContents',
        }),
        hierarchyFolderIsSelected() {
            var result = !this.checkedContentIds.length

            this.checkedContentIds.forEach((i) => {
                if (!result) {
                    const content = this.leadCurrentFolderContents.entries.find((item) => item.id == i)
                    if (this.isFolder(content) && content.is_hierarchy_folder) {
                        result = true
                    }
                }
            })

            return result
        },
        checkedContents() {
            return this.checkedContentIds.map((i) => this.leadCurrentFolderContents.entries.find((item) => item.id == i))
        },
    },
    watch: {
        async leadFolderInfo(newValue) {
            if (newValue.id && !newValue.folder_is_deleted) {
                this.currentFolderId = newValue.folder_id
                this.rootFolderId = newValue.folder_id
                this.fetchingFolderList = true
                await this.$store.dispatch('lead/fetchFolderContents', { zohoId: newValue.zoho_id, folderId: this.currentFolderId })
                this.fetchingFolderList = false
            }
        },
    },
    async mounted() {
        await this.init()
    },
    methods: {
        async init() {
            this.showLoadingScreen = true

            ZOHO.embeddedApp.on('PageLoad', async (data) => {
                this.leadId = data.EntityId
                await this.$store.dispatch('lead/fetchLeadZoho', this.leadId)

                await this.$store.dispatch('zoho/fetchZohoZapiKey')
                await this.$store.dispatch('pluginUser/fetchUser')
                await this.$store.dispatch('lead/fetchLeadFolderInfo', this.leadId)

                this.showLoadingScreen = false
            })
            ZOHO.embeddedApp.init()
        },
        async openTemplateSelectModal() {
            await axios.get(`${process.env.VUE_APP_BACKEND_API_URL}/api/users/${this.zapikey}/fetchDealTemplateOptions`, {
                params: {'module_name': this.modulesName}
            }).then((res) => {
                this.dealTemplateOptions = res.data
            }).catch(err => {
                this.showErrorModal = true
                this.modalErrorMessage = "Couldn't Fetching Templates! Please Try again."
            })
            if (!this.showErrorModal) this.showTemplateSelectModal = true;
        },
        async createLeadFoldersFromSettings(templateId) {
            this.showLoadingScreen = true
            this.loadingText = 'Creating Lead Folders...'

            await this.$store.dispatch('lead/createLeadFoldersFromSettings', templateId)

            this.loadingText = 'Fetching Contents...'
            await this.$store.dispatch('lead/fetchLeadFolderInfo', this.leadId)

            this.showLoadingScreen = false
        },
        bytesToSize(bytes) {
            return utils.bytesToSize(bytes)
        },
        isFolder(content) {
            return content['.tag'] == 'folder'
        },
        async contentClicked(content) {
            if (this.isFolder(content)) {
                this.currentFolderId = content.id
                this.parentFolderId = content.parentReference['id']
                await this.fetchCurrentFolderContents()

                this.folderDepth++
            } else {
                var link = content.webUrl
                // var link = content['@microsoft.graph.downloadUrl']
                window.open(link, '_blank')
            }
        },
        async fetchCurrentFolderContents() {
            this.fetchingFolderList = true
            this.allContentsChecked = false
            this.checkedContentIds = []
            await this.$store.dispatch('lead/fetchFolderContents', { zohoId: this.leadFolderInfo.zoho_id, folderId: this.currentFolderId })
            this.fetchingFolderList = false
        },
        async goToParentFolder() {
            if (this.fetchingFolderInfo === false) {
                let pId = this.parentFolderId;
                this.currentFolderId = pId
                this.fetchingFolderList = true
                await this.$store.dispatch('lead/fetchFolderContents', {
                    folderId: pId,
                    zohoId: this.leadFolderInfo.zoho_id
                }).then((response) => {
                    this.fetchingFolderInfo = true
                    this.fetchParentFolderInfo(response.value[0].parentReference.id)
                })
                this.fetchingFolderList = false

                this.folderDepth--
            }
        },
        async fetchParentFolderInfo(folderId) {
            await this.$store
                .dispatch('oneDrive/fetchFolderInfo', {
                    folderId: folderId,
                    zapikey: this.zapikey,
                })
                .then((res) => {
                    this.parentFolderId = res.data.parentReference.id !== undefined ? res.data.parentReference.id : 'root';
                    this.fetchingFolderInfo = false
                })
        },
        isHierarchyFolder(content) {
            return this.isFolder(content) && content.is_hierarchy_folder
        },
        loadMoreContents() {
            this.$store.dispatch('lead/loadMoreContents', {
                cursor: this.leadCurrentFolderContents.cursor,
                zohoId: this.leadFolderInfo.zoho_id,
                folderId: this.currentFolderId
            })
        },
        getActionList(content) {
            if (this.isFolder(content) && content.is_hierarchy_folder) {
                return [
                    { label: 'Browse', value: 'Browse', content: content },
                    { label: 'Share', value: 'Share', content: content },
                ]
            } else {
                return [
                    { label: 'Browse', value: 'Browse', content: content },
                    { label: 'Share', value: 'Share', content: content },
                    { label: 'Move', value: 'Move', content: content },
                    { label: 'Rename', value: 'Rename', content: content },
                    { label: 'Delete', value: 'Delete', content: content },
                ]
            }
        },
        actionPicked(option) {
            var action = option.value
            var content = option.content
            switch (action) {
                case 'Browse':
                    this.browseToContent(content)
                    break
                case 'Share':
                    this.shareContent(content)
                    break
                case 'Move':
                    this.moveContent(content)
                    break
                case 'Rename':
                    this.renameContent(content)
                    break
                case 'Delete':
                    this.deleteContent(content)
                    break
                default:
                    break
            }
        },
        browseToContent(content) {
            var link = content.webUrl
            window.open(link, '_blank')
        },
        createFolder() {
            this.showCreateFolderModal = true
        },
        createFolderSucceeded() {
            // this.showCreateFolderModal = false
            this.fetchCurrentFolderContents()
        },
        shareContent(content) {
            this.contentToShare = content
            this.showShareContentModal = true
        },
        shareSucceeded(content) {
            if (!content.shared_folder_id) {
                this.fetchCurrentFolderContents()
            }
        },
        renameContent(content) {
            this.contentToRename = content
            this.showRenameContentModal = true
        },
        renameSucceeded() {
            this.fetchCurrentFolderContents()
        },
        moveContent(content) {
            this.contentToMove = content
            this.showMoveContentModal = true
        },
        moveSucceeded() {
            this.fetchCurrentFolderContents()
        },
        moveContentsBatch(content) {
            this.showMoveContentsBatchModal = true
        },
        moveBatchSucceeded() {
            this.fetchCurrentFolderContents()
        },
        deleteContent(content) {
            this.contentToDelete = content
            this.showDeleteContentModal = true
        },
        deleteSucceeded() {
            this.fetchCurrentFolderContents()
        },
        checkAllContentsClicked() {
            if (this.allContentsChecked) {
                this.checkedContentIds = [].concat(this.leadCurrentFolderContents.entries.map((i) => i.id))
            } else {
                this.checkedContentIds = []
            }
        },
        checkSingleContentClicked() {
            if (this.checkedContentIds.length != this.leadCurrentFolderContents.entries.length) {
                this.allContentsChecked = false
            } else {
                this.allContentsChecked = true
            }
        },
        deleteContentsBatch() {
            this.showDeleteContentsBatchModal = true
            this.entriesToDelete = this.checkedContentIds.map((i) => ({ id: i }))
        },
        async batchDeleteSucceeded() {
            // this.showDeleteContentsBatchModal = false
            this.fetchCurrentFolderContents()
        },
        uploadFilesClicked() {
            this.showUploadFilesModal = true
        },
        uploadSucceeded() {
            this.fetchCurrentFolderContents()
        },
    },
}
</script>
