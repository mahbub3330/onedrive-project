<template>
  <div class="row">
    <div class="col-8">
      <h3> Hello  </h3>
    </div>
  </div>
</template>

<script>

export default {
  name: "test-example",
  display: "Nested",
  order: 15,
  components: {

  },
  data() {
    return {
      folderList: [
        {
          name: "Analysis",
          folders: [],
        },
        {
          name: "Sign-Off",
          folders: [],
        },
        {
          name: "Handover",
          folders: [],
        },
        {
          name: "Requirement",
          folders: [],
        },
        {
          name: "Requirement 1",
          folders: [],
        },
        {
          name: "Requirement 2",
          folders: [],
        },
        {
          name: "Requirement 3",
          folders: [],
        },
        // {
        //     name: "task 3",
        //     folders: [
        //         {
        //             name: "task 4",
        //             folders: [],
        //         },
        //     ],
        // },
        // {
        //     name: "task 5",
        //     folders: [],
        // },
      ],
    };
  },
  mounted() {
    console.log('hitted!!')
  }
};
</script>
<style scoped></style>
