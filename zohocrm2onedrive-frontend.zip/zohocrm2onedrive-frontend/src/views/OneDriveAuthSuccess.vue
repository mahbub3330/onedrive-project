<template>
    <div class="flex items-center justify-center bg-indigo-100 h-screen">
        <h2 class="text-indigo-500 text-5xl">Authorization done successfully.</h2>
    </div>
</template>

<script>
export default {
    mounted() {
        localStorage.setItem('reloadPage', true)
        setTimeout(() => {
            window.close()
        }, 600)
    },
}
</script>
